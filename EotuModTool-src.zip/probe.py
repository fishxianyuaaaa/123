"""Auto-aligning UE4 package header reader (handles the 2-byte offset quirk in this game's cooked assets).

Strategy: locate the name table by finding an offset whose int32 value points at a run of
count FString+hash entries that parse cleanly; then locate import/export tables by matching
offsets to the end of the previous table.
"""
import struct


class R:
    def __init__(self, d, p=0):
        self.d = d
        self.p = p

    def i32(self):
        v = struct.unpack_from('<i', self.d, self.p)[0]
        self.p += 4
        return v

    def u32(self):
        return self.i32() & 0xFFFFFFFF

    def raw(self, n):
        v = self.d[self.p:self.p + n]
        self.p += n
        return v

    def fstr(self):
        n = self.i32()
        if n <= 0:
            return None
        s = self.d[self.p:self.p + n - 1]
        self.p += n
        return s.decode('utf-8', 'replace')


def parse_names(d, start, count, hash_len=4):
    p = start
    out = []
    for _ in range(count):
        r = R(d, p)
        s = r.fstr()
        if s is None or len(s) == 0:
            return None
        r.raw(hash_len)
        out.append(s)
        p = r.p
    return out, p


class UAsset:
    def __init__(self, uasset_bytes, uexp_bytes=None):
        self.uasset = uasset_bytes
        self.uexp = uexp_bytes or b''
        self._scan()

    def _find_name_table(self):
        d = self.uasset
        # candidate: (count_field_off, offset_field_off) with offset_field = count_field+4
        for off in range(20, 400):
            opos = off + 4
            if opos + 4 > len(d):
                break
            cnt = struct.unpack_from('<i', d, off)[0]
            tbl = struct.unpack_from('<i', d, opos)[0]
            if not (10 <= cnt <= 20000) or not (40 <= tbl < len(d)):
                continue
            for hl in (4, 8):
                res = parse_names(d, tbl, cnt, hl)
                if res:
                    return cnt, tbl, res[0], res[1], hl, off
        return None

    def _scan(self):
        d = self.uasset
        r = self._find_name_table()
        if r is None:
            raise RuntimeError('name table not found')
        self.name_count, self.name_offset, self.names, names_end, self.hash_len, self.name_count_pos = r
        # imports: find int32 in header equal to names_end (the import offset), count just before
        self.import_offset = None
        for off in range(0, min(600, len(d) - 4)):
            if struct.unpack_from('<i', d, off)[0] == names_end:
                self.import_offset = names_end
                self.import_count = struct.unpack_from('<i', d, off - 4)[0]
                self.import_count_pos = off - 4
                break
        if self.import_offset is None:
            raise RuntimeError('import offset not found')
        self.imports = []
        p = self.import_offset
        for _ in range(self.import_count):
            rr = R(d, p)
            self.imports.append((rr.i32(), rr.i32(), rr.i32(), rr.i32()))
            p = rr.p
        imports_end = p
        self.export_offset = None
        for off in range(0, min(800, len(d) - 4)):
            if struct.unpack_from('<i', d, off)[0] == imports_end:
                self.export_offset = imports_end
                self.export_count = struct.unpack_from('<i', d, off - 4)[0]
                self.export_count_pos = off - 4
                break
        assert self.export_offset is not None, 'export offset not found'
        self.exports = []
        p = self.export_offset
        for _ in range(self.export_count):
            e = R(d, p)
            self.exports.append({
                'class_index': e.i32(),
                'super_index': e.i32(),
                'template_index': e.i32(),
                'outer_index': e.i32(),
                'object_name_index': e.i32(),
                'object_flags': e.u32(),
                'serial_size': e.i32(),
                'serial_offset': e.i32(),
                'forced': e.i32(),
                'not_for_client': e.i32(),
                'not_for_server': e.i32(),
                '_pos': p,
            })
            p = e.p
        self.export_table_pos = self.export_offset
        self.export_table_end = p
        # total header size = file length (uasset only holds header here)
        self.total_header_size = len(self.uasset)

    def name(self, i):
        return self.names[i] if 0 <= i < len(self.names) else str(i)

    def export_bytes(self, i):
        e = self.exports[i]
        start = e['serial_offset'] - self.total_header_size
        return self.uexp[start:start + e['serial_size']]
