"""EotU (Empires of the Undergrowth) CreatureStats DataTable reader / in-place editor.

Cooked UE4 package layout used by this build (verified against
EotU/Content/Assets/Data/CreatureStats.uasset of v1.200003):
  .uasset  = package header (name table at NameOffset, one 4-byte hash per FName entry)
  .uexp    = export payload:
       [FName RowStruct][FName ObjectProperty][int32 Size][int32 ArrayIndex]
       [byte HasPropertyGuid][int32 RowStructImportIndex]
       [FName None]                       <- end of UObject property list
       [int32 NumKeysToRemove][int32 NumRows]
       rows of:  [FName RowName] { [FName Name][FName Type][int32 Size][int32 ArrayIndex]
                                   (+ BoolVal byte for BoolProperty,
                                    + FName StructName + Guid for StructProperty,
                                    + FName EnumName for Enum/ByteProperty)
                                   [byte HasPropertyGuid] [Size bytes value] } [FName None]

Only value bytes are rewritten, so the file size never changes and the .uasset
(export table with serial sizes/offsets) stays valid untouched.
"""
import json
import struct

from probe import parse_names

NONE = 'None'


class Value:
    """One property value inside a row, with the byte offset where it lives."""
    __slots__ = ('name', 'type', 'size', 'pos', 'raw', 'bool_pos', 'bool_val')

    def __init__(self, name, type_, size, pos, raw, bool_pos=None, bool_val=None):
        self.name = name
        self.type = type_
        self.size = size
        self.pos = pos
        self.raw = raw
        self.bool_pos = bool_pos
        self.bool_val = bool_val

    @property
    def is_float(self):
        return self.type == 'FloatProperty' and self.size == 4

    @property
    def is_int(self):
        return self.type == 'IntProperty' and self.size == 4

    def get_float(self):
        return struct.unpack('<f', self.raw)[0]

    def get_int(self):
        return struct.unpack('<i', self.raw)[0]


class Table:
    def __init__(self, uasset_path, uexp_path):
        self.uasset = bytearray(open(uasset_path, 'rb').read())
        self.uexp = bytearray(open(uexp_path, 'rb').read())
        self.uasset_path = uasset_path
        self.uexp_path = uexp_path
        self._load()

    # ---------------- header ----------------
    def _load(self):
        ua = bytes(self.uasset)
        self.name_count = self.name_offset = None
        for off in range(20, 400):
            cnt = struct.unpack_from('<i', ua, off)[0]
            tbl = struct.unpack_from('<i', ua, off + 4)[0]
            if not (5 <= cnt <= 20000) or not (40 <= tbl < len(ua)):
                continue
            res = parse_names(ua, tbl, cnt, 4)
            if res:
                self.names, end = res
                self.name_count, self.name_offset = cnt, tbl
                break
        if self.name_offset is None:
            raise RuntimeError('name table not found in ' + self.uasset_path)
        self._find_rows()

    def _find_rows(self):
        """Locate the row stream: 在所有可行起始偏移里取"行数最多"的那个。

        注意：不能取"第一个能跑通的 start"——Abilities 表实测会被错位解析成 265 行
        （真实 331 行，BasicAttack / BTBStunAOE_Small 等全被漏掉）。取最大行数最稳。
        """
        best = None
        n = len(self.uexp)
        for start in range(30, 200):
            try:
                rows, pos, _ = self._walk(start)
            except Exception:
                continue
            if len(rows) < 2:
                continue
            tail = bytes(self.uexp[pos:n])
            ok_tail = (len(tail) == 4 and tail == struct.pack('<I', 0x9E2A83C1)) \
                or (len(tail) <= 16 and all(b == 0 for b in tail))
            if not ok_tail:
                continue
            if best is None or len(rows) > len(best[1]):
                best = (start, rows)
        if best is None:
            raise RuntimeError('row stream not found in ' + self.uexp_path)
        self.row_start, self.rows = best

    # ---------------- rows ----------------
    def _walk(self, start):
        d = bytes(self.uexp)
        n = len(d)
        p = start
        rows = []
        while p < n:
            if n - p < 8:  # trailing padding / end marker
                break
            ri, rn = struct.unpack_from('<ii', d, p)
            p += 8
            rname = self._n(ri)
            props = []
            while True:
                ni, nn = struct.unpack_from('<ii', d, p)
                p += 8
                pname = self._n(ni)
                if pname == NONE:
                    break
                ti, tn = struct.unpack_from('<ii', d, p)
                p += 8
                ptype = self._n(ti)
                size = struct.unpack_from('<i', d, p)[0]
                p += 4
                p += 4  # ArrayIndex
                bool_pos = bool_val = None
                if ptype == 'StructProperty':
                    p += 8 + 16
                elif ptype in ('EnumProperty', 'ByteProperty'):
                    p += 8
                elif ptype == 'BoolProperty':
                    bool_pos = p
                    bool_val = d[p]
                    p += 1
                g = d[p]
                p += 1
                if g:
                    p += 16
                raw = d[p:p + size]
                if len(raw) != size:
                    raise ValueError('truncated')
                props.append(Value(pname, ptype, size, p, raw, bool_pos, bool_val))
                p += size
            rows.append((rname, props))
        return rows, p, None

    def _n(self, i):
        return self.names[i] if 0 <= i < len(self.names) else '?%d' % i

    # ---------------- editing ----------------
    def set_float(self, row_idx, prop_name, value):
        v = self._find(row_idx, prop_name)
        if not v.is_float:
            raise TypeError(f'{prop_name} is {v.type}, not float')
        self.uexp[v.pos:v.pos + 4] = struct.pack('<f', float(value))
        v.raw = bytes(self.uexp[v.pos:v.pos + 4])

    def set_int(self, row_idx, prop_name, value):
        v = self._find(row_idx, prop_name)
        if not v.is_int:
            raise TypeError(f'{prop_name} is {v.type}, not int')
        self.uexp[v.pos:v.pos + 4] = struct.pack('<i', int(value))
        v.raw = bytes(self.uexp[v.pos:v.pos + 4])

    def set_bool(self, row_idx, prop_name, value):
        v = self._find(row_idx, prop_name)
        if v.type != 'BoolProperty':
            raise TypeError(f'{prop_name} is {v.type}, not bool')
        self.uexp[v.bool_pos] = 1 if value else 0
        v.bool_val = 1 if value else 0

    def set_enum(self, row_idx, prop_name, value):
        """把 EnumProperty 改成指定枚举值。

        UE 里枚举值存的是一个 FName（索引+number，共 8 字节），
        名字表里的写法是 'EAbilityType::AT_Charge' 这种带类型前缀的完整串。
        """
        v = self._find(row_idx, prop_name)
        if v.type != 'EnumProperty':
            raise TypeError(f'{prop_name} is {v.type}, not enum')
        try:
            idx = self.names.index(value)
        except ValueError:
            raise RuntimeError(f'名称表里找不到枚举值「{value}」')
        self.uexp[v.pos:v.pos + 8] = struct.pack('<ii', idx, 0)
        v.raw = bytes(self.uexp[v.pos:v.pos + 8])

    def _find(self, row_idx, prop_name):
        for v in self.rows[row_idx][1]:
            if v.name == prop_name:
                return v
        raise KeyError(prop_name)

    # ---------------- io ----------------
    def to_dict(self):
        out = {}
        for rname, props in self.rows:
            d = {}
            for v in props:
                if v.is_float:
                    d[v.name] = v.get_float()
                elif v.is_int:
                    d[v.name] = v.get_int()
                elif v.type == 'BoolProperty':
                    d[v.name] = bool(v.bool_val)
                elif v.type == 'EnumProperty':
                    i, _ = struct.unpack('<ii', v.raw)
                    d[v.name] = self._n(i)
                else:
                    d[v.name] = v.raw.hex()
            out[rname] = d
        return out

    def save(self, uexp_out=None, uasset_out=None):
        uexp_out = uexp_out or self.uexp_path
        uasset_out = uasset_out or self.uasset_path
        with open(uexp_out, 'wb') as f:
            f.write(bytes(self.uexp))
        with open(uasset_out, 'wb') as f:
            f.write(bytes(self.uasset))

    def save_json(self, path):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)


def load(name, workdir='_work'):
    return Table(f'{workdir}/{name}.uasset', f'{workdir}/{name}.uexp')
