# -*- coding: utf-8 -*-
"""生物数据目录：把 CreatureStats 两套表读成前端能直接渲染的结构。"""
import os
import re

from . import labels as label_mod
from . import paths, taxonomy
from .locres_names import display_names
from eotu_stats import Table

# 字段分组与中文标签。kind 决定前端用什么控件、后端怎么写值。
FIELDS = [
    # --- 战斗 ---
    dict(name='Health', label='生命值', kind='float', group='战斗', hint='单位最大血量'),
    dict(name='AttackDamage', label='攻击力', kind='float', group='战斗', hint='单次攻击基础伤害'),
    dict(name='AttackSpeed', label='攻击速度', kind='float', group='战斗', hint='每秒攻击次数'),
    dict(name='Speed', label='移动速度', kind='float', group='战斗', hint='太大会导致手感失控'),
    dict(name='HealthPerSecond', label='每秒回血', kind='float', group='战斗'),
    dict(name='MaxSingleDamage', label='单次受伤上限', kind='float', group='战斗', hint='0 或极大值通常表示不限制'),
    dict(name='Piercing', label='穿透', kind='float', group='战斗'),
    dict(name='BasicAttackThreatGeneration', label='普攻仇恨', kind='float', group='战斗'),
    dict(name='PointValue', label='点数价值', kind='float', group='战斗'),
    # --- 防御 ---
    dict(name='Armour', label='护甲', kind='float', group='防御'),
    dict(name='PhysicalResist', label='物理抗性', kind='float', group='防御', hint='一般填 0 ~ 1'),
    dict(name='VenomResist', label='毒液抗性', kind='float', group='防御', hint='一般填 0 ~ 1'),
    dict(name='AOEResist', label='范围伤害抗性', kind='float', group='防御', hint='一般填 0 ~ 1'),
    dict(name='SlowResist', label='减速抗性', kind='float', group='防御', hint='一般填 0 ~ 1'),
    dict(name='Evasion', label='闪避率', kind='float', group='防御', hint='一般填 0 ~ 1'),
    dict(name='Temperament', label='性情', kind='enum', group='防御', hint='枚举值，本版本只读'),
    # --- 采集与行为 ---
    dict(name='DigAmmount', label='挖掘量', kind='float', group='行为'),
    dict(name='DigSpeed', label='挖掘速度', kind='float', group='行为'),
    dict(name='FoodHarvestTime', label='采集耗时', kind='float', group='行为'),
    dict(name='FoodCarryMax', label='携带食物上限', kind='int', group='行为'),
    dict(name='FoodValue', label='食物价值', kind='int', group='行为'),
    dict(name='WanderDistance', label='游荡距离', kind='float', group='行为'),
    dict(name='PickupTime', label='拾取耗时', kind='float', group='行为'),
    dict(name='TargetRadius', label='目标半径', kind='float', group='行为'),
    dict(name='ArrivalDistance', label='到达判定距离', kind='float', group='行为'),
    dict(name='ReachableDistance', label='可及距离', kind='float', group='行为'),
    dict(name='AttackTolDistance', label='攻击容许距离', kind='float', group='行为'),
    # --- 状态开关 ---
    dict(name='CannotBePickedUp', label='不可被叼起', kind='bool', group='开关'),
    dict(name='CannotBeExercuted', label='不可被处决', kind='bool', group='开关'),
    dict(name='CannotBeStunned', label='不可被眩晕', kind='bool', group='开关'),
    dict(name='CannotBeConfused', label='不可被混乱', kind='bool', group='开关'),
    dict(name='CannotFlee', label='不会逃跑', kind='bool', group='开关'),
    dict(name='CannotBeStrongPickedUp', label='不可被强力叼起', kind='bool', group='开关'),
    dict(name='CannotBeKnockedBack', label='不可被击退', kind='bool', group='开关'),
]

FIELD_MAP = {f['name']: f for f in FIELDS}
GROUPS = ['战斗', '防御', '行为', '开关']

# 界面英文模式用
FIELD_EN = {
    'Health': 'Health', 'AttackDamage': 'Attack Damage', 'AttackSpeed': 'Attack Speed',
    'Speed': 'Move Speed', 'HealthPerSecond': 'HP Regen / s',
    'MaxSingleDamage': 'Max Damage per Hit', 'Piercing': 'Piercing',
    'BasicAttackThreatGeneration': 'Basic Attack Threat', 'PointValue': 'Point Value',
    'Armour': 'Armour', 'PhysicalResist': 'Physical Resist',
    'VenomResist': 'Venom Resist', 'AOEResist': 'AoE Resist',
    'SlowResist': 'Slow Resist', 'Evasion': 'Evasion', 'Temperament': 'Temperament',
    'DigAmmount': 'Dig Amount', 'DigSpeed': 'Dig Speed',
    'FoodHarvestTime': 'Harvest Time', 'FoodCarryMax': 'Food Carry Max',
    'FoodValue': 'Food Value', 'WanderDistance': 'Wander Distance',
    'PickupTime': 'Pickup Time', 'TargetRadius': 'Target Radius',
    'ArrivalDistance': 'Arrival Distance', 'ReachableDistance': 'Reachable Distance',
    'AttackTolDistance': 'Attack Tolerance',
    'CannotBePickedUp': 'Cannot Be Picked Up',
    'CannotBeExercuted': 'Cannot Be Executed',
    'CannotBeStunned': 'Cannot Be Stunned',
    'CannotBeConfused': 'Cannot Be Confused',
    'CannotFlee': 'Cannot Flee',
    'CannotBeStrongPickedUp': 'Cannot Be Force-Picked Up',
    'CannotBeKnockedBack': 'Cannot Be Knocked Back',
}
GROUP_EN = {'战斗': 'Combat', '防御': 'Defence', '行为': 'Behaviour', '开关': 'Flags'}
TEMPERAMENT = {
    'ECreatureTemperament::AttackOnSight': ('主动攻击（见到就打）', 'Attack on sight'),
    'ECreatureTemperament::AttackWhenFavorable': ('有利时才攻击', 'Attack when favorable'),
    'ECreatureTemperament::DoNotAttack': ('不主动攻击', 'Do not attack'),
    'ECreatureTemperament::RetreatWhenAttacked': ('被攻击时撤退', 'Retreat when attacked'),
    'ECreatureTemperament::AttackWhenAttacked': ('被攻击才还手', 'Attack when attacked'),
}
CATEGORY_LABEL = {'player': '玩家蚁种', 'wild': '野生 / 敌对', 'special': '特殊'}
CATEGORY_LABEL_EN = {'player': 'Player ants', 'wild': 'Wild / hostile', 'special': 'Special'}

PLAYER_PREFIXES = (
    'BlackAnt', 'WorkerAnt', 'MTWorkerAnt', 'Queen', 'RoyalGuard', 'SwarmQueen',
    'WoodAnt', 'FireAnt', 'Leafcutter', 'BulletAnt', 'Termite', 'YungTermite',
    'ExplodingAnt', 'ExplodingTermite', 'PlayerControlledSpider',
)
SPECIAL_ROWS = {'Default', 'TestCreature1', 'Larry1', 'NianBeast1'}
SPECIAL_PREFIXES = ('SmallAttackPoint', 'MediumSmallAttackPoint', 'MediumAttackPoint', 'LargeAttackPoint')

# locres 覆盖不到（或想用更顺口叫法）的行前缀
ALIASES = {
    'BlackAnt': '黑蚁', 'WorkerAnt': '基因窃贼蚁工蚁', 'MTWorkerAnt': '繁殖蚁工蚁',
    'Queen': '蚁后', 'RoyalGuard': '皇家卫兵', 'SwarmQueen': '群落蚁后',
    'WoodAntA': '木蚁（快速型）', 'WoodAntB': '木蚁（远程型）', 'WoodAntMelee': '木蚁（近战型）',
    'WoodAnt': '木蚁', 'FireAntPervasive': '火蚁兵蚁（普及型）',
    'FireAntVigorous': '火蚁兵蚁（亢奋型）', 'FireAntWorker': '火蚁工蚁',
    'FireAntQueen': '火蚁蚁后', 'FireAnt': '火蚁',
    'LeafcutterMedia': '切叶蚁（中型）', 'LeafcutterMajorStun': '切叶蚁（眩晕大兵）',
    'LeafcutterMajorTaunt': '切叶蚁（嘲讽大兵）', 'LeafcutterMinor': '切叶蚁（小工蚁）',
    'LeafcutterMinim': '切叶蚁（微型）', 'Leafcutter': '切叶蚁',
    'BulletAnt': '子弹蚁', 'Termite': '白蚁', 'YungTermite': '幼白蚁',
    'ExplodingAnt': '爆炸蚁', 'ExplodingTermite': '爆炸白蚁',
    'Matabele': '马塔贝勒蚁', 'DriverAnt': '黑色行军蚁', 'ArmyAnt': '行军蚁',
    'DCHAdult': '魔鬼隐翅虫成虫', 'DCHLarvae': '魔鬼隐翅虫幼虫',
    'RoveBeetleA': '绿色隐翅虫', 'RoveBeetleB': '蓝色隐翅虫',
    'BeachWolfSpider': '海滩狼蛛', 'LargeHermitCrab': '大型寄居蟹',
    'Default': '默认模板（未使用行）',
}


def category_of(row):
    if row in SPECIAL_ROWS or row.startswith(SPECIAL_PREFIXES):
        return 'special'
    if row.startswith(PLAYER_PREFIXES):
        return 'player'
    return 'wild'


def _cn_label(row, names):
    m = re.match(r'^(.*?)(\d+)$', row)
    base, level = (m.group(1), m.group(2)) if m else (row, '')
    cn = None
    if base in names:
        cn = names[base]
    if not cn:
        cands = [t for t in names if base.startswith(t) or t.startswith(base)]
        if cands:
            cn = names[max(cands, key=len)]
    if not cn:
        for prefix in sorted(ALIASES, key=len, reverse=True):
            if base.startswith(prefix):
                cn = ALIASES[prefix]
                break
    if not cn:
        cn = taxonomy.role_cn(base)
    cn = cn or base or row
    if level:
        cn = f'{cn} · {level}级'
    return cn, base, level


_CN_CACHE = None


def cn_for_base(base):
    """给文案页用：把「FireAntPervasive」这类物种标识翻成中文显示名。"""
    global _CN_CACHE
    if _CN_CACHE is None:
        loc = paths.locres_src('data')
        _CN_CACHE = display_names(loc) if os.path.isfile(loc) else {}
    cn, _, _ = _cn_label(base, _CN_CACHE)
    return cn


def _round(v):
    if isinstance(v, float):
        return round(v, 6)
    return v


def build():
    tables = {}
    for name in paths.TABLE_PATHS:
        t = Table(paths.table_src(name, 'uasset'), paths.table_src(name, 'uexp'))
        tables[name] = t
    story = tables['CreatureStats'].to_dict()
    free = tables['CreatureStats_Freeplay'].to_dict()
    loc = paths.locres_src('data')
    names = display_names(loc) if os.path.isfile(loc) else {}

    creatures, matched = [], 0
    for row, props in tables['CreatureStats'].rows:
        vals = story.get(row, {})
        fvals = free.get(row, {})
        diff = []
        for f in FIELDS:
            n = f['name']
            if n in vals and n in fvals and isinstance(vals[n], (int, float)) \
                    and isinstance(fvals[n], (int, float)) and abs(float(vals[n]) - float(fvals[n])) > 1e-6:
                diff.append(n)
        cn, base, level = _cn_label(row, names)
        if cn != base and not cn.startswith(base):
            matched += 1
        family = taxonomy.family_of(row)
        fam = next((f for f in taxonomy.FAMILIES if f['id'] == family), None)
        creatures.append(dict(
            row=row, cn=cn, cn_en=label_mod.humanize(base) + (f' · Lv.{level}' if level else ''),
            base=base, level=level,
            category=category_of(row), family=family,
            category_label=CATEGORY_LABEL.get(category_of(row), category_of(row)),
            category_label_en=CATEGORY_LABEL_EN.get(category_of(row), category_of(row)),
            family_label=fam['label'] if fam else '其他',
            family_label_en=fam['label_en'] if fam else 'Other',
            temperament_cn=TEMPERAMENT.get(str(vals.get('Temperament')), (None, None))[0],
            temperament_en=TEMPERAMENT.get(str(vals.get('Temperament')), (None, None))[1],
            search=(cn + ' ' + base + ' ' + row + ' ' + family).lower(),
            values={k: _round(v) for k, v in vals.items()},
            fp={k: _round(v) for k, v in fvals.items()},
            fp_diff=diff,
        ))
    fams = [dict(f, label_en=f.get('label_en', f['label']), hint_en=f.get('hint_en', ''))
            for f in taxonomy.FAMILIES]
    return dict(
        fields=[dict(f, label_en=FIELD_EN.get(f['name'], f['name']),
                     hint_en=f.get('hint', ''), group_en=GROUP_EN.get(f['group'], f['group']))
                for f in FIELDS],
        groups=GROUPS, groups_en=[GROUP_EN.get(g, g) for g in GROUPS],
        families=fams,
        creatures=creatures,
        stats=dict(
            rows=len(creatures),
            cn_matched=matched,
            story_rows=len(story),
            freeplay_rows=len(free),
            same_rows=[c['row'] for c in creatures] == list(free.keys()),
            by_family={f['id']: sum(1 for c in creatures if c['family'] == f['id'])
                       for f in taxonomy.FAMILIES},
        ),
    )
