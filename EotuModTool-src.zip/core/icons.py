# -*- coding: utf-8 -*-
"""生物 UI 图标库：从原版 pak 提取、生成预览、把新图写进 .uexp。

EotU 的信息素面板/巢穴分配图标都是 Texture2D，像素数据在 .uexp 末尾，
格式为 PF_B8G8R8A8。替换时只覆盖末尾 size 字节、文件长度完全不变，
.uasset 里的 SerialSize 不用动，因此不会破坏资产结构。
"""
import base64
import json
import os
import struct
import subprocess
import zlib

from . import labels as label_mod
from . import paths, taxonomy

FMT = b'PF_B8G8R8A8'


# ---------------- PNG 读写（纯标准库，exe 不依赖 Pillow） ----------------
def _png_chunk(kind, data):
    c = kind + data
    return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xFFFFFFFF)


def write_png(path, w, h, rgba):
    raw = bytearray()
    stride = w * 4
    for y in range(h):
        raw.append(0)
        raw.extend(rgba[y * stride:(y + 1) * stride])
    out = (b'\x89PNG\r\n\x1a\n'
           + _png_chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
           + _png_chunk(b'IDAT', zlib.compress(bytes(raw), 9))
           + _png_chunk(b'IEND', b''))
    with open(path, 'wb') as f:
        f.write(out)


def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else (b if pb <= pc else c)


def decode_png(data):
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('不是 PNG 图片')
    p, idat, w, h, ctype, depth, palette, trns = 8, bytearray(), 0, 0, 0, 0, None, None
    while p + 8 <= len(data):
        ln, = struct.unpack_from('>I', data, p)
        kind = data[p + 4:p + 8]
        body = data[p + 8:p + 8 + ln]
        p += 12 + ln
        if kind == b'IHDR':
            w, h, depth, ctype, comp, filt, inter = struct.unpack('>IIBBBBB', body)
            if depth != 8 or inter != 0:
                raise ValueError('只支持 8 位、非隔行的 PNG（请用常见 PNG 格式）')
        elif kind == b'PLTE':
            palette = body
        elif kind == b'tRNS':
            trns = body
        elif kind == b'IDAT':
            idat.extend(body)
        elif kind == b'IEND':
            break
    if not w or not h or w * h > 64 * 1024 * 1024:
        raise ValueError('PNG 尺寸异常')
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ctype)
    if not channels:
        raise ValueError('不支持的 PNG 颜色类型')
    raw = zlib.decompress(bytes(idat))
    stride = w * channels
    prev = bytearray(stride)
    rows, pos = [], 0
    for _ in range(h):
        ft = raw[pos]
        line = bytearray(raw[pos + 1:pos + 1 + stride])
        pos += 1 + stride
        for i in range(stride):
            a = line[i - channels] if i >= channels else 0
            b = prev[i]
            c = prev[i - channels] if i >= channels else 0
            if ft == 1: line[i] = (line[i] + a) & 0xFF
            elif ft == 2: line[i] = (line[i] + b) & 0xFF
            elif ft == 3: line[i] = (line[i] + (a + b) // 2) & 0xFF
            elif ft == 4: line[i] = (line[i] + _paeth(a, b, c)) & 0xFF
            elif ft != 0:
                raise ValueError('PNG 过滤器不支持')
        rows.append(line)
        prev = line
    rgba = bytearray(w * h * 4)
    for y, line in enumerate(rows):
        for x in range(w):
            i, o = x * channels, (y * w + x) * 4
            if ctype == 6:
                rgba[o:o + 4] = line[i:i + 4]
            elif ctype == 2:
                rgba[o:o + 4] = line[i:i + 3] + b'\xff'
            elif ctype == 0:
                rgba[o:o + 4] = bytes([line[i], line[i], line[i], 0xFF])
            elif ctype == 4:
                rgba[o:o + 4] = bytes([line[i], line[i], line[i], line[i + 1]])
            else:
                idx = line[i]
                if palette is None or 3 * idx + 3 > len(palette):
                    raise ValueError('PNG 调色板缺失')
                rgba[o:o + 3] = palette[3 * idx:3 * idx + 3]
                rgba[o + 3] = trns[idx] if trns and idx < len(trns) else 0xFF
    return w, h, bytes(rgba)


def _resize(rgba, sw, sh, dw, dh):
    """双线性缩放，输出 RGBA。"""
    if (sw, sh) == (dw, dh):
        return rgba
    out = bytearray(dw * dh * 4)
    for y in range(dh):
        sy = (y + 0.5) * sh / dh - 0.5
        y0, y1 = max(0, int(sy)), min(sh - 1, int(sy) + 1)
        fy = max(0.0, min(1.0, sy - y0))
        for x in range(dw):
            sx = (x + 0.5) * sw / dw - 0.5
            x0, x1 = max(0, int(sx)), min(sw - 1, int(sx) + 1)
            fx = max(0.0, min(1.0, sx - x0))
            o = (y * dw + x) * 4
            for c in range(4):
                a = rgba[(y0 * sw + x0) * 4 + c] * (1 - fx) + rgba[(y0 * sw + x1) * 4 + c] * fx
                b = rgba[(y1 * sw + x0) * 4 + c] * (1 - fx) + rgba[(y1 * sw + x1) * 4 + c] * fx
                out[o + c] = int(a * (1 - fy) + b * fy)
    return bytes(out)


def rgba_to_bgra(rgba):
    out = bytearray(len(rgba))
    for i in range(0, len(rgba), 4):
        out[i:i + 4] = rgba[i + 2], rgba[i + 1], rgba[i], rgba[i + 3]
    return bytes(out)


def bgra_to_rgba(bgra):
    out = bytearray(len(bgra))
    for i in range(0, len(bgra), 4):
        out[i:i + 4] = bgra[i + 2], bgra[i + 1], bgra[i], bgra[i + 3]
    return bytes(out)


# ---------------- 图标元数据 ----------------
def load_index():
    p = paths.icons_index()
    if not os.path.isfile(p):
        return []
    items = json.load(open(p, encoding='utf-8'))['items']
    for i in items:
        i['cn'] = taxonomy.icon_label(i['id'])
        i['cn_en'] = label_mod.humanize(i['name'])
    return items


def icon_map():
    return {i['id']: i for i in load_index()}


def icon_info(uexp):
    fmt = uexp.find(FMT)
    if fmt < 0:
        return None
    w = struct.unpack('<i', uexp[fmt - 16:fmt - 12])[0]
    h = struct.unpack('<i', uexp[fmt - 12:fmt - 8])[0]
    size = w * h * 4
    if not (0 < w <= 4096 and 0 < h <= 4096 and len(uexp) >= size):
        return None
    return dict(w=w, h=h, size=size, fmt_off=fmt, uexp_len=len(uexp),
                pixel_start=len(uexp) - size)


def read_uexp(icon_id):
    p = paths.icon_uexp(icon_id)
    if not os.path.isfile(p):
        raise ValueError('内置图标资产缺失：' + icon_id)
    return open(p, 'rb').read()


def prepare():
    """开发期：从原版 pak 抽出全部图标，生成 PNG 预览与索引。"""
    repak = paths.repak()
    pak = paths.VANILLA_PAK
    if not os.path.isfile(pak):
        raise RuntimeError('找不到原版 pak：' + pak)
    list_file = os.path.join(paths.APP_DIR, 'out', '_vanilla_list.txt')
    if not os.path.isfile(list_file):
        r = subprocess.run([repak, '--aes-key', paths.AES_KEY, 'list', pak],
                           capture_output=True, timeout=180)
        lines = (r.stdout or b'').decode('utf-8', 'replace').splitlines()
    else:
        lines = open(list_file, encoding='utf-8', errors='replace').read().splitlines()
    assets = []
    for line in lines:
        line = line.strip()
        if not line.endswith('.uasset'):
            continue
        if ('CharacterIcons/PheromonePanel/' in line
                or ('ChamberAssignment' in line and 'Icon' in line)):
            assets.append(line[:-7])
    os.makedirs(paths.asset('icons', 'uexp'), exist_ok=True)
    os.makedirs(paths.asset('icons', 'png'), exist_ok=True)
    items, skipped = [], []
    for rel in sorted(set(assets)):
        r = subprocess.run([repak, '--aes-key', paths.AES_KEY, 'get', pak, rel + '.uexp'],
                           capture_output=True, timeout=60)
        uexp = r.stdout
        info = icon_info(uexp)
        if not info:
            skipped.append(rel)
            continue
        iid = rel.split('/')[-1]
        with open(paths.icon_uexp(iid), 'wb') as f:
            f.write(uexp)
        pixels = uexp[info['pixel_start']:]
        write_png(paths.icon_png(iid), info['w'], info['h'], bgra_to_rgba(pixels))
        cn = taxonomy.icon_label(iid)
        items.append(dict(id=iid, asset=rel, cn=cn, name=iid,
                          family=taxonomy.family_of(iid),
                          w=info['w'], h=info['h'], size=info['size'],
                          uexp_len=info['uexp_len'], set='pp' if 'PheromonePanel' in rel else 'chamber'))
    with open(paths.icons_index(), 'w', encoding='utf-8') as f:
        json.dump(dict(count=len(items), items=items), f, ensure_ascii=False, indent=1)
    return dict(count=len(items), skipped=skipped)


def apply_changes(changes, stage, log):
    """changes: {icon_id: {'from': 源图标id} 或 {'image': base64 PNG}}。"""
    idx = icon_map()
    written = []
    for iid, spec in (changes or {}).items():
        item = idx.get(iid)
        if not item:
            raise ValueError('未知图标：' + iid)
        target = read_uexp(iid)
        info = icon_info(target)
        if not info:
            raise ValueError('图标格式不支持（不是 B8G8R8A8）：' + iid)
        w, h = info['w'], info['h']
        if isinstance(spec, str):
            spec = {'from': spec}
        if not isinstance(spec, dict):
            raise ValueError(iid + ' 的图标设置无效')
        if spec.get('from'):
            src = read_uexp(spec['from'])
            si = icon_info(src)
            if not si:
                raise ValueError('源图标格式不支持：' + spec['from'])
            rgba = bgra_to_rgba(src[si['pixel_start']:])
            rgba = _resize(rgba, si['w'], si['h'], w, h)
            source = '官方图标 ' + spec['from']
        elif spec.get('image'):
            b64 = spec['image']
            if ',' in b64 and b64[:5] == 'data:':
                b64 = b64.split(',', 1)[1]
            try:
                sw, sh, rgba = decode_png(base64.b64decode(b64))
            except Exception as e:
                raise ValueError(iid + ' 自定义图片无法读取：' + str(e))
            rgba = _resize(rgba, sw, sh, w, h)
            source = f'自定义图片（{sw}×{sh} → {w}×{h}）'
        else:
            raise ValueError(iid + ' 没有指定新图标')
        new_pixels = rgba_to_bgra(rgba)
        if len(new_pixels) != info['size']:
            raise RuntimeError('图标像素长度异常，已中止')
        out_bytes = target[:info['pixel_start']] + new_pixels
        if len(out_bytes) != len(target):
            raise RuntimeError('图标 uexp 长度变化，已中止（会破坏资产结构）')
        rel = item['asset'] + '.uexp'
        out = os.path.join(stage, *rel.split('/'))
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, 'wb') as f:
            f.write(out_bytes)
        back = open(out, 'rb').read()
        if back[info['pixel_start']:] != new_pixels or len(back) != len(target):
            raise RuntimeError(iid + ' 图标回读校验失败')
        log.append(f'  图标 {item["cn"]}（{w}×{h}）：{source}，uexp 长度不变')
        written.append(dict(id=iid, asset=rel, source=source, size=len(out_bytes)))
    return written
