# -*- coding: utf-8 -*-
"""生成前的完整改动统计 + 风险评估（中英双语）。

页面必须先调用它，把结果原样展示给用户；用户确认后带 token 再调用 generate，
后端会重算 token，确保「看到的」与「真正生成的」是同一份改动。
v2.1 额外返回 reused：本次模组名是否与上一次生成/已有 pak 重名，供前端二次确认。
"""
import os
import time

from . import catalog as catalog_mod
from . import icons, installer, locres, paths
from .generator import (SCOPES, SCOPE_LABEL, SCOPE_LABEL_EN,
                        pak_filename, safe_name, token_of)

RISK_ORDER = {'danger': 0, 'warn': 1, 'info': 2}


def _risk(level, title, detail, title_en, detail_en):
    return dict(level=level, title=title, detail=detail,
                title_en=title_en, detail_en=detail_en)


def _reuse_info(mod_name):
    """同名 pak 是否已存在 / 上次是否用了同一个名字。"""
    cfg = paths.get_cfg()
    pak = pak_filename(mod_name)
    p = os.path.join(paths.OUT_DIR, pak)
    exists = os.path.isfile(p)
    last = cfg.get('last_mod_name')
    used = exists or (bool(last) and last == mod_name)
    info = dict(
        pak=pak, exists=exists,
        size=os.path.getsize(p) if exists else 0,
        mtime=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(p))) if exists else '',
        last_time=cfg.get('last_mod_time', ''),
        source='file' if exists else 'history',
    )
    return used, info


def build(payload, cat=None):
    mod_name = safe_name(payload.get('mod_name'))
    scope = payload.get('scope', 'both')
    if scope not in SCOPES:
        raise ValueError('生效模式无效')
    changes = payload.get('changes') or {}
    texts = payload.get('texts') or {}
    icon_changes = payload.get('icons') or {}
    if not (changes or texts or icon_changes):
        raise ValueError('还没有任何改动：请先在数值 / 文案 / 图标页填写内容')

    if cat is None:
        cat = catalog_mod.build()
    by_row = {c['row']: c for c in cat['creatures']}
    field_map = {f['name']: f for f in cat['fields']}
    text_items, text_by_id = locres.catalog()
    icon_idx = icons.icon_map()

    sections, risks = [], []

    # ---------- 数值 ----------
    rows, n_fields = [], 0
    for row, fields in changes.items():
        c = by_row.get(row)
        if not c:
            raise ValueError('未知生物行：' + row)
        for field, new in (fields or {}).items():
            meta = field_map.get(field)
            if not meta:
                raise ValueError('未知字段：' + field)
            old = c['values'].get(field)
            if old is None or (isinstance(old, (int, float)) and isinstance(new, (int, float))
                               and abs(float(old) - float(new)) < 1e-9):
                continue
            rows.append(dict(label=f"{c['cn']} · {meta['label']}",
                             label_en=f"{c['cn_en']} · {meta['label_en']}",
                             old=str(old), new=str(new), note=row))
            n_fields += 1
            if meta['group'] == '防御' and field != 'Armour' and isinstance(new, (int, float)) \
                    and not (0 <= float(new) <= 1):
                risks.append(_risk('warn', '抗性数值超出常规范围',
                                   f'{c["cn"]} 的「{meta["label"]}」= {new}（一般填 0 ~ 1）。'
                                   '数值异常通常不会让游戏崩溃，但可能让单位几乎无敌或瞬死。',
                                   'Resistance out of range',
                                   f'{c["cn_en"]} → {meta["label_en"]} = {new} (normally 0–1). '
                                   'Won\'t crash the game but may make a unit nearly invincible.'))
            if field == 'Speed' and isinstance(new, (int, float)) and float(new) > 2000:
                risks.append(_risk('warn', '移动速度极高',
                                   f'{c["cn"]} 移速 {new}，可能导致单位穿墙、寻路异常。',
                                   'Extreme move speed',
                                   f'{c["cn_en"]} speed {new} may cause pathing / clipping issues.'))
    if rows:
        sections.append(dict(id='stats', title='生物数值', title_en='Creature Stats',
                             count=len(rows), rows=rows,
                             note=f'涉及 {len(changes)} 个生物行 · {len(SCOPES[scope])} 张数据表',
                             note_en=f'{len(changes)} creatures · {len(SCOPES[scope])} tables'))
        risks.append(_risk('info', '数值改写是等长的',
                           '只改数据表里的值，.uasset/.uexp 长度不变，不会触发偏移错位；删掉 pak 即还原。',
                           'Stats edits keep file length',
                           'Only values change; asset size stays identical. Delete the pak to revert.'))

    # ---------- 文案 ----------
    trows = []
    for tid, new in texts.items():
        item = text_by_id.get(tid)
        if not item:
            raise ValueError('未知文本条目：' + tid)
        if new == item['value']:
            continue
        shared = [k for k in item['shared'] if k != item['key']]
        note = '；'.join(shared[:3]) if shared else ''
        trows.append(dict(label=item['label'], label_en=item.get('label_en', item['label']),
                          old=item['value'], new=str(new),
                          note=('共用同一段文字，会一起变：' + note) if note else item['key'],
                          note_en=('Shared with: ' + note) if note else item['key']))
        if '{' in item['value'] and '{' not in str(new):
            risks.append(_risk('warn', '文本里的占位符被删掉了',
                               f'「{item["label"]}」原文含 {{参数}} 占位符，新文本没有了。'
                               '游戏拼接数值时可能显示异常（一般不会崩溃，但不建议）。',
                               'Placeholder removed',
                               f'"{item["label_en"]}" originally contained a {{parameter}} placeholder. '
                               'Values may render incorrectly.'))
        if len(shared):
            risks.append(_risk('warn', '一段文字被多个界面共用',
                               f'「{item["label"]}」同时是：{item["label"]} / {note}。'
                               '改这一处，这些界面会一起变化。',
                               'Text shared by several screens',
                               f'"{item["label_en"]}" is also used by: {note}. All of them will change.'))
        if '\n' in str(new):
            risks.append(_risk('warn', '新文本含换行',
                               f'「{item["label"]}」含换行符，部分 UI 文本框可能显示不完整。',
                               'New text contains a line break',
                               f'"{item["label_en"]}" contains a line break; some UI boxes may clip it.'))
        if len(str(new)) > 240:
            risks.append(_risk('warn', '文本很长',
                               f'「{item["label"]}」有 {len(str(new))} 字，过长的文本可能溢出 UI 文本框。',
                               'Text is very long',
                               f'"{item["label_en"]}" is {len(str(new))} characters; may overflow the UI.'))
    if trows:
        sections.append(dict(id='texts',
                             title='中文文案（名称 / 介绍 / 菜单 / 致谢）',
                             title_en='Game Text (names / descriptions / menus / credits)',
                             count=len(trows), rows=trows,
                             note='写入 .locres 中文文本，游戏内所有中文界面都会读到',
                             note_en='Writes .locres; all Chinese UI reads it'))
        delta = sum(len(r['new']) - len(r['old']) for r in trows)
        risks.append(_risk('warn', '文本长度会变化（低风险，已验证）',
                           f'文案合计长度变化 {delta:+d} 字。locres 是流式格式，工具会重建翻译区并逐条自检；'
                           '这类改动在此前多个 mod 上验证可正常进游戏。'
                           '万一出现启动崩溃或文字错乱，删掉本 pak 即可完全还原。',
                           'Text length changes (low risk, verified)',
                           f'Total length change {delta:+d} chars. The locres is rebuilt stream-wise and '
                           'self-checked. If anything looks wrong, delete the pak to revert.'))

    # ---------- 图标 ----------
    irows = []
    for iid, spec in icon_changes.items():
        item = icon_idx.get(iid)
        if not item:
            raise ValueError('未知图标：' + iid)
        if isinstance(spec, str):
            spec = {'from': spec}
        if spec.get('from'):
            src = icon_idx.get(spec['from'])
            desc = '换成官方图标「' + (src['cn'] if src else spec['from']) + '」'
            desc_en = 'Use official icon "' + (src['cn_en'] if src else spec['from']) + '"'
        elif spec.get('image'):
            desc = '换成自己上传的图片（自动缩放到 ' + f"{item['w']}×{item['h']}" + '）'
            desc_en = f'Custom image (resized to {item["w"]}×{item["h"]})'
            risks.append(_risk('warn', '自定义图片会被缩放',
                               f'游戏图标固定 {item["w"]}×{item["h"]} 像素，上传的图会被拉伸/压缩，'
                               '可能变形。建议用接近正方形、主体居中的透明 PNG。',
                               'Custom image will be resized',
                               f'Icon is fixed at {item["w"]}×{item["h"]}px; a non-square image may look stretched.'))
        else:
            raise ValueError(iid + ' 没有指定新图标')
        irows.append(dict(label=item['cn'], label_en=item.get('cn_en', iid),
                          old='原版图标', old_en='Vanilla icon',
                          new=desc, new_en=desc_en, note=item['name']))
    if irows:
        sections.append(dict(id='icons', title='生物图标', title_en='Creature Icons',
                             count=len(irows), rows=irows,
                             note='只替换贴图末尾的像素数据',
                             note_en='Only the trailing pixel data is replaced'))
        risks.append(_risk('info', '图标替换不改结构',
                           '所有官方图标尺寸一致；工具只覆盖 .uexp 末尾的像素区，文件长度不变，'
                           '.uasset 里的 SerialSize 保持匹配。不会影响游戏加载。',
                           'Icon swap does not change structure',
                           'Only trailing pixel bytes are overwritten; file size and SerialSize stay valid.'))
        risks.append(_risk('warn', '图标是全局共用的',
                           '同一张贴图在多个界面（信息素面板、巢穴分配、图鉴）都会用到，'
                           '替换后所有引用它的地方一起变，不是只改某一个生物。',
                           'Icons are shared globally',
                           'The texture is used by several screens; all of them change together.'))

    # ---------- 同名覆盖 ----------
    reused, reuse = _reuse_info(mod_name)
    if reused:
        where = (f'（{reuse["size"] // 1024} KB，生成于 {reuse["mtime"]}）'
                 if reuse['exists'] else f'（上次生成于 {reuse["last_time"]}）')
        risks.append(_risk('warn', '与上次生成同名，会覆盖旧 pak',
                           f'模组名「{mod_name}」上次已经用过 {where}。继续生成会覆盖 '
                           f'{reuse["pak"]}；旧 pak 不会保留备份。想同时保留两个 mod，请换个名字。',
                           'Same name as last build — old pak will be overwritten',
                           f'"{mod_name}" was used before. Generating again overwrites {reuse["pak"]}. '
                           'Rename the mod if you want to keep both.'))

    # ---------- 环境 ----------
    issues, info = paths.check_environment()
    for s in issues:
        risks.append(_risk('danger', '环境不完整', s, 'Incomplete environment', s))
    for cf in installer.conflicts():
        risks.append(_risk('danger', '检测到同表冲突 pak',
                           f'Paks 目录里还有「{cf}」，它也修改了 CreatureStats。'
                           '两个 pak 会互相覆盖，最终只有一个生效。建议先把它移出 Paks 目录。',
                           'Conflicting pak detected',
                           f'"{cf}" also edits CreatureStats. Only one pak will win; move it out of Paks.'))
    running = installer.game_running()
    if running:
        risks.append(_risk('warn', '游戏正在运行',
                           f'检测到 {running}。生成 pak 不受影响，但「安装到游戏」会失败，请先关闭游戏。',
                           'Game is running',
                           f'{running} is running. Generation works, but install will fail until you close it.'))

    risks.sort(key=lambda r: RISK_ORDER.get(r['level'], 9))

    # 预计产物
    files = []
    for t in SCOPES[scope]:
        files.append(paths.TABLE_PATHS[t] + '.uasset')
        files.append(paths.TABLE_PATHS[t] + '.uexp')
    for kind in {text_by_id[t]['kind'] for t in texts if t in text_by_id and texts[t] != text_by_id[t]['value']}:
        files.append(paths.LOCRES_OUT[kind])
    for iid in icon_changes:
        if iid in icon_idx:
            files.append(icon_idx[iid]['asset'] + '.uexp')

    counts = dict(stats=n_fields, texts=len(trows), icons=len(irows),
                  total=n_fields + len(trows) + len(irows))
    return dict(
        ok=True, mod_name=mod_name, pak_name=pak_filename(mod_name),
        scope=scope, scope_label=SCOPE_LABEL[scope],
        scope_label_en=SCOPE_LABEL_EN[scope],
        counts=counts, sections=sections, risks=risks, files=files,
        token=token_of(payload), reused=reused, reused_info=reuse,
        danger=sum(1 for r in risks if r['level'] == 'danger'),
        warn=sum(1 for r in risks if r['level'] == 'warn'),
    )
