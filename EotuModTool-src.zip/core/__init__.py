# -*- coding: utf-8 -*-
"""Eotu Mod Tool core package.

把 hardmode 里的成熟数据表读写器挂到 sys.path，保证任何入口
（HTTP 服务、命令行测试、双击启动）都能 import eotu_stats / probe。
"""
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_HARDMODE = os.path.join(_ROOT, 'mods', 'hardmode')
if _HARDMODE not in sys.path:
    sys.path.insert(0, _HARDMODE)
