# -*- coding: utf-8 -*-
"""locres 中文文本读写：按键精确替换 + 结构自检。

实测格式：头 33 字节（@17 存 int64 = 翻译区起点偏移），命名空间区，
翻译区 = [int32 条目数] + 条目×([FString][uint32 源串哈希])。
条目靠顺序解析、没有逐条绝对偏移，因此改长改短都安全；
命名空间区不动，所以头里的偏移也不变。
"""
import os
import struct

from . import labels as label_mod
from . import paths

HEADER_LEN = 33
STR_OFFSET_POS = 17

# 可编辑文本分组：把游戏里散落的键整理成页面上能看懂的几类
GROUPS = [
    dict(id='creature_name', label='生物名称', label_en='Creature Names',
         hint='图鉴/卡片上的名字，改短一点比较保险', hint_en='Name on the card / encyclopedia'),
    dict(id='creature_desc', label='生物介绍', label_en='Descriptions',
         hint='图鉴里的百科描述（ShortDescription）', hint_en='Encyclopedia description'),
    dict(id='level3', label='3 级加成说明', label_en='Level 3 Bonuses',
         hint='升级到 3 级时显示的那句说明', hint_en='Shown at level 3'),
    dict(id='ability', label='能力标签', label_en='Ability Labels',
         hint='「能力：xxx」这类短标签，多处共用', hint_en='Short ability tags, shared'),
    dict(id='menu', label='菜单名字', label_en='Menu Labels',
         hint='主菜单、街机菜单、游戏内菜单按钮文字', hint_en='Main / arcade / in-game menus'),
    dict(id='credits', label='致谢内容', label_en='Credits',
         hint='鸣谢页的文字，可写自己的模组介绍', hint_en='Credits page, good for your mod intro'),
]

MENU_PREFIXES = ('MainMenu', 'PlayMenu', 'InGameMenu', 'Arcade', 'Tutorial', 'Back',
                 'Settings', 'CreditsTitle', 'Quit', 'Continue', 'NewGame', 'LoadGame',
                 'Options', 'Pause', 'Resume', 'Exit')
MENU_KEYS = {
    'MainMenu', 'MainMenuPlayOption', 'MainMenuCredits', 'MainMenuSettings',
    'CreditsTitle', 'Arcade', 'Tutorial', 'Back', 'InGameMenuTitle',
    'InGameMenuQuitToMainMenu', 'PlayMenuSkirmishDesc', 'PlayMenuFreeplayDesc',
}
CREDITS_KEYS = {
    'CreditsOurArmy', 'CreditsSubstanceSharers', 'CreditsFollowingResources',
    'CreditsTitle', 'MainMenuCredits', 'CreditsLocalisation', 'CreditsVarious',
    'CreditsVoiceActors', 'CreditsMissionNarrator', 'CreditsLeadDevelopers',
    'CreditsCharacterArtists', 'CreditsCommManager', 'CommTestingFocusCredits',
}

# 给常见键一个更友好的中文标签
LABELS = {
    'MainMenu': '主菜单按钮', 'MainMenuPlayOption': '「开始」按钮',
    'MainMenuCredits': '「鸣谢」按钮', 'MainMenuSettings': '「设置」按钮',
    'CreditsTitle': '鸣谢页标题 / 鸣谢按钮',
    'Arcade': '街机模式', 'Tutorial': '教程按钮', 'Back': '返回按钮',
    'InGameMenuTitle': '游戏内菜单标题', 'InGameMenuQuitToMainMenu': '退出到主菜单',
    'PlayMenuSkirmishDesc': '遭遇战说明', 'PlayMenuFreeplayDesc': '自由模式说明',
    'CreditsOurArmy': '致谢 · 音效团队', 'CreditsSubstanceSharers': '致谢 · 素材分享',
    'CreditsFollowingResources': '致谢 · 环境原画',
    'CreditsLocalisation': '致谢 · 本地化', 'CreditsVarious': '致谢 · 技术支持',
    'CreditsVoiceActors': '致谢 · 配音演员', 'CreditsMissionNarrator': '致谢 · 旁白',
    'CreditsLeadDevelopers': '致谢 · 主程序', 'CreditsCharacterArtists': '致谢 · 角色美术',
    'CreditsCommManager': '致谢 · 社区经理', 'CommTestingFocusCredits': '致谢 · 测试小组',
}


def _fstr_read(buf, p):
    ln, = struct.unpack_from('<i', buf, p)
    if ln < 0:
        n = (-ln) * 2
        return buf[p + 4:p + 4 + n].decode('utf-16-le', 'replace').rstrip('\x00'), p + 4 + n, True
    if ln > 0:
        return buf[p + 4:p + 4 + ln].decode('utf-8', 'replace').rstrip('\x00'), p + 4 + ln, False
    return '', p + 4, False


def _fstr_build(text, utf16):
    if utf16 or any(ord(c) > 127 for c in text):
        b = text.encode('utf-16-le') + b'\x00\x00'
        return struct.pack('<i', -(len(text) + 1)) + b
    b = text.encode('utf-8') + b'\x00'
    return struct.pack('<i', len(text) + 1) + b


class LocRes:
    def __init__(self, path):
        self.path = path
        self.raw = open(path, 'rb').read()
        self._parse()

    def _parse(self):
        raw = self.raw
        if len(raw) < HEADER_LEN + 8:
            raise ValueError('locres 文件太短')
        self.str_offset, = struct.unpack_from('<q', raw, STR_OFFSET_POS)
        if not (HEADER_LEN <= self.str_offset < len(raw)):
            raise ValueError('locres 翻译区偏移异常')
        self.header = raw[:self.str_offset]
        p = self.str_offset
        self.count, = struct.unpack_from('<i', raw, p)
        p += 4
        if not (0 < self.count < 200000):
            raise ValueError('locres 条目数异常')
        self.entries = []  # (FString bytes, hash bytes, utf16 flag)
        for _ in range(self.count):
            start = p
            ln, = struct.unpack_from('<i', raw, p)
            if ln < 0:
                n = (-ln) * 2
                utf16 = True
            elif ln > 0:
                n = ln
                utf16 = False
            else:
                n, utf16 = 0, False
            if p + 8 + n > len(raw):
                raise ValueError('locres 翻译区被截断')
            p += 4 + n
            self.entries.append((raw[start:p], raw[p:p + 4], utf16))
            p += 4
        if p != len(raw):
            raise ValueError('locres 尾部有多余数据，格式与预期不符')
        self._parse_namespaces()

    def _parse_namespaces(self):
        raw, end = self.raw, self.str_offset
        p, self.keys = HEADER_LEN, []  # (ns, key, index)
        while p < end:
            p += 4  # namespace hash
            ns, p, _ = _fstr_read(raw, p)
            cnt, = struct.unpack_from('<i', raw, p)
            p += 4
            for _ in range(cnt):
                p += 4  # key hash
                key, p, _ = _fstr_read(raw, p)
                p += 4  # source string hash
                idx, = struct.unpack_from('<i', raw, p)
                p += 4
                self.keys.append((ns, key, idx))
        if p != end:
            raise ValueError('locres 命名空间区长度异常')

    def value(self, index):
        b, _, utf16 = self.entries[index]
        ln, = struct.unpack_from('<i', b, 0)
        if ln < 0:
            return b[4:4 + (-ln) * 2].decode('utf-16-le', 'replace').rstrip('\x00')
        return b[4:4 + ln].decode('utf-8', 'replace').rstrip('\x00')

    def shared(self, index):
        """同一段译文被哪些键共用（改一处会一起变）。"""
        return [k for ns, k, i in self.keys if i == index]

    def build(self, overrides):
        """overrides: {index: 新文本} -> 新文件 bytes，并做完整自检。"""
        out = [self.header, struct.pack('<i', self.count)]
        for i, (blob, hash_b, utf16) in enumerate(self.entries):
            if i in overrides:
                out.append(_fstr_build(overrides[i], utf16))
            else:
                out.append(blob)
            out.append(hash_b)
        data = b''.join(out)
        # 自检：能完整解析、条目数一致、未改动的译文一字不差
        chk = LocRes.__new__(LocRes)
        chk.path = self.path
        chk.raw = data
        chk._parse()
        if chk.count != self.count or len(chk.entries) != len(self.entries):
            raise RuntimeError('locres 重建后条目数不一致')
        for i in range(self.count):
            if i not in overrides and chk.value(i) != self.value(i):
                raise RuntimeError(f'locres 重建后第 {i} 条译文被破坏')
            if i in overrides and chk.value(i) != overrides[i]:
                raise RuntimeError(f'locres 重建后第 {i} 条新文本不一致')
        return data


def _group_of(ns, key):
    if ns == 'CreatureInformation':
        if key.endswith('_DisplayName'):
            return 'creature_name'
        if key.endswith('_ShortDescription'):
            return 'creature_desc'
        if key.endswith('_Level3Description'):
            return 'level3'
        if key.startswith('CreatureInfo_Ability_'):
            return 'ability'
        return None
    if key in CREDITS_KEYS or (key.startswith('Credits') and key not in MENU_KEYS):
        return 'credits'
    if key in MENU_KEYS or key.startswith(MENU_PREFIXES) or ns.endswith('MainMenu'):
        return 'menu'
    return None


def _labels(key, group, value, resolver=None):
    """返回 (中文标题, 英文标题)；resolver 由 catalog 提供，负责把物种名翻成中文。"""
    return label_mod.label_pair(key, group, value, resolver)


def catalog():
    """返回可编辑文本条目（前端渲染 + 生成时校验都用它）。"""
    from . import catalog as catalog_mod  # 延迟导入，避免与 catalog 形成初始化环
    resolver = catalog_mod.cn_for_base
    result, by_id = [], {}
    for kind in ('data', 'ui'):
        path = paths.locres_src(kind)
        if not os.path.isfile(path):
            continue
        lr = LocRes(path)
        seen = set()
        for ns, key, idx in lr.keys:
            group = _group_of(ns, key)
            if not group or idx in seen:
                continue
            seen.add(idx)
            tid = f'{kind}::{ns}::{key}'
            val = lr.value(idx)
            zh, en = _labels(key, group, val, resolver)
            item = dict(id=tid, kind=kind, ns=ns, key=key, index=idx,
                        group=group, label=zh, label_en=en, value=val,
                        length=len(val), shared=lr.shared(idx),
                        path=paths.LOCRES_OUT[kind])
            result.append(item)
            by_id[tid] = item
    return result, by_id


def apply_changes(changes, stage, log):
    """changes: {id: 新文本}。按 kind 分组写入 stage，返回写入文件列表。"""
    items, by_id = catalog()
    grouped = {}
    for tid, new in (changes or {}).items():
        item = by_id.get(tid)
        if not item:
            raise ValueError('未知文本条目：' + tid)
        if not isinstance(new, str):
            raise ValueError(tid + ' 需要文字')
        if new == item['value']:
            continue
        if '\x00' in new:
            raise ValueError(tid + ' 不能包含空字符')
        grouped.setdefault(item['kind'], {})[item['index']] = new
    written = []
    for kind, overrides in grouped.items():
        lr = LocRes(paths.locres_src(kind))
        data = lr.build(overrides)
        out = os.path.join(stage, *paths.LOCRES_OUT[kind].split('/'))
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, 'wb') as f:
            f.write(data)
        # 回读校验（从写出的文件再解析一次）
        back = LocRes(out)
        for idx, want in overrides.items():
            if back.value(idx) != want:
                raise RuntimeError(f'{kind} 文本回读不一致：第 {idx} 条')
        log.append(f'  {kind} locres：替换 {len(overrides)} 段文字，'
                   f'{len(lr.raw)} → {len(data)} 字节（流式格式自检通过）')
        written.append(dict(kind=kind, path=out, count=len(overrides),
                            old_size=len(lr.raw), new_size=len(data)))
    return written
