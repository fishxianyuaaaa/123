# -*- coding: utf-8 -*-
"""从游戏自带中文 locres 里提取生物显示名。

locres 结构（本作实测）：33 字节头 → 若干命名空间节
  [uint32 hash][FString 节名][int32 条目数]
    × [uint32 hash][FString key][uint32 hash][int32 翻译序号]
→ 翻译区 [int32 总数] × ([FString 值][int32 hash])
"""
import struct


def _fstr(buf, p):
    ln, = struct.unpack('<i', buf[p:p + 4])
    if ln < 0:
        return buf[p + 4:p + 4 + (-ln) * 2].decode('utf-16-le', 'replace').rstrip('\x00'), p + 4 + (-ln) * 2
    if ln > 0:
        return buf[p + 4:p + 4 + ln].decode('utf-8', 'replace').rstrip('\x00'), p + 4 + ln
    return '', p + 4


def _find_translations(d):
    """找能一路精确走到 EOF 的翻译区起点。"""
    for cand in range(0, len(d) - 4):
        cnt, = struct.unpack('<i', d[cand:cand + 4])
        if not (100 <= cnt <= 100000):
            continue
        q, vals = cand + 4, []
        try:
            while q + 4 <= len(d):
                s, q2 = _fstr(d, q)
                q = q2 + 4
                vals.append(s)
                if len(vals) > cnt:
                    break
            if q == len(d) and len(vals) == cnt:
                return cand, vals
        except Exception:
            continue
    return None, []


def display_names(path):
    """返回 {英文标识: 中文显示名}，例如 {'BlackAnt': '黑蚁兵蚁'}。"""
    d = open(path, 'rb').read()
    tp, strings = _find_translations(d)
    if tp is None:
        return {}
    out = {}
    p = 33
    while p < tp:
        try:
            struct.unpack('<I', d[p:p + 4])
            p += 4
            ns, p = _fstr(d, p)
            cnt, = struct.unpack('<i', d[p:p + 4])
            p += 4
            for _ in range(cnt):
                struct.unpack('<I', d[p:p + 4])
                p += 4
                key, p = _fstr(d, p)
                struct.unpack('<I', d[p:p + 4])
                p += 4
                idx, = struct.unpack('<i', d[p:p + 4])
                p += 4
                if ns == 'CreatureInformation' and key.endswith('_DisplayName') and 0 <= idx < len(strings):
                    token = key[len('CreatureInfo_'):-len('_DisplayName')]
                    if token:
                        out[token] = strings[idx]
        except Exception:
            break
    return out
