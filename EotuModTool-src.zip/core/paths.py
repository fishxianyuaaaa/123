# -*- coding: utf-8 -*-
"""路径与资产定位。

v2 起工具自带一份原版资产（assets/），可以整包拷给别人的电脑用；
本机开发时若无内置资产，则回退到 mods/hardmode/src。
打包成 exe 后，只读资源在 sys._MEIPASS，输出/配置在 exe 所在目录。
"""
import json
import os
import sys

FROZEN = getattr(sys, 'frozen', False)
BUNDLE = getattr(sys, '_MEIPASS', None) or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUNDLE = os.path.abspath(BUNDLE)
HERE = BUNDLE
APP_DIR = os.path.dirname(os.path.abspath(sys.executable)) if FROZEN else BUNDLE

CFG_FILE = os.path.join(APP_DIR, 'config.json')
ASSETS = os.path.join(BUNDLE, 'assets')
WEB_DIR = os.path.join(BUNDLE, 'web')

OUT_DIR = os.path.join(APP_DIR, 'out')
STAGE_DIR = os.path.join(APP_DIR, 'stage')
PRESET_DIR = os.path.join(APP_DIR, 'presets')

AES_KEY = '0x6A438455002AFC0979AC5F59AE970FC2D2635EAEE796EA9C713A4B9D90B504DD'

TABLE_PATHS = {
    'CreatureStats': 'EotU/Content/Assets/Data/CreatureStats',
    'CreatureStats_Freeplay': 'EotU/Content/Assets/Data/FreeplayStats/CreatureStats_Freeplay',
}
LOCRES_OUT = {
    'data': 'EotU/Content/Localization/DataFiles/zh-Hans/DataFiles.locres',
    'ui': 'EotU/Content/Localization/UserInterface/zh-Hans/UserInterface.locres',
}
ICON_PREFIX = 'EotU/Content/UI/InGame/UIUpdate/CharacterIcons/PheromonePanel/'


def _load_cfg():
    try:
        with open(CFG_FILE, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_cfg(cfg):
    os.makedirs(APP_DIR, exist_ok=True)
    with open(CFG_FILE, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def get_cfg():
    """读取工具配置（游戏目录、语言、上次生成的模组名等）。"""
    return _load_cfg()


def set_cfg(**kw):
    """合并写入工具配置，不影响已有的其它键。"""
    cfg = _load_cfg()
    cfg.update(kw)
    _save_cfg(cfg)
    return cfg


def _is_game_root(d):
    return bool(d) and os.path.isdir(os.path.join(d, 'EotU', 'Content', 'Paks'))


def detect_game_root():
    cfg = _load_cfg().get('game_root')
    if _is_game_root(cfg):
        return os.path.abspath(cfg)
    d = APP_DIR
    for _ in range(4):
        if _is_game_root(d):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    for drive in 'CDEFGH':
        for rel in ('', 'Games', 'SteamLibrary/steamapps/common/EmpiresOfTheUndergrowth',
                    'Program Files (x86)/Steam/steamapps/common/EmpiresOfTheUndergrowth'):
            p = os.path.join(drive + ':', rel)
            if _is_game_root(p):
                return p
    return os.path.dirname(HERE)


ROOT = detect_game_root()
HARDMODE = os.path.join(ROOT, 'mods', 'hardmode')
SRC = os.path.join(HARDMODE, 'src')
PAKS_DIR = os.path.join(ROOT, 'EotU', 'Content', 'Paks')
VANILLA_PAK = os.path.join(PAKS_DIR, 'pakchunk0-WindowsNoEditor.pak')


def set_game_root(path):
    global ROOT, HARDMODE, SRC, PAKS_DIR, VANILLA_PAK
    path = os.path.abspath(path)
    if not _is_game_root(path):
        raise ValueError('这个目录里没有 EotU/Content/Paks，不是有效的游戏根目录')
    cfg = _load_cfg()
    cfg['game_root'] = path
    _save_cfg(cfg)
    ROOT = path
    HARDMODE = os.path.join(ROOT, 'mods', 'hardmode')
    SRC = os.path.join(HARDMODE, 'src')
    PAKS_DIR = os.path.join(ROOT, 'EotU', 'Content', 'Paks')
    VANILLA_PAK = os.path.join(PAKS_DIR, 'pakchunk0-WindowsNoEditor.pak')
    return path


def asset(*parts):
    return os.path.join(ASSETS, *parts)


def table_src(name, ext):
    p = asset('tables', name + '.' + ext)
    if os.path.isfile(p):
        return p
    return os.path.join(SRC, name + '.' + ext)


def locres_src(kind):
    fn = 'DataFiles_zh-Hans.locres' if kind == 'data' else 'UserInterface_zh-Hans.locres'
    p = asset('loc', fn)
    if os.path.isfile(p):
        return p
    return os.path.join(SRC, 'loc', fn)


def repak():
    p = asset('bin', 'repak.exe')
    if os.path.isfile(p):
        return p
    return os.path.join(HARDMODE, 'we_manual', 'tools', 'repak.exe')


def icons_index():
    return asset('icons', 'index.json')


def icon_uexp(icon_id):
    return asset('icons', 'uexp', icon_id + '.uexp')


def icon_png(icon_id):
    return asset('icons', 'png', icon_id + '.png')


# 让 hardmode 里成熟的数据表读写器可用（源码模式）
if not FROZEN and os.path.isdir(HARDMODE) and HARDMODE not in sys.path:
    sys.path.insert(0, HARDMODE)


def ensure_dirs():
    for d in (OUT_DIR, STAGE_DIR, PRESET_DIR):
        os.makedirs(d, exist_ok=True)


def check_environment():
    """返回 (问题列表, 信息字典)，页面顶部用它显示状态灯。"""
    issues, info = [], {}
    info['game_root'] = ROOT
    info['paks_dir'] = PAKS_DIR
    info['app_dir'] = APP_DIR
    info['bundled_assets'] = os.path.isdir(ASSETS)
    info['repak'] = repak()
    info['source'] = '内置资产' if os.path.isfile(asset('tables', 'CreatureStats.uexp')) else '开发目录'
    if not os.path.isdir(PAKS_DIR):
        issues.append('找不到游戏 Paks 目录：' + PAKS_DIR + '（可在「设置」里指定游戏根目录）')
    for name in TABLE_PATHS:
        for ext in ('uasset', 'uexp'):
            p = table_src(name, ext)
            if not os.path.isfile(p) or os.path.getsize(p) == 0:
                issues.append('缺少原始资产：' + name + '.' + ext)
    if not os.path.isfile(repak()):
        issues.append('找不到打包工具 repak.exe')
    for kind in ('data', 'ui'):
        if not os.path.isfile(locres_src(kind)):
            issues.append('缺少中文文本：' + os.path.basename(locres_src(kind)))
    info['icons'] = os.path.isfile(icons_index())
    info['logo'] = os.path.isfile(asset('logo.png'))
    return issues, info
