# -*- coding: utf-8 -*-
"""安装 / 冲突检测 / 预设管理。"""
import glob
import hashlib
import json
import os
import shutil
import subprocess
import time

from . import paths
from .generator import safe_name

OWN_PREFIX = 'zzz_EotU_EothTool_'


def _decode(b):
    """Windows 中文版 tasklist 输出是 GBK，不能用默认 utf-8 解码。"""
    if isinstance(b, str):
        return b
    for enc in ('utf-8', 'gbk', 'cp936', 'latin-1'):
        try:
            return (b or b'').decode(enc)
        except UnicodeDecodeError:
            continue
    return (b or b'').decode('utf-8', 'replace')


def _md5(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def game_running():
    for exe in ('EotU-Win64-Shipping.exe', 'EotU.exe'):
        try:
            r = subprocess.run(['tasklist', '/FI', f'IMAGENAME eq {exe}', '/FO', 'CSV', '/NH'],
                               capture_output=True, timeout=10)
            if exe.lower() in _decode(r.stdout).lower():
                return exe
        except Exception:
            continue
    return None


def _pak_has(path, needle):
    try:
        r = subprocess.run([paths.repak(), 'list', path], capture_output=True, timeout=30)
        return needle.lower() in _decode(r.stdout).lower()
    except Exception:
        return False


def conflicts():
    """列出 Paks 里同样改了 CreatureStats / locres / 图标的其它 mod pak。"""
    out = []
    if not os.path.isdir(paths.PAKS_DIR):
        return out
    needles = ('CreatureStats', 'DataFiles.locres', 'UserInterface.locres')
    for p in sorted(glob.glob(os.path.join(paths.PAKS_DIR, 'zzz_*.pak'))):
        name = os.path.basename(p)
        if name.startswith(OWN_PREFIX):
            continue
        if any(_pak_has(p, n) for n in needles):
            out.append(name)
    return out


def installed_own():
    if not os.path.isdir(paths.PAKS_DIR):
        return []
    return [os.path.basename(p) for p in sorted(glob.glob(os.path.join(paths.PAKS_DIR, OWN_PREFIX + '*_P.pak')))]


def install(pak_path):
    pak_path = os.path.abspath(pak_path)
    out_dir = os.path.abspath(paths.OUT_DIR)
    if os.path.commonpath([pak_path, out_dir]) != out_dir:
        raise RuntimeError('只能安装本工具 out 目录里生成的 pak')
    if not os.path.isfile(pak_path):
        raise RuntimeError('找不到待安装的 pak：' + pak_path)
    if not os.path.isdir(paths.PAKS_DIR):
        raise RuntimeError('找不到游戏 Paks 目录，请先在「设置」里指定游戏根目录')
    running = game_running()
    if running:
        raise RuntimeError(f'游戏正在运行（{running}），请先关闭游戏再安装')
    dst = os.path.join(paths.PAKS_DIR, os.path.basename(pak_path))
    if os.path.exists(dst):
        os.remove(dst)
    shutil.copyfile(pak_path, dst)
    if _md5(dst) != _md5(pak_path):
        raise RuntimeError('安装后校验失败（md5 不一致）')
    return dict(ok=True, dst=dst, size=os.path.getsize(dst), md5=_md5(dst),
                conflicts=conflicts())


def uninstall():
    removed = []
    for p in sorted(glob.glob(os.path.join(paths.PAKS_DIR, OWN_PREFIX + '*_P.pak'))):
        os.remove(p)
        removed.append(os.path.basename(p))
    return dict(ok=True, removed=removed)


# ---------------- 预设 ----------------
def _preset_path(name):
    return os.path.join(paths.PRESET_DIR, safe_name(name) + '.json')


def list_presets():
    out = []
    for p in sorted(glob.glob(os.path.join(paths.PRESET_DIR, '*.json'))):
        try:
            d = json.load(open(p, encoding='utf-8'))
            out.append(dict(name=d.get('name', os.path.basename(p)[:-5]),
                            mod_name=d.get('mod_name', ''),
                            scope=d.get('scope', 'both'),
                            count=(sum(len(v) for v in d.get('changes', {}).values())
                                   + len(d.get('texts', {})) + len(d.get('icons', {}))),
                            saved=d.get('saved', ''),
                            file=os.path.basename(p)))
        except Exception:
            continue
    return out


def save_preset(payload):
    name = safe_name(payload.get('name'))
    data = dict(name=name, mod_name=payload.get('mod_name', ''),
                scope=payload.get('scope', 'both'),
                note=payload.get('note', ''),
                changes=payload.get('changes', {}),
                texts=payload.get('texts', {}),
                icons=payload.get('icons', {}),
                saved=time.strftime('%Y-%m-%d %H:%M:%S'))
    if not (data['changes'] or data['texts'] or data['icons']):
        raise ValueError('预设里没有改动，先填几项再保存')
    paths.ensure_dirs()
    with open(_preset_path(name), 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return dict(ok=True, name=name)


def load_preset(name):
    p = _preset_path(name)
    if not os.path.isfile(p):
        raise RuntimeError('找不到预设：' + name)
    return json.load(open(p, encoding='utf-8'))
