# -*- coding: utf-8 -*-
"""生物分类与中文名：给 281 行生物和 80+ 个图标共用。"""
import re

FAMILIES = [
    dict(id='ants', label='蚂蚁与白蚁', label_en='Ants & Termites', icon='🐜',
         hint='玩家可孵化的蚁种，以及野外各种蚂蚁', hint_en='Playable ants and wild ant species'),
    dict(id='beetles', label='甲虫', label_en='Beetles', icon='🪲',
         hint='隐翅虫、虎甲、瓢虫、幼虫', hint_en='Rove beetles, tiger beetles, ladybirds, larvae'),
    dict(id='insects', label='其他昆虫', label_en='Other Insects', icon='🦗',
         hint='螳蛉、蝼蛄、蚜虫、蜂类、木蠹等', hint_en='Mantidflies, mole crickets, aphids, wasps'),
    dict(id='arachnids', label='蛛形类', label_en='Arachnids', icon='🕷️',
         hint='蜘蛛、鞭蛛、盲蛛、漏斗网蛛', hint_en='Spiders, whip spiders, harvestmen'),
    dict(id='others', label='其他生物', label_en='Other Creatures', icon='🦀',
         hint='寄居蟹、蜥蜴、鼠妇等', hint_en='Crabs, lizards, woodlice'),
    dict(id='special', label='特殊 / 占位', label_en='Special / Placeholder', icon='⚙️',
         hint='默认模板、攻击点、测试行等', hint_en='Default template, attack points, test rows'),
]

# 关键词 -> (family, 中文名)。按 key 长度倒序匹配，先命中先算。
SPECIES = {
    'LittleBlackAnt': ('ants', '小黑家蚁'), 'BigHeadedSuperSoldier': ('ants', '大头蚁超级兵'),
    'BigHeadedMajor': ('ants', '大头蚁大兵'), 'BigHeadedMinor': ('ants', '大头蚁小工'),
    'ExplodingTermite': ('ants', '爆炸白蚁'), 'ExplodingAnt': ('ants', '爆炸蚁'),
    'AfricanStinkAnt': ('ants', '非洲臭蚁'), 'SlaveMakerAnt': ('ants', '奴役蚁'),
    'LeafcutterSuperMajor': ('ants', '切叶蚁超大兵'), 'LeafcutterMajorTaunt': ('ants', '切叶蚁嘲讽大兵'),
    'LeafcutterMajorStun': ('ants', '切叶蚁眩晕大兵'), 'LeafcutterQueen': ('ants', '切叶蚁蚁后'),
    'LeafcutterMedia': ('ants', '切叶蚁中型'), 'LeafcutterMinor': ('ants', '切叶蚁小工'),
    'LeafcutterMinim': ('ants', '切叶蚁微型'), 'AttaCephalotes': ('ants', '切叶蚁'),
    'LeafCutter': ('ants', '切叶蚁'), 'GeneStealer': ('ants', '基因窃贼蚁'),
    'StinkAnt': ('ants', '臭蚁'), 'TrapJaw': ('ants', '大齿猛蚁'),
    'ScientistHat': ('special', '科学家帽子'), 'SausageFly': ('ants', '香肠蚁'),
    'FireAntPervasive': ('ants', '火蚁普及型'), 'FireAntVigorous': ('ants', '火蚁亢奋型'),
    'FireAntWorker': ('ants', '火蚁工蚁'), 'FireAntQueen': ('ants', '火蚁蚁后'),
    'FireAnt': ('ants', '火蚁'), 'WoodAntMelee': ('ants', '木蚁近战型'),
    'WoodAntA': ('ants', '木蚁快速型'), 'WoodAntB': ('ants', '木蚁远程型'),
    'WoodAnt': ('ants', '木蚁'), 'BlackAntQueen': ('ants', '黑蚁蚁后'),
    'BlackAntWorker': ('ants', '黑蚁工蚁'), 'BlackAnt': ('ants', '黑蚁'),
    'WorkerAnt': ('ants', '基因窃贼蚁工蚁'), 'MTWorkerAnt': ('ants', '繁殖蚁工蚁'),
    'SwarmQueen': ('ants', '群落蚁后'), 'RoyalGuard': ('ants', '皇家卫兵'),
    'Queen': ('ants', '蚁后'), 'TrapjawAnt': ('ants', '大齿猛蚁'),
    'MatabeleMedicFastResponder': ('ants', '马塔贝勒军医·快速反应'),
    'MatabeleMedicAnesthetist': ('ants', '马塔贝勒军医·麻醉师'),
    'MatabeleSoldier': ('ants', '马塔贝勒兵蚁'), 'Matabele': ('ants', '马塔贝勒蚁'),
    'DriverAnt': ('ants', '黑色行军蚁'), 'ArmyAntMajor': ('ants', '行军蚁大兵'),
    'ArmyAnt': ('ants', '行军蚁'), 'EcitonBurchelli': ('ants', '布氏行军蚁'),
    'FormicaSanguinea': ('ants', '血红林蚁'), 'FormicaFusca': ('ants', '黑蚁'),
    'MacrotermesBellicosus': ('ants', '大白蚁'), 'Macrotermes': ('ants', '大白蚁'),
    'Neocapritermes': ('ants', '新白蚁'), 'TermiteWorker': ('ants', '白蚁工蚁'),
    'TermiteSoldier': ('ants', '白蚁兵蚁'), 'TermiteMajorSoldier': ('ants', '大白蚁兵'),
    'TermiteColonyQueen': ('ants', '白蚁蚁后'), 'TermiteKing': ('ants', '白蚁蚁王'),
    'Termite': ('ants', '白蚁'), 'YungTermite': ('ants', '幼白蚁'),
    'BulletAnt': ('ants', '子弹蚁'), 'RedVelvetAnt': ('ants', '红绒蚁'),
    'SlaverAnt': ('ants', '掠奴蚁'), 'SwarmTermite': ('ants', '群落白蚁'),
    'BigHeadedAnt': ('ants', '大头蚁'), 'FormicaRufa': ('ants', '红林蚁'),
    'BeachTigerBeetle': ('beetles', '海滩虎甲'), 'SSTigerBeetle': ('beetles', '沙地虎甲'),
    'CheckeredBeetle': ('beetles', '棋盘甲'), 'RoveBeetleALarva': ('beetles', '隐翅虫幼虫A'),
    'RoveBeetleBLarva': ('beetles', '隐翅虫幼虫B'), 'RoveBeetleA': ('beetles', '绿色隐翅虫'),
    'RoveBeetleB': ('beetles', '蓝色隐翅虫'), 'DCHLarvae': ('beetles', '魔鬼隐翅虫幼虫'),
    'DCHAdult': ('beetles', '魔鬼隐翅虫成虫'), 'BTBLarvae': ('beetles', '虎甲幼虫'),
    'Ladybird': ('beetles', '瓢虫'), 'Beetle': ('beetles', '甲虫'),
    'WaspMantidfly': ('insects', '螳蛉'), 'MoleCricket': ('insects', '蝼蛄'),
    'Woodworm': ('insects', '木蠹幼虫'), 'Aphid': ('insects', '蚜虫'),
    'Wasp': ('insects', '黄蜂'), 'Mantid': ('insects', '螳螂'),
    'Cricket': ('insects', '蟋蟀'), 'Larva': ('insects', '幼虫'),
    'BeachWolfSpider': ('arachnids', '海滩狼蛛'), 'JumpingSpider': ('arachnids', '跳蛛'),
    'WhipSpiderling': ('arachnids', '小鞭蛛'), 'WhipSpider': ('arachnids', '鞭蛛'),
    'FunnelWeb': ('arachnids', '漏斗网蛛'), 'Harvestman': ('arachnids', '盲蛛'),
    'Spider': ('arachnids', '蜘蛛'), 'Scorpion': ('arachnids', '蝎子'),
    'LargeHermitCrab': ('others', '大型寄居蟹'), 'SmallHermitCrab': ('others', '小寄居蟹'),
    'HermitCrab': ('others', '寄居蟹'), 'Woodlouse': ('others', '鼠妇'),
    'SpinyDevil': ('others', '澳洲魔蜥'), 'Crab': ('others', '蟹'),
    'NianBeast': ('special', '年兽'), 'TestCreature': ('special', '测试生物'),
    'HarvestmansLeg': ('special', '盲蛛断腿'),
    # 图标库里 3 个此前没有中文名的条目
    'ScientistHand': ('special', '科学家的手'),
    'FormicaEreptor': ('ants', '掠奴蚁'), 'Formica_': ('ants', '林蚁'),
    'MyrmeciaEreptor': ('ants', '斗牛犬蚁'), 'Myrmecia_': ('ants', '斗牛犬蚁'),
}

_SPECIAL_EXACT = {'Default', 'Larry1', 'PMOld1', 'PMYung1'}
_SPECIAL_PREFIX = ('SmallAttackPoint', 'MediumSmallAttackPoint', 'MediumAttackPoint', 'LargeAttackPoint')

ROLE = {
    'SuperMajor': '超大兵', 'SuperSoldier': '超级兵', 'MajorSoldier': '大兵',
    'Major': '大兵', 'Midi': '中型', 'Minor': '小工', 'Minim': '微型',
    'Soldier': '兵蚁', 'Worker': '工蚁', 'Queen': '蚁后', 'King': '蚁王',
    'Medic': '军医', 'Anesthetist': '麻醉师', 'FastResponder': '快速反应',
    'Adult': '成虫', 'Larva': '幼虫', 'Small': '小型', 'Large': '大型',
    'Medium': '中型', 'Uber': '超级', 'Super': '超级', 'Yung': '幼体',
}

_SORTED = sorted(SPECIES, key=len, reverse=True)


def species_of(name):
    """返回 (family, 中文物种名) 或 None。"""
    for k in _SORTED:
        if k.lower() in name.lower():
            return SPECIES[k]
    low = name.lower()
    if 'ant' in low or 'termite' in low or 'formica' in low or 'myrmica' in low:
        return 'ants', name
    if any(w in low for w in ('beetle', 'rove', 'dch', 'ladybird')):
        return 'beetles', name
    if any(w in low for w in ('spider', 'harvestman', 'whip', 'scorpion', 'tick')):
        return 'arachnids', name
    if any(w in low for w in ('crab', 'woodlouse', 'spinydevil', 'frog', 'toad', 'lizard')):
        return 'others', name
    if any(w in low for w in ('wasp', 'aphid', 'cricket', 'mantis', 'worm', 'fly', 'moth')):
        return 'insects', name
    return None


def family_of(row):
    if row in _SPECIAL_EXACT or row.startswith(_SPECIAL_PREFIX):
        return 'special'
    hit = species_of(row)
    return hit[0] if hit else 'others'


def role_cn(name):
    base = re.sub(r'\d+$', '', name)
    hit = species_of(base)
    if not hit:
        return base
    fam, cn = hit
    # 物种名后面剩下的词，补上角色
    key = next((k for k in _SORTED if k.lower() in base.lower()), None)
    rest = base.replace(key, '', 1) if key else ''
    extra = []
    for k in sorted(ROLE, key=len, reverse=True):
        if k.lower() in rest.lower():
            extra.append(ROLE[k])
            rest = re.sub(k, '', rest, flags=re.I)
    return cn + ('·' + ''.join(extra[:2]) if extra else '')


def icon_label(asset_name):
    """把图标文件名翻成中文短名。"""
    base = asset_name.split('/')[-1]
    base = base.replace('UI_Creature_', '').replace('_PheromonePanel_Icon', '')
    base = base.replace('ChamberIcon', '').replace('Icon', '')
    return role_cn(base) or base
