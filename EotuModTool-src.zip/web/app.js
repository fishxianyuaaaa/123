'use strict';
/* Eotu Mod Tool v2.1 前端 —— 双语界面 / 中文标签 / 批量范围 / 生成前确认 / 同名提醒 */

const $ = id => document.getElementById(id);
const S = {
  catalog: null, texts: null, icons: null, status: null, presets: [],
  changes: {}, textChanges: {}, iconChanges: {},
  filter: { q: '', family: 'all', side: 'all' },
  textFilter: { q: '', group: 'all', page: 0, onlyChanged: false },
  iconFilter: { q: '', family: 'all', onlyChanged: false },
  selected: null, summary: null, lastResult: null,
  picker: { id: null, sel: null, image: null, tab: 'official' },
  tab: 'editor',
};
const PAGE_SIZE = 24;

// 批量倍率作用范围：常用 / 阵营 / 物种类别 / 其它
const BATCH_GROUPS = [
  { group: 'common', items: ['filtered', 'all', 'player', 'hostile'] },
  { group: 'side', items: ['hostile_ants', 'hostile_insects', 'hostile_beetles', 'hostile_arachnids'] },
  { group: 'family', items: ['ants', 'beetles', 'insects', 'arachnids', 'others', 'special'] },
  { group: 'other', items: ['prefix'] },
];

// ---------------- 工具 ----------------
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}
function fmt(v) {
  if (v === true) return t('bool.true');
  if (v === false) return t('bool.false');
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : String(+v.toFixed(4));
  return String(v == null ? '—' : v);
}
function clip(s, n) { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) + '…' : s; }
function eq(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) < 1e-9;
  return a === b;
}
let toastTimer = null;
function toast(msg, bad) {
  const el = $('toast'); el.textContent = msg; el.className = 'toast' + (bad ? ' bad' : ''); el.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, 3200);
}
async function api(path, body) {
  const opt = body === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  };
  const r = await fetch(path, opt);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
function byRow(row) { return S.catalog.byRow[row]; }
function textById(id) { return S.texts ? S.texts.byId[id] : null; }
function iconById(id) { return S.icons ? S.icons.byId[id] : null; }
function countOf(o) { return Object.keys(o).length; }
function countFields() { return Object.values(S.changes).reduce((n, v) => n + Object.keys(v).length, 0); }
function totalChanges() { return countFields() + countOf(S.textChanges) + countOf(S.iconChanges); }
function hasChanges() { return totalChanges() > 0; }

function buildPayload() {
  return {
    mod_name: $('modName').value.trim() || t('build.modName.def'),
    scope: $('scope').value,
    note: $('note').value.trim(),
    changes: S.changes, texts: S.textChanges, icons: S.iconChanges,
  };
}

// ---------------- 初始化 ----------------
async function init() {
  applyStaticI18n();
  bindEvents();
  try {
    const [st, cat, tx, ic, pr] = await Promise.all([
      api('/api/status'), api('/api/catalog'), api('/api/texts'), api('/api/icons'), api('/api/presets'),
    ]);
    // 本机没存过语言偏好时，用工具配置里的值（分享给别人时沿用对方上次设置）
    let saved = null;
    try { saved = localStorage.getItem('eoth_lang'); } catch (e) { /* ignore */ }
    if (!saved && st.lang && st.lang !== LANG) { LANG = st.lang; _applyI18n(); }
    S.status = st;
    S.catalog = cat;
    S.catalog.byRow = {};
    S.catalog.fieldMap = {};
    cat.creatures.forEach(c => { S.catalog.byRow[c.row] = c; });
    cat.fields.forEach(f => { S.catalog.fieldMap[f.name] = f; });
    S.texts = tx;
    S.texts.byId = {};
    tx.items.forEach(i => { S.texts.byId[i.id] = i; });
    S.icons = ic;
    S.icons.byId = {};
    ic.items.forEach(i => { S.icons.byId[i.id] = i; });
    S.presets = pr.presets || [];
    $('verText').textContent = 'v' + (st.version || '2.1').replace(/\.0$/, '');
    const defs = ['我的蚂蚁模组', 'My Ant Mod'];
    if (defs.includes($('modName').value)) $('modName').value = t('build.modName.def');
    rerenderAll();
    $('gameRoot').value = (st.info && st.info.game_root) || '';
    applyHash();
  } catch (e) {
    $('statusChip').className = 'status-chip bad';
    $('statusChip').querySelector('span').textContent = t('init.fail', { m: e.message });
    toast(t('init.fail', { m: e.message }), true);
  }
}

/** 语言切换后重画所有动态内容 */
function rerenderAll() {
  if (!S.catalog || !S.texts || !S.icons) return;
  renderStatus();
  renderFamilyFilters();
  renderIconFamilySel();
  renderTextGroupSel();
  renderBatchScope();
  renderCreatureList();
  if (S.selected) renderEditor();
  renderTexts();
  renderIcons();
  renderPresets();
  renderPakStatus();
  renderNavBadges();
  renderFooter();
  renderDiff();
  updatePakPreview();
  $('aboutEnv').textContent = t('settings.env', {
    r: (S.status.info && S.status.info.game_root) || '—',
    s: (S.status.info && S.status.info.source) || '—',
    n: S.icons.stats ? S.icons.stats.total : 0,
  });
  $('btnTextOnlyChanged').textContent = S.textFilter.onlyChanged ? t('texts.showAll') : t('texts.onlyChanged');
  $('btnIconOnlyChanged').textContent = S.iconFilter.onlyChanged ? t('icons.showAll') : t('icons.onlyChanged');
  const defs = ['我的蚂蚁模组', 'My Ant Mod'];
  if (defs.includes($('modName').value)) $('modName').value = t('build.modName.def');
  if (!$('confirmModal').hidden && S.summary) renderConfirm(S.summary);
  if (!$('dupModal').hidden && S.summary) renderDup(S.summary);
  if (!$('batchModal').hidden) {
    const fs = S.catalog.fields.filter(f => f.kind === 'float' || f.kind === 'int');
    $('batchFields').innerHTML = fs.map(f =>
      `<label><input type="checkbox" value="${f.name}" ${batchChecked(f.name)}>${esc(L(f, 'label'))}</label>`).join('');
    batchPreview();
  }
  if (!$('iconModal').hidden && S.picker.id) {
    const item = iconById(S.picker.id);
    $('iconModalTitle').textContent = t('iconModal.title', {
      n: item ? L(item, 'cn') : S.picker.id,
      s: item ? item.w + '×' + item.h : '',
    });
    renderPicker();
  }
  if (S.lastResult) showResult(S.lastResult);
}

function applyHash() {
  const h = location.hash || '';
  const lm = h.match(/lang=(zh|en)/);
  if (lm) setLang(lm[1], false);
  const m = h.match(/tab=(\w+)/);
  if (m) switchTab(m[1]);
  const r = h.match(/row=([\w]+)/);
  if (r && S.catalog.byRow[r[1]]) { switchTab('editor'); selectCreature(r[1]); }
  // 可视化自检用的临时开关（不影响正常功能）
  if (h.indexOf('debug=batch') >= 0) setTimeout(() => { if (S.catalog) openBatch(); }, 500);
  if (h.indexOf('debug=dup') >= 0) setTimeout(() => {
    S.summary = {
      mod_name: $('modName').value.trim() || t('build.modName.def'),
      pak_name: 'zzz_EotU_EothTool_测试_P.pak', reused: true,
      reused_info: { pak: 'zzz_EotU_EothTool_测试_P.pak', exists: true,
                     size: 42311, mtime: '2026-11-13 19:20:00', last_time: '2026-11-13 19:20:00' },
    };
    renderDup(S.summary); $('dupModal').hidden = false;
  }, 500);
}

function renderStatus() {
  const st = S.status, chip = $('statusChip');
  if (!st) return;
  const issues = st.issues || [], conflicts = st.conflicts || [];
  if (issues.length) {
    chip.className = 'status-chip bad';
    chip.querySelector('span').textContent = t('status.bad', { m: clip(issues[0], 42) });
  } else if (conflicts.length) {
    chip.className = 'status-chip warn';
    chip.querySelector('span').textContent = t('status.conflict', { n: conflicts.length });
  } else if (st.game_running) {
    chip.className = 'status-chip warn';
    chip.querySelector('span').textContent = t('status.running');
  } else {
    chip.className = 'status-chip';
    chip.querySelector('span').textContent = t('status.ok', { n: S.catalog ? S.catalog.stats.rows : 281 });
  }
  const wb = $('warnBox');
  const lines = [];
  conflicts.forEach(c => lines.push(t('warn.conflict', { p: esc(c) })));
  if (st.game_running) lines.push(t('warn.running'));
  issues.forEach(i => lines.push(t('warn.issue', { m: esc(i) })));
  wb.innerHTML = lines.join('<br>'); wb.hidden = !lines.length;
}

// ---------------- 导航 ----------------
function switchTab(tab) {
  S.tab = tab;
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === 'panel-' + tab));
  history.replaceState(null, '', '#tab=' + tab);
  if (tab === 'diff') renderDiff();
  if (tab === 'build') renderPakStatus();
  if (tab === 'texts') renderTexts();
  if (tab === 'icons') renderIcons();
}

// ---------------- 生物列表 ----------------
function renderFamilyFilters() {
  const el = $('familyFilters'), fams = S.catalog.families, stats = S.catalog.stats.by_family;
  const all = `<button class="fam-chip ${S.filter.family === 'all' ? 'active' : ''}" data-fam="all">${LANG === 'en' ? 'All' : '全部'} <b>${S.catalog.stats.rows}</b></button>`;
  el.innerHTML = all + fams.map(f =>
    `<button class="fam-chip ${S.filter.family === f.id ? 'active' : ''}" data-fam="${f.id}" title="${esc(L(f, 'hint'))}">${f.icon} ${esc(L(f, 'label'))} <b>${stats[f.id] || 0}</b></button>`
  ).join('');
}
function filteredCreatures() {
  const q = S.filter.q.trim().toLowerCase();
  return S.catalog.creatures.filter(c => {
    if (S.filter.family !== 'all' && c.family !== S.filter.family) return false;
    if (S.filter.side !== 'all' && c.category !== S.filter.side) return false;
    if (q && !(c.search || (L(c, 'cn') + ' ' + c.base + ' ' + c.row).toLowerCase()).includes(q)) return false;
    return true;
  });
}
function renderCreatureList() {
  if (!S.catalog) return;
  const list = filteredCreatures();
  $('listCount').textContent = t('list.count', { n: list.length });
  $('listHint').textContent = S.filter.q ? t('list.search') : t('list.hint');
  const el = $('creatureList');
  if (!list.length) { el.innerHTML = `<div class="empty-inline" style="margin-top:14px">${esc(t('list.empty'))}</div>`; return; }
  el.innerHTML = list.map(c => {
    const n = countOf(S.changes[c.row] || {});
    return `<div class="c-item ${S.selected === c.row ? 'active' : ''}" data-row="${esc(c.row)}">
      <div class="c-main"><div class="c-name">${esc(L(c, 'cn'))}</div><div class="c-row">${esc(c.row)}</div></div>
      ${n ? `<span class="c-badge">${n}</span>` : ''}
      <span class="c-fam">${esc(L(c, 'family_label'))}</span></div>`;
  }).join('');
}
function selectCreature(row) {
  S.selected = row;
  renderCreatureList();
  renderEditor();
}
function renderEditor() {
  const row = S.selected;
  if (!row || !S.catalog) return;
  const c = byRow(row), ch = S.changes[row] || {};
  $('editorEmpty').hidden = true; $('editorContent').hidden = false;
  $('edTitle').textContent = L(c, 'cn');
  $('edRow').textContent = c.row;
  $('edCat').textContent = L(c, 'category_label');
  $('edFam').textContent = L(c, 'family_label');
  $('edFp').hidden = !(c.fp_diff && c.fp_diff.length);
  const groups = S.catalog.groups;
  $('fieldGroups').innerHTML = groups.map((g, gi) => {
    const fs = S.catalog.fields.filter(f => f.group === g && c.values[f.name] !== undefined);
    const gname = LANG === 'en' ? (S.catalog.groups_en[gi] || g) : g;
    return `<div class="fgroup"><h4>${esc(gname)} <small>${esc(t('ed.group', { n: fs.length }))}</small></h4>` +
      fs.map(f => renderField(c, f, ch)).join('') + '</div>';
  }).join('');
}
function renderField(c, f, ch) {
  const orig = c.values[f.name];
  const cur = ch[f.name] !== undefined ? ch[f.name] : orig;
  const changed = ch[f.name] !== undefined;
  const origTitle = esc(t('f.origTitle', { l: L(f, 'label'), v: fmt(orig) }));
  let control, oldText;
  if (f.kind === 'enum') {
    // 「性情」是只读枚举：控件显示本地化可读名，副标签不再暴露内部英文枚举值
    const disp = (LANG === 'en' ? c.temperament_en : c.temperament_cn) || fmt(orig);
    control = `<div class="enum-val" title="${esc(disp)}">${esc(disp)}</div><span></span>`;
    oldText = esc(t('f.readonly'));
  } else if (f.kind === 'bool') {
    control = `<button class="bool-btn ${cur ? 'on' : ''}" data-bool="${esc(f.name)}">${esc(fmt(cur))}</button><span></span>`;
    oldText = esc(t('f.old', { v: fmt(orig) }));
  } else {
    control = `<input type="text" inputmode="decimal" value="${esc(fmt(cur))}" data-field="${esc(f.name)}" title="${esc(L(f, 'hint'))}">` +
      `<button class="f-reset" data-reset="${esc(f.name)}" title="${esc(t('f.reset'))}">↺</button>`;
    oldText = esc(t('f.old', { v: fmt(orig) }));
  }
  return `<div class="f-row ${changed ? 'changed' : ''}" data-wrap="${esc(f.name)}">
    <div class="f-label" title="${origTitle}">${esc(L(f, 'label'))}<span class="f-old">${oldText}</span></div>
    ${control}</div>`;
}
function setChange(row, field, value) {
  const orig = byRow(row).values[field];
  if (!S.changes[row]) S.changes[row] = {};
  if (eq(orig, value)) delete S.changes[row][field];
  else S.changes[row][field] = value;
  if (!countOf(S.changes[row])) delete S.changes[row];
  afterChange();
}
function afterChange() {
  renderNavBadges(); renderFooter(); renderDiff(); updatePakPreview();
  if (S.tab === 'editor') { renderCreatureList(); if (S.selected) renderEditor(); }
  if (S.tab === 'texts') renderTexts();
  if (S.tab === 'icons') renderIcons();
}

// ---------------- 文案 ----------------
function renderTextGroupSel() {
  const sel = $('textGroupSel'), cur = sel.value || 'all';
  const all = `<option value="all">${esc(t('texts.group.all'))}</option>`;
  sel.innerHTML = all + S.texts.groups.map(g =>
    `<option value="${g.id}">${esc(L(g, 'label'))}（${S.texts.stats.by_group[g.id] || 0}）</option>`).join('');
  sel.value = cur;
  S.textFilter.group = sel.value;
}
function filteredTexts() {
  const q = S.textFilter.q.trim().toLowerCase();
  return S.texts.items.filter(i => {
    if (S.textFilter.group !== 'all' && i.group !== S.textFilter.group) return false;
    if (S.textFilter.onlyChanged && S.textChanges[i.id] === undefined) return false;
    if (q && !(L(i, 'label') + ' ' + i.key + ' ' + i.value + ' ' + i.id).toLowerCase().includes(q)) return false;
    return true;
  });
}
function renderTexts() {
  if (!S.texts) return;
  const list = filteredTexts(), pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  S.textFilter.page = Math.min(S.textFilter.page, pages - 1);
  const page = list.slice(S.textFilter.page * PAGE_SIZE, (S.textFilter.page + 1) * PAGE_SIZE);
  $('textChanged').textContent = t('texts.changed', { n: countOf(S.textChanges) });
  const gmap = {}; S.texts.groups.forEach(g => { gmap[g.id] = L(g, 'label'); });
  $('textList').innerHTML = page.length ? page.map(i => {
    const val = S.textChanges[i.id] !== undefined ? S.textChanges[i.id] : i.value;
    const changed = S.textChanges[i.id] !== undefined;
    const shared = i.shared && i.shared.length > 1;
    return `<div class="tcard ${changed ? 'changed' : ''}" data-id="${esc(i.id)}">
      <div class="tcard-head"><div style="min-width:0;flex:1"><div class="tcard-label">${esc(L(i, 'label'))}</div>
        <div class="tcard-key">${esc(i.key)}</div></div><span class="tgroup">${esc(gmap[i.group] || i.group)}</span></div>
      <div class="tcard-orig" title="${esc(i.value)}">${esc(t('texts.orig', { v: clip(i.value, 150) }))}</div>
      <textarea data-tid="${esc(i.id)}" rows="2" placeholder="${esc(t('texts.textarea.ph'))}">${esc(val)}</textarea>
      <div class="tcard-foot"><span>${esc(t('texts.chars', { n: val.length, o: i.value.length }))}${shared ? ' · <span class="share">' + esc(t('texts.shared')) + '</span>' : ''}${i.value.includes('{') ? ' · <span class="share">' + esc(t('texts.placeholder')) + '</span>' : ''}</span>
        ${changed ? `<button data-treset="${esc(i.id)}">${esc(t('texts.reset'))}</button>` : ''}</div></div>`;
  }).join('') : `<div class="empty-inline" style="grid-column:1/-1">${esc(t('texts.empty'))}</div>`;
  $('textPager').innerHTML = `<button id="tPrev" ${S.textFilter.page <= 0 ? 'disabled' : ''}>${esc(t('texts.prev'))}</button>
    <span>${esc(t('texts.pager', { p: S.textFilter.page + 1, n: pages, t: list.length }))}</span>
    <button id="tNext" ${S.textFilter.page >= pages - 1 ? 'disabled' : ''}>${esc(t('texts.next'))}</button>`;
  const p = $('tPrev'), n = $('tNext');
  if (p) p.onclick = () => { S.textFilter.page--; renderTexts(); };
  if (n) n.onclick = () => { S.textFilter.page++; renderTexts(); };
}
function setText(id, value) {
  const item = textById(id);
  if (!item) return;
  if (value === item.value) delete S.textChanges[id];
  else S.textChanges[id] = value;
  afterChange();
}

// ---------------- 图标 ----------------
function renderIconFamilySel() {
  const sel = $('iconFamilySel'), cur = sel.value || 'all';
  sel.innerHTML = `<option value="all">${esc(t('icons.family.all'))}</option>` + S.icons.families.map(f =>
    `<option value="${f.id}">${f.icon} ${esc(L(f, 'label'))}（${(S.icons.stats.by_family || {})[f.id] || 0}）</option>`).join('');
  sel.value = cur;
  S.iconFilter.family = sel.value;
}
function filteredIcons() {
  const q = S.iconFilter.q.trim().toLowerCase();
  return S.icons.items.filter(i => {
    if (S.iconFilter.family !== 'all' && i.family !== S.iconFilter.family) return false;
    if (S.iconFilter.onlyChanged && S.iconChanges[i.id] === undefined) return false;
    if (q && !(L(i, 'cn') + ' ' + i.name + ' ' + i.id).toLowerCase().includes(q)) return false;
    return true;
  });
}
function iconThumb(id) {
  const ch = S.iconChanges[id];
  if (ch && ch.from && iconById(ch.from)) return '/icon/png/' + encodeURIComponent(ch.from) + '.png';
  if (ch && ch.image) return ch.image;
  return '/icon/png/' + encodeURIComponent(id) + '.png';
}
function renderIcons() {
  if (!S.icons) return;
  const list = filteredIcons();
  $('iconChanged').textContent = t('icons.changed', { n: countOf(S.iconChanges) });
  $('iconGrid').innerHTML = list.length ? list.map(i => {
    const ch = S.iconChanges[i.id];
    const src = ch ? (ch.from ? t('icons.from', { n: L(iconById(ch.from) || {}, 'cn') }) : t('icons.custom')) : i.w + '×' + i.h;
    return `<div class="icard ${ch ? 'changed' : ''}" data-icon="${esc(i.id)}">
      ${ch ? `<span class="ibadge">${esc(t('icons.badge'))}</span>` : ''}
      <img class="thumb" src="${iconThumb(i.id)}" alt="" loading="lazy">
      <div class="icn" title="${esc(L(i, 'cn'))}">${esc(L(i, 'cn'))}</div>
      <div class="isub">${esc(clip(src, 22))}</div></div>`;
  }).join('') : `<div class="empty-inline" style="grid-column:1/-1">${esc(t('icons.empty'))}</div>`;
}
function openIconModal(id) {
  S.picker = { id, sel: null, image: null, tab: 'official' };
  const item = iconById(id);
  $('iconModalTitle').textContent = t('iconModal.title', {
    n: item ? L(item, 'cn') : id, s: item ? item.w + '×' + item.h : '',
  });
  $('pickerSearch').value = '';
  $('uploadPreview').hidden = true;
  $('btnApplyIcon').disabled = true;
  switchIconTab('official');
  renderPicker();
  $('iconModal').hidden = false;
}
function switchIconTab(tab) {
  S.picker.tab = tab;
  document.querySelectorAll('.it').forEach(b => b.classList.toggle('active', b.dataset.itab === tab));
  $('itabOfficial').hidden = tab !== 'official';
  $('itabUpload').hidden = tab !== 'upload';
}
function renderPicker() {
  const q = ($('pickerSearch').value || '').trim().toLowerCase();
  const list = S.icons.items.filter(i => i.id !== S.picker.id &&
    (!q || (L(i, 'cn') + ' ' + i.name).toLowerCase().includes(q))).slice(0, 120);
  $('pickerGrid').innerHTML = list.map(i =>
    `<div class="pitem ${S.picker.sel === i.id ? 'sel' : ''}" data-pick="${esc(i.id)}" title="${esc(i.name)}">
      <img src="/icon/png/${encodeURIComponent(i.id)}.png" alt="" loading="lazy"><div>${esc(L(i, 'cn'))}</div></div>`).join('') ||
    `<div class="empty-inline" style="grid-column:1/-1">${esc(t('picker.empty'))}</div>`;
}
function applyIcon() {
  const p = S.picker;
  if (!p.id) return;
  if (p.tab === 'upload' && p.image) S.iconChanges[p.id] = { image: p.image };
  else if (p.tab === 'official' && p.sel) S.iconChanges[p.id] = { from: p.sel };
  else { toast(t('toast.selectIcon'), true); return; }
  $('iconModal').hidden = true;
  afterChange();
  toast(t('toast.iconAdded'));
}

// ---------------- 清单 / 底栏 ----------------
function renderNavBadges() {
  const vals = [countFields(), countOf(S.textChanges), countOf(S.iconChanges), totalChanges()];
  ['navStat', 'navText', 'navIcon', 'navDiff'].forEach((id, k) => {
    const el = $(id); el.textContent = vals[k]; el.classList.toggle('on', vals[k] > 0);
  });
}
function renderFooter() {
  $('footSummary').innerHTML = t('foot.summary', {
    n: '<b id="footCount">' + totalChanges() + '</b>',
    s: '<b id="footStat">' + countFields() + '</b>',
    t: '<b id="footText">' + countOf(S.textChanges) + '</b>',
    i: '<b id="footIcon">' + countOf(S.iconChanges) + '</b>',
  });
  $('footScope').textContent = t('foot.scope.' + $('scope').value);
  $('btnFootRisk').hidden = !(S.summary && (S.summary.danger || S.summary.warn));
}
function diffRows() {
  const out = [];
  for (const [row, fs] of Object.entries(S.changes)) {
    const c = byRow(row) || { cn: row, cn_en: row };
    for (const [f, v] of Object.entries(fs)) {
      const meta = (S.catalog.fieldMap || {})[f] || { label: f, label_en: f };
      out.push([t('diff.catStat'), L(c, 'cn') + ' · ' + L(meta, 'label'), fmt(c.values[f]), fmt(v),
        () => setChange(row, f, c.values[f])]);
    }
  }
  for (const [id, v] of Object.entries(S.textChanges)) {
    const i = textById(id) || { label: id, label_en: id, value: '—' };
    out.push([t('diff.catText'), L(i, 'label'), clip(i.value, 50), clip(v, 50),
      () => setText(id, i.value)]);
  }
  for (const [id, v] of Object.entries(S.iconChanges)) {
    const i = iconById(id) || { cn: id, cn_en: id };
    const src = iconById(v.from) || { cn: v.from, cn_en: v.from };
    const nv = v.from ? t('diff.officialIcon', { n: L(src, 'cn') }) : t('diff.customImage');
    out.push([t('diff.catIcon'), L(i, 'cn'), t('diff.vanillaIcon'), nv,
      () => { delete S.iconChanges[id]; afterChange(); }]);
  }
  return out;
}
function renderDiff() {
  const rows = diffRows();
  $('diffStats').innerHTML = `<div class="stat-pill"><b>${countFields()}</b>${esc(t('diff.pill.values'))}</div>
    <div class="stat-pill"><b>${countOf(S.textChanges)}</b>${esc(t('diff.pill.texts'))}</div>
    <div class="stat-pill"><b>${countOf(S.iconChanges)}</b>${esc(t('diff.pill.icons'))}</div>
    <div class="stat-pill"><b>${totalChanges()}</b>${esc(t('diff.pill.total'))}</div>`;
  $('diffEmpty').hidden = rows.length > 0;
  $('diffBody').innerHTML = rows.slice(0, 400).map((r, k) =>
    `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td><td class="num">${esc(r[3])}</td>
     <td><button class="del" data-del="${k}">${esc(t('diff.del'))}</button></td></tr>`).join('');
  $('diffBody').querySelectorAll('[data-del]').forEach(b => {
    b.onclick = () => { rows[Number(b.dataset.del)][4](); };
  });
}

// ---------------- 生成 / 确认 / 同名提醒 ----------------
function updatePakPreview() {
  $('pakPreview').textContent = 'zzz_EotU_EothTool_' + ($('modName').value.trim() || t('build.modName.def')) + '_P.pak';
}
async function doSummary() {
  if (!hasChanges()) { toast(t('toast.noChanges'), true); return; }
  const btn = $('btnGenerate'); btn.disabled = true; btn.textContent = t('build.generating');
  try {
    const d = await api('/api/summary', buildPayload());
    if (!d.ok) { toast(d.error || t('toast.summaryFail', { e: '' }), true); return; }
    S.summary = d;
    renderFooter();
    if (d.reused) { renderDup(d); $('dupModal').hidden = false; return; }
    renderConfirm(d);
    $('confirmModal').hidden = false;
  } catch (e) { toast(t('toast.summaryFail', { e: e.message }), true); }
  finally { btn.disabled = false; btn.textContent = t('build.generate'); }
}
function renderDup(d) {
  const r = d.reused_info || {};
  const info = r.exists
    ? t('dup.fileInfo', { k: Math.max(1, Math.round((r.size || 0) / 1024)), t: r.mtime || '—' })
    : t('dup.historyInfo', { t: r.last_time || '—' });
  $('dupBody').textContent = t('dup.body', {
    n: d.mod_name, pak: r.pak || d.pak_name, info,
  });
  $('dupPak').textContent = (r.pak || d.pak_name) +
    (LANG === 'en' ? '  ·  in the tool out/ folder' : '  ·  位于工具目录 out/ 下');
}
function renderConfirm(d) {
  const c = d.counts;
  let html = `<div class="summary-counts">
    <div class="sc"><b>${c.stats}</b><span>${esc(t('confirm.statValues'))}</span></div>
    <div class="sc"><b>${c.texts}</b><span>${esc(t('confirm.statTexts'))}</span></div>
    <div class="sc"><b>${c.icons}</b><span>${esc(t('confirm.statIcons'))}</span></div>
    <div class="sc"><b>${d.files.length}</b><span>${esc(t('confirm.statFiles'))}</span></div></div>
    <div style="font-size:12px;color:#5d6a82;line-height:1.8">
      ${esc(t('confirm.modName'))}<b>${esc(d.mod_name)}</b> · ${esc(t('confirm.scope'))}<b>${esc(L(d, 'scope_label'))}</b><br>
      ${esc(t('confirm.output'))}<code>${esc(d.pak_name)}</code>${esc(t('confirm.outHint'))}
    </div>`;
  html += `<div class="summary-title">${esc(t('confirm.detail'))}</div>`;
  d.sections.forEach(sec => {
    html += `<div class="sum-sec"><div class="sum-sec-head"><span>${esc(L(sec, 'title'))} · ${sec.count} ${LANG === 'en' ? 'items' : '项'}</span>
      <small>${esc(L(sec, 'note'))}</small></div><div class="sum-rows">` +
      sec.rows.slice(0, 300).map(r => `<div class="sum-row">
        <span class="lbl" title="${esc(L(r, 'label'))}">${esc(L(r, 'label'))}</span>
        <span class="old" title="${esc(L(r, 'old'))}">${esc(clip(L(r, 'old'), 40))}</span>
        <span class="new" title="${esc(L(r, 'new'))}">→ ${esc(clip(L(r, 'new'), 40))}</span></div>`).join('') +
      (sec.rows.length > 300 ? `<div class="sum-row"><span class="lbl">${esc(t('confirm.more', { n: sec.rows.length - 300 }))}</span><span></span><span></span></div>` : '') +
      `</div></div>`;
  });
  html += `<div class="summary-title">${esc(t('confirm.riskTitle'))} <span class="cnt">${esc(t('confirm.riskCount', { d: d.danger, w: d.warn }))}</span></div>
    <div class="risk-list">` + (d.risks.length ? d.risks.map(r =>
    `<div class="risk-item ${r.level}"><span class="ri">${r.level === 'danger' ? '⛔' : r.level === 'warn' ? '⚠️' : 'ℹ️'}</span>
       <div><b>${esc(L(r, 'title'))}</b>${esc(L(r, 'detail'))}</div></div>`).join('')
    : `<div class="risk-item info"><span class="ri">✅</span><div><b>${esc(t('confirm.noRisk'))}</b>${esc(t('confirm.noRiskDetail'))}</div></div>`) + '</div>';
  html += `<div class="summary-files">${esc(t('confirm.files'))}${d.files.map(f => esc(f)).join('<br>')}</div>`;
  $('confirmBody').innerHTML = html;
  const needAck = d.danger > 0;
  $('ackWrap').hidden = !needAck;
  $('ackRisk').checked = false;
  $('btnConfirmGenerate').disabled = needAck;
  $('confirmBody').scrollTop = 0;
}
async function doGenerate() {
  if (!S.summary) return;
  const p = buildPayload(); p.confirmed = true; p.token = S.summary.token;
  $('confirmBody').innerHTML = `<div class="gen-progress">${t('confirm.progress')}</div>`;
  $('btnConfirmGenerate').disabled = true;
  try {
    const r = await api('/api/generate', p);
    if (!r.ok) { toast(r.error || t('toast.genFail', { e: '' }), true); $('confirmModal').hidden = true; return; }
    S.lastResult = r;
    $('confirmModal').hidden = true;
    showResult(r);
    toast(t('toast.genSuccess', { n: r.pak_name }));
    switchTab('build');
  } catch (e) {
    toast(t('toast.genFail', { e: e.message }), true);
    $('confirmModal').hidden = true;
  } finally { $('btnConfirmGenerate').disabled = false; }
}
function showResult(r) {
  $('buildIdle').hidden = true; $('buildResult').hidden = false;
  $('rName').textContent = r.pak_name;
  $('rSize').textContent = t('size.kb', { n: (r.size / 1024).toFixed(1) });
  $('rMd5').textContent = r.md5;
  $('rScope').textContent = L(r, 'scope_label');
  $('rCount').textContent = t('result.count', { v: r.changed_values, t: r.changed_texts, i: r.changed_icons });
  $('buildLog').textContent = (r.log || []).join('\n') + ((r.warnings || []).length ? '\n\n' + t('foot.risk') + '\n' + r.warnings.join('\n') : '');
  $('installNote').textContent = '';
}
function renderPakStatus() {
  if (!S.status) return;
  const installed = S.status.installed || [], conflicts = S.status.conflicts || [];
  $('pakStatus').innerHTML =
    `<div>${esc(t('build.paksDir'))}<code>${esc(S.status.info ? S.status.info.paks_dir : '—')}</code></div>` +
    (installed.length ? `<div>${esc(t('build.installed', { p: installed.join('、') }))}</div>` : `<div>${esc(t('build.notInstalled'))}</div>`) +
    conflicts.map(c => `<span class="conf">${esc(t('build.conflict', { p: c }))}</span>`).join('') +
    (S.status.game_running ? `<div style="color:#b07a22">${esc(t('warn.running'))}</div>` : '');
}

// ---------------- 预设 / 设置 / 安装 ----------------
function renderPresets() {
  $('presetList').innerHTML = S.presets.length ? S.presets.map(p =>
    `<div class="preset-row"><b>${esc(p.name)}</b><span class="muted">${p.count} 项 · ${esc(p.saved || '')}</span>
     <button data-load="${esc(p.name)}">${esc(t('build.presetLoad'))}</button></div>`).join('')
    : `<p class="muted">${esc(t('build.presetEmpty'))}</p>`;
  $('presetList').querySelectorAll('[data-load]').forEach(b => { b.onclick = () => loadPreset(b.dataset.load); });
}
async function savePreset() {
  const name = $('presetName').value.trim();
  if (!name) { toast(t('toast.presetName'), true); return; }
  try {
    const d = await api('/api/presets/save', Object.assign(buildPayload(), { name }));
    if (!d.ok) { toast(d.error || t('toast.presetName'), true); return; }
    S.presets = (await api('/api/presets')).presets || [];
    renderPresets(); toast(t('toast.presetSaved'));
  } catch (e) { toast(t('toast.presetSaved') + '：' + e.message, true); }
}
async function loadPreset(name) {
  try {
    const d = await api('/api/presets/load', { name });
    const p = d.preset || {};
    S.changes = p.changes || {}; S.textChanges = p.texts || {}; S.iconChanges = p.icons || {};
    $('modName').value = p.mod_name || t('build.modName.def');
    $('scope').value = p.scope || 'both';
    $('note').value = p.note || '';
    S.textFilter.page = 0; S.summary = null;
    afterChange(); updatePakPreview(); renderPresets();
    toast(t('toast.presetLoaded', { n: name }));
  } catch (e) { toast(t('toast.presetLoaded', { n: name }) + '：' + e.message, true); }
}
async function installPak() {
  if (!S.lastResult) { toast(t('toast.needResult'), true); return; }
  try {
    const d = await api('/api/install', { pak: S.lastResult.pak });
    if (!d.ok) { toast(d.error || t('toast.installFail', { e: '' }), true); return; }
    $('installNote').textContent = t('build.installNote', { p: d.dst });
    S.status = await api('/api/status'); renderStatus(); renderPakStatus();
    toast(t('toast.installOk'));
  } catch (e) { toast(t('toast.installFail', { e: e.message }), true); }
}
async function uninstallPak() {
  try {
    const d = await api('/api/uninstall', {});
    toast(d.ok ? t('toast.uninstall', { n: (d.removed || []).length }) : (d.error || '—'), !d.ok);
    S.status = await api('/api/status'); renderStatus(); renderPakStatus();
  } catch (e) { toast(t('toast.uninstallFail', { e: e.message }), true); }
}
async function saveRoot() {
  const root = $('gameRoot').value.trim();
  if (!root) { toast(t('toast.rootEmpty'), true); return; }
  try {
    const d = await api('/api/settings', { game_root: root });
    if (!d.ok) { $('rootResult').textContent = d.error || t('toast.rootEmpty'); return; }
    const tail = d.issues && d.issues.length ? t('settings.rootIssues', { i: d.issues.join('；') }) : '';
    $('rootResult').textContent = t('settings.rootOk', { p: d.game_root, tail });
    S.status = await api('/api/status'); renderStatus(); renderPakStatus();
  } catch (e) { $('rootResult').textContent = t('settings.rootFail', { e: e.message }); }
}
function exportJson() {
  const data = Object.assign(buildPayload(), { exported: new Date().toISOString() });
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'EotuModTool_改动清单.json'; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
function clearAll() {
  if (!hasChanges() || !confirm(t('clearAll.confirm'))) return;
  S.changes = {}; S.textChanges = {}; S.iconChanges = {}; S.summary = null;
  afterChange(); toast(t('toast.cleared'));
}

// ---------------- 批量倍率 ----------------
function renderBatchScope() {
  const sel = $('batchScope'), cur = sel.value || 'filtered';
  sel.innerHTML = BATCH_GROUPS.map(g =>
    `<optgroup label="${esc(t('batch.group.' + g.group))}">` +
    g.items.map(k => `<option value="${k}">${esc(t('scope.' + k))}</option>`).join('') +
    '</optgroup>').join('');
  sel.value = Array.from(sel.options).some(o => o.value === cur) ? cur : 'filtered';
  $('prefixRow').hidden = sel.value !== 'prefix';
}
function batchTargets() {
  if (!S.catalog) return [];
  const all = S.catalog.creatures, scope = $('batchScope').value;
  const hostile = c => c.category === 'wild';
  switch (scope) {
    case 'all': return all;
    case 'player': return all.filter(c => c.category === 'player');
    case 'hostile': return all.filter(hostile);
    case 'hostile_ants': return all.filter(c => hostile(c) && c.family === 'ants');
    case 'hostile_insects': return all.filter(c => hostile(c) && (c.family === 'insects' || c.family === 'beetles'));
    case 'hostile_beetles': return all.filter(c => hostile(c) && c.family === 'beetles');
    case 'hostile_arachnids': return all.filter(c => hostile(c) && c.family === 'arachnids');
    case 'ants': return all.filter(c => c.family === 'ants');
    case 'beetles': return all.filter(c => c.family === 'beetles');
    case 'insects': return all.filter(c => c.family === 'insects');
    case 'arachnids': return all.filter(c => c.family === 'arachnids');
    case 'others': return all.filter(c => c.family === 'others');
    case 'special': return all.filter(c => c.family === 'special' || c.category === 'special');
    case 'prefix': {
      const p = $('batchPrefix').value.trim().toLowerCase();
      return p ? all.filter(c => c.row.toLowerCase().startsWith(p)) : [];
    }
    default: return filteredCreatures();
  }
}
function batchFields() {
  return Array.from(document.querySelectorAll('#batchFields input:checked')).map(i => i.value);
}
function batchChecked(name) {
  return document.querySelector(`#batchFields input[value="${name}"]`)?.checked ||
    ['Health', 'AttackDamage'].includes(name);
}
function batchPreview() {
  const mul = Number($('batchMul').value);
  $('batchPreview').textContent = !Number.isFinite(mul) || mul < 0 ? t('batch.invalid') :
    t('batch.preview', { n: batchTargets().length, f: batchFields().length, m: mul });
}
function openBatch() {
  const fs = S.catalog.fields.filter(f => f.kind === 'float' || f.kind === 'int');
  $('batchFields').innerHTML = fs.map(f =>
    `<label><input type="checkbox" value="${f.name}" ${['Health', 'AttackDamage'].includes(f.name) ? 'checked' : ''}>${esc(L(f, 'label'))}</label>`).join('');
  $('batchModal').hidden = false; batchPreview();
}
function applyBatch() {
  const targets = batchTargets(), fs = batchFields();
  const mul = Number($('batchMul').value), digits = Number($('batchRound').value);
  if (!targets.length || !fs.length || !Number.isFinite(mul) || mul < 0) { toast(t('toast.batchIncomplete'), true); return; }
  let n = 0;
  for (const c of targets) for (const f of fs) {
    const orig = c.values[f];
    if (typeof orig !== 'number') continue;
    const cur = (S.changes[c.row] || {})[f] !== undefined ? S.changes[c.row][f] : orig;
    let v = cur * mul;
    v = digits === 0 ? Math.round(v) : Number(v.toFixed(digits));
    if ((S.catalog.fieldMap || {})[f] && S.catalog.fieldMap[f].kind === 'int') v = Math.round(v);
    setChange(c.row, f, v); n++;
  }
  $('batchModal').hidden = true;
  toast(t('toast.batchApplied', { n }));
}

// ---------------- 事件 ----------------
function bindEvents() {
  document.querySelectorAll('.nav-item').forEach(b => { b.onclick = () => switchTab(b.dataset.tab); });
  $('btnShutdown').onclick = async () => {
    if (!confirm(t('shutdown.confirm'))) return;
    try { await api('/api/shutdown', {}); } catch (e) { /* 服务已关闭 */ }
    document.body.innerHTML = `<div style="display:flex;height:100vh;align-items:center;justify-content:center;font-size:16px;color:#5d6a82">${esc(t('shutdown.done'))}</div>`;
  };
  // 标题栏作者链接：普通浏览器直接开新标签；内置预览被拦截时让后端用系统浏览器打开
  $('authorLink').addEventListener('click', e => {
    const url = $('authorLink').href;
    let w = null;
    try { w = window.open(url, '_blank', 'noopener'); } catch (err) { /* ignore */ }
    if (w) { e.preventDefault(); return; }
    e.preventDefault();
    api('/api/open-url', { url }).catch(() => {});
  });
  // 语言切换（标题栏快捷按钮 + 设置页单选）
  $('btnLang').onclick = () => setLang(LANG === 'zh' ? 'en' : 'zh');
  document.querySelectorAll('[data-lang-opt]').forEach(b => {
    b.onclick = () => setLang(b.dataset.langOpt);
  });

  // 生物列表
  $('search').addEventListener('input', e => {
    S.filter.q = e.target.value; $('btnClearSearch').hidden = !S.filter.q; renderCreatureList();
  });
  $('btnClearSearch').onclick = () => { $('search').value = ''; S.filter.q = ''; $('btnClearSearch').hidden = true; renderCreatureList(); };
  $('familyFilters').addEventListener('click', e => {
    const b = e.target.closest('[data-fam]'); if (!b) return;
    S.filter.family = b.dataset.fam; renderFamilyFilters(); renderCreatureList(); batchPreview();
  });
  $('sideFilters').addEventListener('click', e => {
    const b = e.target.closest('[data-side]'); if (!b) return;
    S.filter.side = b.dataset.side;
    $('sideFilters').querySelectorAll('button').forEach(x => x.classList.toggle('active', x === b));
    renderCreatureList();
  });
  $('creatureList').addEventListener('click', e => {
    const it = e.target.closest('[data-row]'); if (it) selectCreature(it.dataset.row);
  });
  $('btnResetRow').onclick = () => { if (S.selected) { delete S.changes[S.selected]; afterChange(); toast(t('toast.resetRow')); } };
  $('fieldGroups').addEventListener('change', e => {
    const el = e.target;
    if (el.dataset.field && S.selected) {
      const meta = (S.catalog.fieldMap || {})[el.dataset.field] || {};
      let v = el.value.trim();
      if (meta.kind === 'int') v = Math.round(Number(v)); else v = Number(v);
      if (!Number.isFinite(v)) { toast(t('toast.number'), true); renderEditor(); return; }
      setChange(S.selected, el.dataset.field, v);
    }
  });
  $('fieldGroups').addEventListener('click', e => {
    const el = e.target;
    if (el.dataset.bool && S.selected) {
      const c = byRow(S.selected), cur = (S.changes[S.selected] || {})[el.dataset.bool] !== undefined
        ? S.changes[S.selected][el.dataset.bool] : c.values[el.dataset.bool];
      setChange(S.selected, el.dataset.bool, !cur);
    }
    const r = el.dataset.reset;
    if (r && S.selected) setChange(S.selected, r, byRow(S.selected).values[r]);
  });

  // 文案
  $('textSearch').addEventListener('input', e => {
    S.textFilter.q = e.target.value; S.textFilter.page = 0;
    $('btnClearTextSearch').hidden = !S.textFilter.q; renderTexts();
  });
  $('btnClearTextSearch').onclick = () => { $('textSearch').value = ''; S.textFilter.q = ''; S.textFilter.page = 0; $('btnClearTextSearch').hidden = true; renderTexts(); };
  $('textGroupSel').onchange = e => { S.textFilter.group = e.target.value; S.textFilter.page = 0; renderTexts(); };
  $('btnTextOnlyChanged').onclick = () => {
    S.textFilter.onlyChanged = !S.textFilter.onlyChanged;
    $('btnTextOnlyChanged').textContent = S.textFilter.onlyChanged ? t('texts.showAll') : t('texts.onlyChanged');
    S.textFilter.page = 0; renderTexts();
  };
  $('textList').addEventListener('change', e => {
    const el = e.target;
    if (el.dataset.tid) setText(el.dataset.tid, el.value);
  });
  $('textList').addEventListener('click', e => {
    const b = e.target.closest('[data-treset]');
    if (b) { const i = textById(b.dataset.treset); if (i) setText(i.id, i.value); }
  });

  // 图标
  $('iconSearch').addEventListener('input', e => {
    S.iconFilter.q = e.target.value; $('btnClearIconSearch').hidden = !S.iconFilter.q; renderIcons();
  });
  $('btnClearIconSearch').onclick = () => { $('iconSearch').value = ''; S.iconFilter.q = ''; $('btnClearIconSearch').hidden = true; renderIcons(); };
  $('iconFamilySel').onchange = e => { S.iconFilter.family = e.target.value; renderIcons(); };
  $('btnIconOnlyChanged').onclick = () => {
    S.iconFilter.onlyChanged = !S.iconFilter.onlyChanged;
    $('btnIconOnlyChanged').textContent = S.iconFilter.onlyChanged ? t('icons.showAll') : t('icons.onlyChanged'); renderIcons();
  };
  $('iconGrid').addEventListener('click', e => {
    const it = e.target.closest('[data-icon]'); if (it) openIconModal(it.dataset.icon);
  });
  document.querySelectorAll('.it').forEach(b => { b.onclick = () => switchIconTab(b.dataset.itab); });
  $('pickerSearch').addEventListener('input', renderPicker);
  $('pickerGrid').addEventListener('click', e => {
    const it = e.target.closest('[data-pick]'); if (!it) return;
    S.picker.sel = it.dataset.pick; S.picker.image = null;
    $('btnApplyIcon').disabled = false; renderPicker();
  });
  $('uploadZone').onclick = () => $('iconFile').click();
  $('uploadZone').addEventListener('dragover', e => { e.preventDefault(); });
  $('uploadZone').addEventListener('drop', e => {
    e.preventDefault(); if (e.dataTransfer.files[0]) readIconFile(e.dataTransfer.files[0]);
  });
  $('iconFile').onchange = e => { if (e.target.files[0]) readIconFile(e.target.files[0]); };
  $('btnCloseIconModal').onclick = $('btnCancelIconModal').onclick = () => { $('iconModal').hidden = true; };
  $('btnResetIcon').onclick = () => {
    if (!S.picker.id) return;
    delete S.iconChanges[S.picker.id]; $('iconModal').hidden = true; afterChange(); toast(t('toast.iconReset'));
  };
  $('btnApplyIcon').onclick = applyIcon;

  // 清单 / 生成 / 同名提醒
  $('btnExport').onclick = exportJson;
  $('btnClear').onclick = clearAll;
  $('btnGenerate').onclick = doSummary;
  $('btnQuickGenerate').onclick = () => { switchTab('build'); setTimeout(doSummary, 40); };
  $('btnFootRisk').onclick = doSummary;
  $('btnCloseConfirm').onclick = $('btnCancelConfirm').onclick = () => { $('confirmModal').hidden = true; };
  $('ackRisk').onchange = e => { $('btnConfirmGenerate').disabled = !e.target.checked; };
  $('btnConfirmGenerate').onclick = doGenerate;
  const cancelDup = () => { $('dupModal').hidden = true; };
  $('btnCloseDup').onclick = $('btnCancelDup').onclick = cancelDup;
  $('btnConfirmDup').onclick = () => {
    $('dupModal').hidden = true;
    if (S.summary) { renderConfirm(S.summary); $('confirmModal').hidden = false; }
  };
  $('btnInstall').onclick = installPak;
  $('btnUninstall').onclick = uninstallPak;
  $('btnOpenOut').onclick = () => api('/api/open-folder', {});
  $('modName').addEventListener('input', () => { S.summary = null; updatePakPreview(); renderFooter(); });
  $('scope').addEventListener('change', () => { S.summary = null; renderFooter(); });
  $('note').addEventListener('input', () => { S.summary = null; });
  $('btnSavePreset').onclick = savePreset;
  $('btnSaveRoot').onclick = saveRoot;

  // 批量
  $('btnBatch').onclick = openBatch;
  $('btnCloseBatch').onclick = $('btnCancelBatch').onclick = () => { $('batchModal').hidden = true; };
  $('btnApplyBatch').onclick = applyBatch;
  $('batchScope').onchange = e => { $('prefixRow').hidden = e.target.value !== 'prefix'; batchPreview(); };
  $('batchPrefix').addEventListener('input', batchPreview);
  $('batchMul').addEventListener('input', batchPreview);
  $('batchFields').addEventListener('change', batchPreview);
  $('familyFilters').addEventListener('click', batchPreview);
  $('sideFilters').addEventListener('click', batchPreview);

  // 快捷键
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault(); switchTab('editor'); $('search').focus(); $('search').select();
    }
    if (e.key === 'Escape') {
      ['confirmModal', 'iconModal', 'batchModal', 'dupModal'].forEach(id => { $(id).hidden = true; });
    }
  });
}

function readIconFile(file) {
  if (!file || !file.name.toLowerCase().endsWith('.png')) { toast(t('toast.pngOnly'), true); return; }
  if (file.size > 8 * 1024 * 1024) { toast(t('toast.imageBig'), true); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      S.picker.image = reader.result; S.picker.sel = null;
      $('uploadImg').src = reader.result;
      $('uploadInfo').textContent = file.name + ' · ' + img.width + '×' + img.height;
      const item = iconById(S.picker.id);
      $('uploadHint').textContent = t('upload.scale', { s: item ? item.w + '×' + item.h : '—' });
      $('uploadPreview').hidden = false;
      $('btnApplyIcon').disabled = false;
      switchIconTab('upload');
    };
    img.onerror = () => toast(t('toast.imageBad'), true);
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

init();
