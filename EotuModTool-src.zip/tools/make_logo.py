# -*- coding: utf-8 -*-
"""生成 Eotu Mod Tool 软件图标：以用户提供的成品图（橙色 U + 绿叶 + 镐子 + 动漫角色 + 文字）为模板。

素材：assets/icon_user_source.jpg  （用户提供的图标成品，947×940，白底 JPG）
处理：抠掉白底 → 透明；整体缩放并留边距；输出多尺寸 ICO 与 1024 PNG。

输出：
  assets/logo.png   1024×1024 透明 PNG（软件界面 / 预览用）
  assets/logo.ico   16/24/32/48/64/128/256 多尺寸 ICO（exe 内嵌图标）
  logo.ico          根目录副本（桌面快捷方式用）
"""
import os
import shutil

from PIL import Image

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(HERE, 'assets')
SRC = os.path.join(ASSETS, 'icon_user_source.jpg')

SIZE = 1024
SIZES = [16, 24, 32, 48, 64, 128, 256]
FILL = 0.90                      # 内容占画布比例（留约 10% 边距）
# 白底抠除阈值（d = max(255-r,255-g,255-b)，越小越白）
T0, T1 = 10, 46                  # d < T0 全透明；T0..T1 羽化过渡；否则保留


def _clamp(v):
    return 0 if v < 0 else (255 if v > 255 else int(v))


def remove_white(im):
    """把近白背景抠成透明，并沿边缘做柔和羽化；同时反推元素本色以去除白边光晕。"""
    im = im.convert('RGBA')
    src = list(im.getdata())
    out = bytearray()
    for r, g, b, a in src:
        d = max(255 - r, 255 - g, 255 - b)
        if d < T0:
            out += bytes((r, g, b, 0))
        elif d < T1:
            an = (d - T0) / (T1 - T0)            # 边缘不透明度 0..1
            if an <= 0:
                out += bytes((r, g, b, 0))
                continue
            aa = int(an * 255)
            # 边缘像素 = an*元素色 + (1-an)*白，反推元素色去除白边
            cr = (r - (1 - an) * 255) / an
            cg = (g - (1 - an) * 255) / an
            cb = (b - (1 - an) * 255) / an
            out += bytes((_clamp(cr), _clamp(cg), _clamp(cb), aa))
        else:
            out += bytes((r, g, b, 255))
    return Image.frombytes('RGBA', im.size, bytes(out))


def main():
    if not os.path.isfile(SRC):
        raise SystemExit('找不到 assets/icon_user_source.jpg（用户提供的图标成品）')

    src = remove_white(Image.open(SRC))

    # 内容等比缩放后居中到透明画布，留出边距（原图设计元素已顶到边缘）
    canvas = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    side = int(SIZE * FILL)
    content = src.resize((side, side), Image.LANCZOS)
    canvas.alpha_composite(content, ((SIZE - side) // 2, (SIZE - side) // 2))

    png_path = os.path.join(ASSETS, 'logo.png')
    canvas.save(png_path, optimize=True)

    ico_path = os.path.join(ASSETS, 'logo.ico')
    canvas.save(ico_path, format='ICO', sizes=[(s, s) for s in SIZES])
    shutil.copyfile(ico_path, os.path.join(HERE, 'logo.ico'))

    print('源图：assets/icon_user_source.jpg（用户提供的成品图标）')
    print('白底抠除阈值 T0=%d T1=%d，内容占比 %.0f%%' % (T0, T1, FILL * 100))
    print('输出：%s  %d×%d' % (png_path, SIZE, SIZE))
    print('输出：%s  尺寸 %s' % (ico_path, SIZES))
    print('已同步根目录 logo.ico')


if __name__ == '__main__':
    main()
