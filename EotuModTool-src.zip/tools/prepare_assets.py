# -*- coding: utf-8 -*-
"""把本机原版资产整理进 assets/，让工具可以整包分享给别人。开发期一次性脚本。"""
import io
import os
import shutil
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from core import icons, paths

os.makedirs(paths.asset('tables'), exist_ok=True)
os.makedirs(paths.asset('loc'), exist_ok=True)
os.makedirs(paths.asset('bin'), exist_ok=True)

for name in paths.TABLE_PATHS:
    for ext in ('uasset', 'uexp'):
        src = os.path.join(paths.SRC, name + '.' + ext)
        dst = paths.asset('tables', name + '.' + ext)
        shutil.copyfile(src, dst)
        print('table', os.path.basename(dst), os.path.getsize(dst))

for fn in ('DataFiles_zh-Hans.locres', 'UserInterface_zh-Hans.locres'):
    src = os.path.join(paths.SRC, 'loc', fn)
    dst = paths.asset('loc', fn)
    shutil.copyfile(src, dst)
    print('locres', fn, os.path.getsize(dst))

shutil.copyfile(os.path.join(paths.HARDMODE, 'we_manual', 'tools', 'repak.exe'),
                paths.asset('bin', 'repak.exe'))
print('repak', os.path.getsize(paths.asset('bin', 'repak.exe')))

r = icons.prepare()
print('icons:', r['count'], 'skipped:', r['skipped'])
print('index:', os.path.getsize(paths.icons_index()))
