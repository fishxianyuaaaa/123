# Eotu Mod Tool

A local, offline modding tool for **Empires of the Undergrowth** (地下蚁国).
It lets you edit creature stats, Chinese text, and creature icons from a simple
UI, then click **Generate** to produce a `_P.pak` mod file you drop into the
game's `Paks` folder. No internet, no game files modified.

Author: **bilbil聪明de咸鱼**
This software is **completely free** — please do NOT use it for commercial gain.

---

## Source layout / 源码结构

```
EotuModTool-src/
├── EothModTool.py            # 程序入口 (entry point)
├── eotu_stats.py             # UE4 DataTable 读写 (CreatureStats 等长改写)
├── probe.py                  # 游戏目录探测 (game-folder probe)
├── Eoth-Mod Tool.spec        # PyInstaller 打包配置 (build spec)
├── core/                     # 后端模块 (backend: locres/stats/generator/server...)
├── web/                      # 前端 (index.html / app.js / i18n.js / style.css)
├── tools/                    # 构建期脚本 (make_logo.py / prepare_assets.py / e2e_test.py)
├── assets/
│   ├── bin/repak.exe         # 官方打包器副本 (repak packer, bundled)
│   ├── icons/                # 76 个官方图标 (uasset+uexp / png)
│   ├── loc/                  # 两套中文 locres
│   ├── tables/               # 原版 CreatureStats 数据表
│   ├── logo.ico / logo.png   # 软件图标 (已生成，无需重新生成)
└── 使用说明.txt              # 中文使用说明
```

The data under `assets/` (tables, locres, icons, `repak.exe`) is **already
bundled**, so you do NOT need the game installed to build or run from source.

---

## How to build the executable / 如何编译出 exe

### Requirements / 环境
- Python **3.10+**
- `pyinstaller`
- (optional) `pillow` — only needed if you want to **regenerate** the logo
  via `tools/make_logo.py`; the shipped `assets/logo.ico` & `assets/logo.png`
  are already included, so the build itself does not require Pillow.

### Steps / 步骤
```bash
# 1. 进入源码目录
cd EotuModTool-src

# 2. 安装打包依赖 (install build dependency)
pip install pyinstaller

# 3. 打包 (build the one-file executable)
#    On some machines `pyinstaller` is not on PATH — use the module form:
pyinstaller "Eoth-Mod Tool.spec" --noconfirm
#    or / 或:
python -m PyInstaller "Eoth-Mod Tool.spec" --noconfirm
```

- The spec uses `console=False` (windowed) and embeds `assets/` + `web/` and
  the icon, so the output is a **single self-contained file**:
  `dist/Eotu Mod Tool.exe`.
- To run from source without building: `python EothModTool.py` (it starts a
  local web server on `http://127.0.0.1:8765/`).

### Notes / 说明
- `tools/prepare_assets.py` is a **one-time dev script** that copies the vanilla
  game assets into `assets/`. It is NOT needed for building because those assets
  are already in the repo.
- `tools/e2e_test.py` runs the 49-item end-to-end smoke test (optional).

---

## License / 许可

Free for personal use. **Do not sell, paywall, or use this software for
commercial profit.** Attribution to the original author
(**bilbil聪明de咸鱼**) is appreciated.

免费供个人使用。**禁止用于任何商业牟利行为**（出售、付费墙等）。
鼓励注明原作者 bilbil聪明de咸鱼。
