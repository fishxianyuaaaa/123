#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""UE4 .uasset 改名工具（EotU 专用）。

为什么不能按版本号解析：EotU cooked 包的 FPackageFileSummary.FileVersionUE4 被清零，
但布局是新版（name 带 4 字节 hash）。按版本分支猜字段顺序不可靠。

这里改用「锚点 + 值域」法，只依赖几条不会变的事实：
  * total_header_size 在偏移 24，后面紧跟 FolderName(FString)、PackageFlags(u32)、
    NameCount、NameOffset —— 这段顺序与版本无关
  * name entry = i32 len + 字符串(含\\0) + 4 字节 hash
  * import table 紧跟 name table（import_offset == name table 结束），
    且 summary 里 export_count/export_offset/import_count/import_offset/depends_offset
    是连续的 5 个 i32
  * export entry 里 serial_size 在 +24、serial_offset 在 +28（顺序与版本无关）

改流程：替换 name table 中的字符串 -> 平移所有落在 header 内部的表偏移 ->
        平移 export 的 serial_offset -> total_header_size += delta。
.uexp（真正的导出数据）一个字节都不动。
"""
import struct

TAG = 0x9E2A83C1


def _fstr(d, p):
    n = struct.unpack_from('<i', d, p)[0]
    p += 4
    if n == 0:
        return '', p
    if n > 0:
        return d[p:p + n - 1].decode('ascii', 'replace'), p + n
    c = -n
    return d[p:p + (c - 1) * 2].decode('utf-16-le', 'replace'), p + c * 2


class UAsset:
    def __init__(self, data, uexp_len=0):
        self.d = bytearray(data)
        self.uexp_len = uexp_len
        self.parse()

    # ---------------- 解析 ----------------
    def parse(self):
        d = self.d
        if struct.unpack_from('<I', d, 0)[0] != TAG:
            raise RuntimeError('不是 uasset')
        self.total_header = struct.unpack_from('<i', d, 24)[0]
        _, p = _fstr(d, 28)              # folder name
        p += 4                            # package flags
        self.name_count = struct.unpack_from('<i', d, p)[0]
        self.name_offset = struct.unpack_from('<i', d, p + 4)[0]
        self.off_name_offset_field = p + 4

        # name table
        self.names = []
        self.name_ranges = []
        q = self.name_offset
        for _ in range(self.name_count):
            s0 = q
            n = struct.unpack_from('<i', d, q)[0]
            if not 0 < n <= 1024:
                raise RuntimeError(f'name 长度异常 {n} @ {q}')
            q += 4
            s = d[q:q + n - 1].decode('ascii', 'replace')
            q += n + 4                    # 字符串(含\0) + 4 字节 hash
            self.names.append(s)
            self.name_ranges.append((s0, q))
        self.name_end = q

        # 锚点：summary 里值等于 name_end 的那个字段就是 import_offset
        hits = []
        for pos in range(0, self.name_offset - 3):
            if struct.unpack_from('<i', d, pos)[0] == self.name_end:
                hits.append(pos)
        if len(hits) != 1:
            raise RuntimeError(f'import_offset 锚点不唯一: {hits}')
        ip = hits[0]
        self.off_import_offset = ip
        self.import_count = struct.unpack_from('<i', d, ip - 4)[0]
        self.off_export_offset = ip - 8
        self.export_count_pos = ip - 12
        self.export_offset = struct.unpack_from('<i', d, ip - 8)[0]
        self.export_count = struct.unpack_from('<i', d, ip - 12)[0]
        self.off_depends_offset = ip + 4
        self.depends_offset = struct.unpack_from('<i', d, ip + 4)[0]

        # 校验：import table 必须正好填满 name_end -> export_offset
        expected = self.name_end + 28 * self.import_count
        if self.export_offset != expected:
            raise RuntimeError(f'import/export 表不吻合: export_offset={self.export_offset} 期望 {expected}')
        if self.export_count <= 0:
            raise RuntimeError('export_count 异常')
        self.export_entry_size = (self.depends_offset - self.export_offset) // self.export_count
        if self.export_entry_size * self.export_count != self.depends_offset - self.export_offset:
            raise RuntimeError('export 表大小不是整数倍')

        # export 表
        self.exports = []
        for i in range(self.export_count):
            base = self.export_offset + i * self.export_entry_size
            name_index = struct.unpack_from('<i', d, base + 16)[0]
            # ⚠ 实测：EotU cooked 包里 SerialSize/SerialOffset 是 **int64**，
            #    分别在 entry +28 / +36；且 SerialOffset 是「uasset 头 + uexp 拼接流」的
            #    绝对位置（== total_header + uexp 内偏移），不是 uexp 内偏移。
            serial_size = struct.unpack_from('<q', d, base + 28)[0]
            serial_offset = struct.unpack_from('<q', d, base + 36)[0]
            self.exports.append({
                'name': self.names[name_index] if name_index >= 0 else '?',
                'name_index': name_index,
                'serial_size': serial_size,
                'serial_offset': serial_offset,
                'base': base,
            })

    # ---------------- 改名 ----------------
    def rename(self, mapping):
        """mapping: {旧短名: 新短名}。只动 name table 里的完整匹配项，hash 保留原值。"""
        targets = [(i, self.names[i], mapping[self.names[i]]) for i in range(self.name_count)
                   if self.names[i] in mapping]
        if not targets:
            return 0
        delta = 0
        for idx, old, new in sorted(targets, reverse=True):
            s0, s1 = self.name_ranges[idx]
            hash_bytes = bytes(self.d[s1 - 4:s1])
            enc = new.encode('ascii') + b'\x00'
            nb = struct.pack('<i', len(enc)) + enc + hash_bytes
            self.d[s0:s1] = nb
            delta += len(nb) - (s1 - s0)
        self._shift(delta)
        return len(targets)

    # ---------------- 新增名字表条目 ----------------
    def add_name(self, s):
        """在名字表末尾追加一个新条目（用于注入原本不存在的属性名）。
        hash 算法不明 → 填 0，加载是按索引取名字，不校验 hash。"""
        if s in self.names:
            return False
        enc = s.encode('ascii') + b'\x00'
        nb = struct.pack('<i', len(enc)) + enc + b'\x00\x00\x00\x00'
        self.d[self.name_end:self.name_end] = nb
        # name_count 字段就在 name_offset 字段的前一个 int32
        struct.pack_into('<i', self.d, self.off_name_offset_field - 4, self.name_count + 1)
        self._shift(len(nb))
        return True

    def _shift(self, delta):
        if delta == 0:
            self.parse()
            return
        d = self.d
        lo, hi = self.name_offset, self.total_header
        exp_start = self.export_offset
        exp_end = self.export_offset + self.export_count * self.export_entry_size

        # 1) summary 区（[0, name_offset)）里指向 header 内部的表偏移字段
        #    ⚠ 绝不能扫到 name table / import / export 数据区，否则会把字符串字节当成整数改坏
        #    ⚠ 字段不一定 4 字节对齐（FolderName 是 FString），所以必须逐字节扫
        lo2 = self.name_end          # 所有表都在 name table 之后，用这个缩窄范围、降低误伤概率
        hits = []
        for pos in range(0, self.name_offset - 3):
            if pos == 24:            # total_header_size 单独处理
                continue
            v = struct.unpack_from('<i', d, pos)[0]
            if lo2 <= v <= hi:
                hits.append(pos)
        # 相邻命中通常是同一个 int32 的不同起点，按间隔 >=4 去重
        sel = []
        for p in hits:
            if not sel or p - sel[-1] >= 4:
                sel.append(p)
        for pos in sel:
            v = struct.unpack_from('<i', d, pos)[0]
            struct.pack_into('<i', d, pos, v + delta)
        # 2) export 的 serial_offset **必须跟着平移**：它是拼接流的绝对位置，
        #    header 变长 delta 后，同一份导出数据在流里的位置也整体后移 delta。
        #    （漏掉这步就是上一版崩溃的原因：Serial size mismatch）
        #    ⚠ 注意：step 1 已把 summary 里的 export_offset += delta，且导出表在文件里
        #       也整体右移了 delta，所以这里必须用「新」位置，不能用 self.export_offset（旧值）
        for i in range(self.export_count):
            pos = self.export_offset + delta + i * self.export_entry_size + 36
            struct.pack_into('<q', d, pos, struct.unpack_from('<q', d, pos)[0] + delta)
        struct.pack_into('<i', d, 24, self.total_header + delta)
        self.parse()

    def export_names(self):
        return [e['name'] for e in self.exports]
