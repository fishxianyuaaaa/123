# -*- coding: utf-8 -*-
"""v3 端到端测试：技能编辑（改数值+配技能）与画面滤镜的 API 全流程 + pak 回环。"""
import io
import json
import os
import re
import struct
import subprocess
import sys
import urllib.error
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
BASE = r'D:\game\v1.200003\EothModTool'
sys.path.insert(0, BASE)
from core import paths
from eotu_stats import Table

B = 'http://127.0.0.1:8765'
KEY = '0x6A438455002AFC0979AC5F59AE970FC2D2635EAEE796EA9C713A4B9D90B504DD'
OK, FAIL = 0, 0


def chk(cond, msg):
    global OK, FAIL
    if cond:
        OK += 1; print('  OK  ', msg)
    else:
        FAIL += 1; print('  FAIL', msg)


def get(p):
    with urllib.request.urlopen(B + p, timeout=60) as r:
        return json.load(r)


def post(p, obj):
    req = urllib.request.Request(B + p, data=json.dumps(obj, ensure_ascii=False).encode('utf-8'),
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.load(r)


def pak_get(pak, rel, out):
    r = subprocess.run([paths.repak(), '--aes-key', KEY, 'get', pak, rel], capture_output=True, timeout=60)
    if r.returncode != 0:
        raise RuntimeError('repak get 失败: ' + rel + ' ' + r.stderr.decode('utf-8', 'replace')[:200])
    open(out, 'wb').write(r.stdout)
    return out


def nm(t, v):
    i, _ = struct.unpack('<ii', v.raw[:8])
    return t._n(i)


print('=' * 70)
print('Eotu Mod Tool v3 技能/滤镜端到端测试')
print('=' * 70)

st = get('/api/status')
chk(st['ok'] and not st['issues'], '环境检查通过')
chk(st['version'] == '2.2', '版本号 2.2')

sk = get('/api/skills')
chk(sk['ok'] and sk['stats']['total'] == 337, '技能目录 337 个技能（Steam 新版 +7，实际 %s）' % sk['stats']['total'])
chk(sk['stats']['safe'] > 30, '安全技能数 %s > 30' % sk['stats']['safe'])
chk(len(sk['fields']) == 11, '可改字段 11 个')
chk(all(f.get('label_en') and f.get('hint_en') for f in sk['fields']),
    '11 个技能字段都有英文标签/提示')
cn_re = re.compile(r'[\u4e00-\u9fff]')
chk(not [s['name'] for s in sk['skills'] if cn_re.search(s.get('owner_en') or '')],
    '所有技能归属都有英文显示名（无中文残留）')
chk('UberJSVenomJab' in [s['name'] for s in sk['skills']], '包含 UberJSVenomJab')
gd = get('/api/grading')
chk(gd['ok'] and gd['count'] == 20, '滤镜目录 20 张 LUT')
chk(len(gd['presets']) == 5, '5 个调色预设')

# ---------- 场景 A：技能数值 + 配技能 + 滤镜，一次生成 ----------
payload = {
    'mod_name': 'V3自动测试', 'scope': 'both', 'note': 'e2e',
    'changes': {}, 'texts': {}, 'icons': {},
    'skillValues': {'BWSVenomStrike': {'Damage': 33.0, 'Cooldown': 7.5}},
    'skillAssigns': [{'creature': 'BlackAnt', 'ability': 'UberJSVenomJab', 'level': 3,
                      'row_name': 'EotuE2E_Assign1', 'force': False}],
    'grading': 'cool',
}
s = post('/api/summary', payload)
chk(s['ok'], 'summary 成功')
chk(s['counts']['skills'] == 3, '技能项统计=3（实际 %s）' % s['counts']['skills'])
chk(s['counts']['grading'] == 1, '滤镜统计=1')
chk(any(x['id'] == 'skillValues' for x in s['sections']), '汇总含技能数值段')
chk(any(x['id'] == 'skillAssigns' for x in s['sections']), '汇总含配技能段')
chk(any(x['id'] == 'grading' for x in s['sections']), '汇总含滤镜段')
chk(len(s['token']) == 16, 'token 16 位')

# 未确认 / 错 token 拒绝
r = post('/api/generate', payload)
chk(not r.get('ok') and '确认' in r.get('error', ''), '未确认拒绝生成')
r = post('/api/generate', dict(payload, confirmed=True, token='deadbeef'))
chk(not r.get('ok'), '错 token 拒绝生成')

# 篡改 token（改了 skillValues）也应拒绝
tampered = dict(payload, confirmed=True, token=s['token'])
tampered['skillValues'] = {'BWSVenomStrike': {'Damage': 999.0}}
r = post('/api/generate', tampered)
chk(not r.get('ok'), '篡改技能数值后 token 失效')

# 真正确认生成
payload['confirmed'] = True
payload['token'] = s['token']
r = post('/api/generate', payload)
chk(r.get('ok'), '生成成功：' + r.get('error', ''))
if not r.get('ok'):
    print(r)
    sys.exit(1)
chk(r['changed_skills'] == 1 and r['assigned_skills'] == 1, '返回技能统计正确')
chk(r['grading'] == 'cool', '返回滤镜预设正确')
pak = r['pak']
chk(os.path.isfile(pak) and os.path.getsize(pak) > 0, 'pak 存在')

# ---------- 从 pak 回环校验 ----------
wd = os.path.join(BASE, '_work', 'verify_v3')
os.makedirs(wd, exist_ok=True)
abu = pak_get(pak, 'EotU/Content/Assets/Data/Abilities.uasset', os.path.join(wd, 'Abilities.uasset'))
abe = pak_get(pak, 'EotU/Content/Assets/Data/Abilities.uexp', os.path.join(wd, 'Abilities.uexp'))
cau = pak_get(pak, 'EotU/Content/Assets/Data/Creatures_Abilities.uasset', os.path.join(wd, 'Creatures_Abilities.uasset'))
cae = pak_get(pak, 'EotU/Content/Assets/Data/Creatures_Abilities.uexp', os.path.join(wd, 'Creatures_Abilities.uexp'))
lutu = pak_get(pak, 'EotU/Content/Assets/Textures/ColourGrading/Africa_LUT.uexp', os.path.join(wd, 'Africa_LUT.uexp'))

t = Table(abu, abe)
for rn, ps in t.rows:
    d = {v.name: v for v in ps}
    if rn == 'BWSVenomStrike' and len(ps) == 23:
        chk(abs(d['Damage'].get_float() - 33.0) < 1e-4, 'pak 内技能伤害=33')
        chk(abs(d['Cooldown'].get_float() - 7.5) < 1e-4, 'pak 内技能冷却=7.5')
        break

t2 = Table(cau, cae)
seq = []
for rn, ps in t2.rows:
    d = {v.name: v for v in ps}
    if 'CreatureName' in d and nm(t2, d['CreatureName']) == 'BlackAnt' and d['Level'].get_int() == 3:
        seq.append((rn, nm(t2, d['AbilityName'])))
chk(any(r[0] == 'EotuE2E_Assign1' for r in seq), 'pak 内新增技能行存在')
bi = next((i for i, r in enumerate(seq) if r[1] == 'BasicAttack'), -1)
ai = next((i for i, r in enumerate(seq) if r[0] == 'EotuE2E_Assign1'), -1)
chk(ai >= 0 and bi >= 0 and ai < bi, '新技能排在 BasicAttack 之前（优先级正确）')

src = open(os.path.join(BASE, 'assets', 'grading', 'uexp', 'Africa_LUT.uexp'), 'rb').read()
dst = open(lutu, 'rb').read()
changed = sum(1 for i in range(4096) if src[288 + i * 4 + 1:288 + i * 4 + 4] != dst[288 + i * 4 + 1:288 + i * 4 + 4])
chk(changed > 4000, 'LUT 像素已改 (%s)' % changed)
chk(len(src) == len(dst), 'LUT 长度不变')

# ---------- 场景 B：不安全技能被拒 / 强制可加 ----------
bad = dict(payload, mod_name='V3测试强制', confirmed=False)
bad['skillValues'] = {}; bad['grading'] = None
bad['skillAssigns'] = [{'creature': 'BlackAnt', 'ability': 'BWSDevour', 'level': 3,
                        'row_name': 'EotuE2E_Bad1', 'force': False}]
r = post('/api/summary', bad)
chk(not r.get('ok') and '拾取' in r.get('error', ''), '拾取型技能被拒绝：' + r.get('error', '')[:60])

# ---------- 首页静态资源含新标签页 ----------
with urllib.request.urlopen(B + '/', timeout=30) as rr:
    html = rr.read().decode('utf-8', 'replace')
chk('panel-skills' in html and 'panel-grading' in html, '首页含技能页与滤镜页 DOM')
chk('data-tab="skills"' in html and 'data-tab="grading"' in html, '首页含技能与滤镜导航')

print('-' * 70)
print('OK=%d FAIL=%d' % (OK, FAIL))
sys.exit(1 if FAIL else 0)
