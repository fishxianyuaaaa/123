# -*- coding: utf-8 -*-
"""v3 端到端测试：API 全流程 + 从生成的 pak 回环提取校验。"""
import io
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
BASE = r'D:\game\v1.200003\EothModTool'
sys.path.insert(0, BASE)
from core import icons, locres, paths
from eotu_stats import Table

B = 'http://127.0.0.1:8765'
KEY = '0x6A438455002AFC0979AC5F59AE970FC2D2635EAEE796EA9C713A4B9D90B504DD'
OK, FAIL = 0, 0


def chk(cond, msg):
    global OK, FAIL
    if cond:
        OK += 1
        print('  OK  ', msg)
    else:
        FAIL += 1
        print('  FAIL', msg)


def get(p):
    with urllib.request.urlopen(B + p, timeout=60) as r:
        return json.load(r)


def post(p, obj):
    req = urllib.request.Request(B + p, data=json.dumps(obj, ensure_ascii=False).encode('utf-8'),
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.load(r)


def pak_get(pak, rel, out):
    r = subprocess.run([paths.repak(), '--aes-key', KEY, 'get', pak, rel], capture_output=True, timeout=60)
    if r.returncode != 0:
        raise RuntimeError('repak get 失败: ' + rel)
    with open(out, 'wb') as f:
        f.write(r.stdout)
    return out


print('=' * 70)
print('Eotu Mod Tool v2 端到端测试')
print('=' * 70)

st = get('/api/status')
chk(st['ok'] and not st['issues'], '环境检查通过')
chk(st['version'] == '2.2', '版本号 2.2')
cat = get('/api/catalog'); tx = get('/api/texts'); ic = get('/api/icons')
chk(len(cat['creatures']) == 283, '生物 283 行（Steam 新版含东方蝾螈/绿树蛇）')
chk(len(tx['items']) > 300, '可编辑文案 %d 条' % len(tx['items']))
chk(len(ic['items']) == 76, '图标 76 个')
chk(len(cat['stats']['by_family']) == 6, '物种类别 6 类：' + str(cat['stats']['by_family']))

# ---- v2.1 新增：中文名覆盖 / 双语数据 / 语言设置 / 安全 ----
bad = [i['label'] for i in tx['items'] if not re.search(r'[\u4e00-\u9fff]', i['label'])]
chk(not bad, '全部 %d 条文案标题都有中文名（残留 %d 条）' % (len(tx['items']), len(bad)))
mixed = [i['label'] for i in tx['items'] if re.search(r'[A-Za-z]{3,}', i['label'])]
chk(not mixed, '文案标题没有中英混排（残留 %d 条）' % len(mixed))
chk(all(i.get('label_en') for i in tx['items']), '文案条目都有英文标题')
chk(all(f.get('label_en') and f.get('group_en') for f in cat['fields']), '数值字段都有英文名/分组名')
chk(all(c.get('cn_en') and c.get('family_label_en') for c in cat['creatures']), '生物都有中英名与类别名')
chk(all(f.get('label_en') for f in cat['families']), '物种类别都有英文名')
chk(all(i.get('cn_en') for i in ic['items']), '图标都有英文名')
chk(all(g.get('label_en') for g in tx['groups']), '文案分组都有英文名')
lang_r = post('/api/settings', {'lang': 'en'})
chk(lang_r.get('ok') and lang_r.get('lang') == 'en', '设置界面语言为英文')
chk(get('/api/status').get('lang') == 'en', '状态接口返回当前语言')
post('/api/settings', {'lang': 'zh'})
chk(not post('/api/open-url', {'url': 'javascript:alert(1)'}).get('ok'), '拒绝非 http 链接')

pinned = tx['items'][0]
credits = next(i for i in tx['items'] if i['key'] == 'CreditsOurArmy')
desc = next((i for i in tx['items'] if i['group'] == 'creature_desc'), tx['items'][1])
icon_a, icon_b = ic['items'][0], ic['items'][3]

payload = {
    'mod_name': 'API端到端', 'scope': 'both', 'note': '自动测试',
    'changes': {'BlackAnt1': {'Health': 120.0, 'AttackDamage': 8.0, 'CannotBeStunned': True},
                'FireAntPervasive1': {'Speed': 190.0}},
    'texts': {pinned['id']: '蚂蚁工坊已启用', credits['id']: '作者：聪明de咸鱼',
              desc['id']: '这是一段被改写的生物介绍'},
    'icons': {icon_a['id']: {'from': icon_b['id']}},
}
chk(pinned['key'] in ('CreditsTitle', 'MainMenuCredits'), '常用文案排在最前：' + pinned['key'])

s = post('/api/summary', payload)
chk(s.get('ok') and s['counts']['total'] == 8, '汇总统计 8 项改动：' + str(s.get('counts')))
conflict_risks = [r for r in s['risks']
                  if r['level'] == 'danger' and ('同表冲突' in r.get('title', '')
                  or 'Conflicting pak' in r.get('title_en', ''))]
other_danger = [r for r in s['risks'] if r['level'] == 'danger' and r not in conflict_risks]
chk(not other_danger, '除 %d 项已知冲突 pak 外无严重风险' % len(conflict_risks))
chk(s['warn'] >= 2, '提示了 %d 项注意（文本变长/图标共用等）' % s['warn'])
chk(len(s['sections']) == 3, '汇总分 3 组：' + str([x['id'] for x in s['sections']]))
chk(len(s['files']) == 7, '预计 pak 内 7 个文件')

r = post('/api/generate', payload)
chk(not r.get('ok') and '确认' in r.get('error', ''), '未确认时拒绝生成')
r = post('/api/generate', dict(payload, confirmed=True, token='deadbeef'))
chk(not r.get('ok') and '过期' in r.get('error', ''), 'token 不匹配时拒绝生成')

payload2 = dict(payload, confirmed=True, token=s['token'])
r = post('/api/generate', payload2)
chk(r.get('ok'), '确认后生成成功')
pak = r.get('pak')
chk(bool(pak) and os.path.isfile(pak), 'pak 文件存在：' + str(r.get('pak_name')))
chk(len(r.get('files', [])) == 7, 'pak 内 7 个文件')
# 同名再生成时应提示覆盖
s2 = post('/api/summary', payload)
chk(s2.get('reused') is True and s2['reused_info']['exists'], '同名再次生成时返回覆盖提醒')
chk(any('覆盖' in x['title'] for x in s2['risks']), '汇总里列出同名覆盖风险')
chk(all(x.get('title_en') and x.get('detail_en') for x in s2['risks']), '风险条目中英双语齐全')
chk(all(sec.get('title_en') for sec in s2['sections']), '改动分组中英双语齐全')
print('  生成日志：')
for line in r.get('log', []):
    print('    ', line)

# ---------- 回环提取 ----------
tmp = os.path.join(paths.OUT_DIR, '_e2e')
os.makedirs(tmp, exist_ok=True)
rel_table = paths.TABLE_PATHS['CreatureStats'] + '.uexp'
uexp = pak_get(pak, rel_table, os.path.join(tmp, 'CreatureStats.uexp'))
shutil.copyfile(paths.table_src('CreatureStats', 'uasset'), os.path.join(tmp, 'CreatureStats.uasset'))
t = Table(os.path.join(tmp, 'CreatureStats.uasset'), uexp).to_dict()
chk(abs(t['BlackAnt1']['Health'] - 120.0) < 1e-6, 'pak 回读 BlackAnt1.Health = 120')
chk(abs(t['BlackAnt1']['AttackDamage'] - 8.0) < 1e-6, 'pak 回读 BlackAnt1.AttackDamage = 8')
chk(bool(t['BlackAnt1']['CannotBeStunned']) is True, 'pak 回读 CannotBeStunned = True')
chk(abs(t['FireAntPervasive1']['Speed'] - 190.0) < 1e-6, 'pak 回读 FireAntPervasive1.Speed = 190')
src_t = Table(paths.table_src('CreatureStats','uasset'), paths.table_src('CreatureStats','uexp')).to_dict()
chk(abs(t['BlackAnt2']['Health'] - src_t['BlackAnt2']['Health']) < 1e-6, '其它行未被误改（BlackAnt2 保持原值）')

rel_ui = paths.LOCRES_OUT['ui']
lu = pak_get(pak, rel_ui, os.path.join(tmp, 'UserInterface.locres'))
lr = locres.LocRes(lu)
chk(lr.value(pinned['index']) == '蚂蚁工坊已启用', 'pak 回读菜单文案正确')
chk(lr.value(credits['index']) == '作者：聪明de咸鱼', 'pak 回读致谢文案正确')
ldata = pak_get(pak, paths.LOCRES_OUT['data'], os.path.join(tmp, 'DataFiles.locres'))
lrd = locres.LocRes(ldata)
chk(lrd.value(desc['index']) == '这是一段被改写的生物介绍', 'pak 回读生物介绍正确')
chk(len(lrd.entries) == lrd.count, 'data locres 结构可完整解析（%d 条）' % lrd.count)
chk(len(lr.entries) == lr.count, 'locres 结构可完整解析（%d 条）' % lr.count)

rel_icon = icon_a['asset'] + '.uexp'
iu = open(pak_get(pak, rel_icon, os.path.join(tmp, 'icon.uexp')), 'rb').read()
info = icons.icon_info(iu)
src = icons.read_uexp(icon_b['id'])
si = icons.icon_info(src)
chk(info is not None and info['uexp_len'] == len(src), '图标 uexp 长度与原版一致：' + str(info and info['uexp_len']))
chk(iu[info['pixel_start']:] == src[si['pixel_start']:], '图标像素已替换为源图标')

# ---------- 安装 / 卸载 / 预设 ----------
ins = post('/api/install', {'pak': pak})
chk(ins.get('ok'), '安装到 Paks 成功')
if ins.get('ok'):
    chk(os.path.isfile(ins['dst']), '安装目标存在')
uni = post('/api/uninstall', {})
chk(uni.get('ok') and any('API' in x for x in uni.get('removed', [])), '卸载移除本工具 pak')
sv = post('/api/presets/save', dict(payload, name='自动测试预设'))
chk(sv.get('ok'), '保存预设')
ld = post('/api/presets/load', {'name': '自动测试预设'})
chk(ld.get('ok') and len(ld['preset'].get('texts', {})) == 3, '载入预设含 3 段文案')

print('=' * 70)
print('总校验：OK=%d  FAIL=%d' % (OK, FAIL))
print('=' * 70)
sys.exit(1 if FAIL else 0)
