# -*- coding: utf-8 -*-
"""Build a clean, source-only distributable zip of Eotu Mod Tool v2.2.
Excludes runtime outputs, caches, personal config and dev-only scratch files.
"""
import os, zipfile, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'dist', 'EotuModTool-src-v2.2.zip')
TOP = 'EotuModTool-src-v2.2'

# Top-level source/manifest files to include verbatim
TOP_FILES = [
    'EothModTool.py', 'eotu_stats.py', 'probe.py', 'uasset_rename.py',
    'Eoth-Mod Tool.spec', 'README.md', '使用说明.txt',
    '创建桌面快捷方式.bat', '启动 Eotu Mod Tool.bat',
]

# Directories to include entirely (with their files), excluding caches
DIRS = ['core', 'web', 'tools', 'assets']

# Files inside included dirs that are dev-only / private / not needed
SKIP_NAMES = {'__pycache__'}
SKIP_SUBSTR = ['.pyc', '.pyo']
# dev-only tools not needed in a release source package
SKIP_TOOLS = {'make_click_candidates.py'}

# clean config (no personal paths)
CLEAN_CONFIG = {
    'lang': 'zh',
    'theme': 'light',
    'sound': False,
}

def keep(rel):
    parts = rel.replace('\\', '/').split('/')
    if any(p in SKIP_NAMES for p in parts):
        return False
    if any(rel.endswith(s) for s in SKIP_SUBSTR):
        return False
    if len(parts) >= 2 and parts[0] == 'tools' and parts[-1] in SKIP_TOOLS:
        return False
    return True

def main():
    n = 0
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in TOP_FILES:
            p = os.path.join(ROOT, f)
            if os.path.isfile(p):
                z.write(p, TOP + '/' + f)
                n += 1
                print('+', f)
        for d in DIRS:
            base = os.path.join(ROOT, d)
            for cur, dirs, files in os.walk(base):
                dirs[:] = [x for x in dirs if x not in SKIP_NAMES]
                for fn in files:
                    full = os.path.join(cur, fn)
                    rel = os.path.relpath(full, ROOT).replace('\\', '/')
                    if not keep(rel):
                        continue
                    z.write(full, TOP + '/' + rel)
                    n += 1
        # clean config
        z.writestr(TOP + '/config.json',
                   json.dumps(CLEAN_CONFIG, ensure_ascii=False, indent=2) + '\n')
        n += 1
    size = os.path.getsize(OUT)
    print('\nWrote', OUT)
    print('files:', n, 'size:', size, 'bytes (%.2f MB)' % (size / 1048576))

if __name__ == '__main__':
    main()
