# -*- coding: utf-8 -*-
"""生成工具自身的二次元提示音（可复现）。

生成：
  assets/sound/ciallo.wav  进软件时的问候音 —— 直接取自用户提供的视频原音
  assets/sound/click.wav   按钮点击音 —— 清脆的木鱼"嗒"声

用法：
  python tools/make_sounds.py [视频路径]
视频默认：D:/QQXIA ZAI/lv_0_20261121113446.mp4
解码用 ffmpeg（自动在 PATH / imageio_ffmpeg 内置目录查找）。
裁剪、淡入淡出、归一化只用标准库，不需要 numpy。
"""
import glob
import math
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import wave

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets', 'sound')
DEFAULT_VIDEO = 'D:/QQXIA ZAI/lv_0_20261121113446.mp4'


def find_ffmpeg():
    exe = os.environ.get('IMAGEIO_FFMPEG_EXE')
    if exe and os.path.isfile(exe):
        return exe
    exe = shutil.which('ffmpeg')
    if exe:
        return exe
    # imageio_ffmpeg (if installed into a python env under the user home)
    pats = [
        os.path.expanduser('~/.workbuddy/binaries/python/envs/default/Lib/'
                           'site-packages/imageio_ffmpeg/binaries/ffmpeg-*.exe'),
    ]
    for pat in pats:
        hits = glob.glob(pat)
        if hits:
            return hits[0]
    raise RuntimeError('找不到 ffmpeg，无法解码视频音频')


def read_wav_mono(path):
    with wave.open(path, 'rb') as w:
        if w.getnchannels() != 1 or w.getsampwidth() != 2 or w.getframerate() != SR:
            raise ValueError('解码结果不是 44100Hz/16bit/单声道')
        raw = w.readframes(w.getnframes())
    return list(struct.unpack('<%dh' % (len(raw) // 2), raw))


def make_ciallo(video):
    """从视频提取原声，裁掉首尾静音，做自然淡入淡出并归一化。"""
    if not os.path.isfile(video):
        raise FileNotFoundError('找不到视频：' + video)
    tmp = os.path.join(tempfile.gettempdir(), 'eotu_ciallo_src.wav')
    cmd = [find_ffmpeg(), '-hide_banner', '-loglevel', 'error', '-y',
           '-i', video, '-vn', '-ac', '1', '-ar', str(SR), tmp]
    subprocess.run(cmd, check=True)
    raw = read_wav_mono(tmp)

    # 音频能量：0.00~0.35s 是起音前的低电平，0.40~1.10s 是主音效，
    # 1.10s 之后是渐弱尾音。保留一小段尾巴听起来才自然。
    start, end = int(0.32 * SR), min(len(raw), int(1.50 * SR))
    seg = raw[start:end]
    n = len(seg)
    fade_in = int(0.008 * SR)
    fade_out = int(0.25 * SR)
    out = []
    for i, s in enumerate(seg):
        if i < fade_in:
            s *= i / fade_in
        if i > n - fade_out:
            s *= max(0.0, (n - i) / fade_out)
        out.append(s / 32768.0)
    peak = max(abs(x) for x in out) or 1.0
    gain = 0.82 / peak
    return [x * gain for x in out]


def make_click():
    """木鱼「嗒」声（试听候选 C）：900Hz + 三倍频，极短利落、干脆清脆。"""
    dur = 0.06
    out = []
    for i in range(int(SR * dur)):
        t = i / SR
        v = (math.sin(2 * math.pi * 900.0 * t) * 1.00
             + math.sin(2 * math.pi * 2700.0 * t) * 0.28
             + math.sin(2 * math.pi * 5400.0 * t) * 0.07)
        out.append(v * math.exp(-t / 0.007) * 0.36 * min(1.0, t / 0.0004))
    return out


def write_wav(name, samples):
    path = os.path.join(OUT, name)
    os.makedirs(OUT, exist_ok=True)
    with wave.open(path, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        frames = bytearray()
        for s in samples:
            frames += struct.pack('<h', int(max(-1.0, min(1.0, s)) * 32767))
        w.writeframes(bytes(frames))
    peak = max(abs(s) for s in samples) if samples else 0
    print('%s: %d samples, %.3fs, peak=%.3f, %d bytes'
          % (name, len(samples), len(samples) / SR, peak, os.path.getsize(path)))


if __name__ == '__main__':
    video = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    write_wav('ciallo.wav', make_ciallo(video))
    write_wav('click.wav', make_click())
