# -*- coding: utf-8 -*-
"""把 locres 里的英文键翻成「用户看得懂」的中文名，同时提供英文显示名。

v2.1：文案编辑页原来直接把英文 key 当标题（ExecutionAttack / OptionsGamma /
CreditsFrenchLanguage…），普通用户看不懂。这里集中维护一张精确对照表，
其余条目按「游戏自带中文显示名 → 别名 → 物种词典 → 词根翻译」逐级兜底，
保证 389 条可编辑文本全部有中文标题。
"""
import re

# 分组后缀：主标签后面补一句用途，避免「黑蚁」这种不知道改的是名称还是介绍
SUFFIX = {
    'creature_name': (' · 名称', ' · Name'),
    'creature_desc': (' · 介绍', ' · Description'),
    'level3': (' · 3级说明', ' · Lv.3 Bonus'),
    'ability': ('', ''),
    'menu': ('', ''),
    'credits': ('', ''),
}

GROUP_HINT = {
    'creature_name': ('图鉴/卡片上的名字，改短一点比较保险',
                      'Name shown in the encyclopedia / unit card; shorter is safer'),
    'creature_desc': ('图鉴里的百科描述（ShortDescription）',
                      'Encyclopedia description (ShortDescription)'),
    'level3': ('升级到 3 级时显示的那句说明', 'Text shown when the unit reaches level 3'),
    'ability': ('「能力：xxx」这类短标签，多处共用', 'Short ability labels, shared by several screens'),
    'menu': ('主菜单、街机菜单、游戏内菜单按钮文字', 'Main menu, arcade and in-game menu labels'),
    'credits': ('鸣谢页的文字，可写自己的模组介绍', 'Credits page text; a good place for your own mod intro'),
}

# ---------- 精确对照：菜单 / 致谢 / 能力标签 / 非生物类介绍 ----------
CN_EXACT = {
    # 常用菜单与致谢（排在页面最前的那些）
    'MainMenu': '主菜单按钮', 'MainMenuPlayOption': '「开始」按钮',
    'MainMenuCredits': '「鸣谢」按钮', 'MainMenuSettings': '「设置」按钮',
    'CreditsTitle': '鸣谢页标题 / 鸣谢按钮',
    'Arcade': '街机模式', 'Tutorial': '教程按钮', 'Back': '返回按钮',
    'InGameMenuTitle': '游戏内菜单标题', 'InGameMenuQuitToMainMenu': '退出到主菜单',
    'PlayMenuSkirmishDesc': '遭遇战说明', 'PlayMenuFreeplayDesc': '自由模式说明',
    'CreditsOurArmy': '致谢 · 音效团队', 'CreditsSubstanceSharers': '致谢 · 素材分享',
    'CreditsFollowingResources': '致谢 · 环境原画',
    'CreditsLocalisation': '致谢 · 本地化', 'CreditsVarious': '致谢 · 技术支持',
    'CreditsVoiceActors': '致谢 · 配音演员', 'CreditsMissionNarrator': '致谢 · 旁白',
    'CreditsLeadDevelopers': '致谢 · 主程序', 'CreditsCharacterArtists': '致谢 · 角色美术',
    'CreditsCommManager': '致谢 · 社区经理', 'CommTestingFocusCredits': '致谢 · 测试小组',
    # 其余致谢
    'CreditsAssistantProgrammers': '致谢 · 助理程序员',
    'CreditsSupportingUIArtist': '致谢 · UI 美术支持',
    'CreditsSpecialThanks': '致谢 · 特别感谢',
    'CreditsThanksForPlaying': '致谢 · 感谢游玩',
    'CreditsSlugDiscoPublisherSubtitle': '致谢 · 发行商副标题',
    'CreditsCzechLanguage': '致谢 · 捷克语本地化',
    'CreditsChineseLanguage': '致谢 · 中文本地化',
    'CreditsDutchLanguage': '致谢 · 荷兰语本地化',
    'CreditsFrenchLanguage': '致谢 · 法语本地化',
    'CreditsGermanLanguage': '致谢 · 德语本地化',
    'CreditsJapaneseLanguage': '致谢 · 日语本地化',
    'CreditsKoreanLanguage': '致谢 · 韩语本地化',
    'CreditsPolishLanguage': '致谢 · 波兰语本地化',
    'CreditsRussianLanguage': '致谢 · 俄语本地化',
    'CreditsSpanishLanguage': '致谢 · 西班牙语本地化',
    # 菜单 / 设置
    'QuiteGame': '退出游戏', 'QuitGame': '退出游戏',
    'InGameMenuQuitToDesktop': '游戏内菜单 · 退出到桌面',
    'InGameMenuResume': '游戏内菜单 · 继续游戏',
    'InGameMenuSaveFormicarium': '游戏内菜单 · 保存蚁巢',
    'InGameMenuRestart': '游戏内菜单 · 重新开始',
    'Options': '设置', 'OptionsResolution': '设置 · 分辨率',
    'OptionsGameLanguage': '设置 · 游戏语言',
    'OptionsArachnoMode': '设置 · 蛛形类模式',
    'OptionsScreenMode': '设置 · 屏幕模式',
    'OptionsFrameRate': '设置 · 帧率上限',
    'OptionsMonitor': '设置 · 显示器',
    'OptionsGamma': '设置 · 亮度',
    'OptionsGraphicsPreset': '设置 · 画质预设',
    'OptionsTexQuality': '设置 · 纹理质量',
    'OptionsVFXQual': '设置 · 特效质量',
    'OptionsViewDist': '设置 · 可视距离',
    'OptionsResScaling': '设置 · 渲染缩放',
    'OptionsShadowQual': '设置 · 阴影质量',
    'OptionsPPQual': '设置 · 后期处理质量',
    'OptionsAAQual': '设置 · 抗锯齿质量',
    'OptionsFoliageScaling': '设置 · 植被密度',
    'OptionsMasterVol': '设置 · 主音量',
    'OptionsMusicVol': '设置 · 音乐音量',
    'OptionsFXVol': '设置 · 音效音量',
    'OptionsVoiceVol': '设置 · 语音音量',
    'OptionsAudioMax': '设置 · 音量上限',
    'OptionsVSync': '设置 · 垂直同步',
    'OptionsRotateLeft': '设置 · 向左旋转',
    'OptionsRotateRight': '设置 · 向右旋转',
    'OptionsInspectCreatureLabel': '设置 · 查看生物标签',
    'OptionsGroupEnemyMounting': '设置 · 敌人骑乘分组',
    'OptionsApplyDefaultKeys': '设置 · 恢复默认按键',
    'OptionsShowPheromoneMarkerSmoke': '设置 · 信息素标记烟雾',
    'OptionsEnableNotifications': '设置 · 启用通知',
    'OptionsEnableTips': '设置 · 启用提示',
    'OptionsShowTileInfo': '设置 · 显示地块信息',
    'OptionsShowTileInfoColon': '设置 · 显示地块信息（标签）',
    'OptionsShowCreatureInfo': '设置 · 显示生物信息',
    'OptionsShowCreatureInfoColon': '设置 · 显示生物信息（标签）',
    'OptionsShowCreatureInfoTooltip': '设置 · 生物信息提示',
    'PauseGameWithNotificationsColon': '设置 · 通知时暂停游戏',
    'QuitInstanceTitle': '退出关卡 · 标题',
    'QuitInstanceDescription': '退出关卡 · 说明',
    'QuitConfirmTitle': '退出确认 · 标题',
    'QuitConfirmDesc': '退出确认 · 说明',
    'QuitConfirmSaveQuit': '退出确认 · 保存并退出',
    'NewGamePlusX': '新游戏+ · 难度文本',
    'NewGamePlusConfirm': '新游戏+ · 确认按钮',
    'NewGamePlusLevelColon': '新游戏+ · 等级标签',
    'Continue': '继续游戏', 'BackupNo': '备份 · 「否」按钮',
    'ArcadeModeDesc': '街机模式说明',
    'ExitNotifications': '退出通知',
    'MainMenuOtherModes': '主菜单 · 其他模式',
    'MainMenuFormicarium': '主菜单 · 蚁巢',
    'BackToSounds': '返回 · 声音设置',
    'MenuButtonExtraLevels': '菜单 · 额外关卡按钮',
    'DemoLevels': '演示关卡', 'RemixLabel': '重制版标签',
    # 能力标签
    'DamageEnemy': '能力 · 伤害敌人',
    'DamageOverTime': '能力 · 持续伤害',
    'DamageOverTimeLeaveAreaGround': '能力 · 持续伤害（离开区域/地面）',
    'DoTParalyse': '能力 · 持续伤害并麻痹',
    'DetachLeg': '能力 · 断腿', 'DetachTail': '能力 · 断尾',
    'EatAphid': '能力 · 捕食蚜虫', 'Execute': '能力 · 处决',
    'ExecuteIncreaseHidden': '能力 · 处决后提升隐蔽',
    'ExecuteRestoreHealth': '能力 · 处决后回血',
    'IncreaseSpeed': '能力 · 提升移速',
    'IncreasedPhysicalResistance': '能力 · 提升物理抗性',
    'LeapTowardsEnemy': '能力 · 跃向敌人',
    'LeapIncreaseAttackSpeed': '能力 · 跃击后提升攻速',
    'ParalyseIncreaseDamage': '能力 · 麻痹并增伤',
    'PickUpDamage': '能力 · 叼起造成伤害',
    'PickUpDamageLeaveAreaGround': '能力 · 叼起伤害（离开区域/地面）',
    'PickUpExecute': '能力 · 叼起并处决',
    'PickUpExecuteAndNearby': '能力 · 叼起处决并波及附近',
    'PickUpExecuteRestoreHealth': '能力 · 叼起处决并回血',
    'PickUpDamageOverTimeDamage': '能力 · 叼起并持续伤害',
    'Relocate': '能力 · 迁移', 'RestoreHealth': '能力 · 恢复生命',
    'SlowConfuse': '能力 · 减速并混乱',
    'SlowMovementAndAttack': '能力 · 减缓移动与攻击',
    'ReturnDamage': '能力 · 反弹伤害',
    'StealLarvaeAndPreventEggs': '能力 · 偷幼虫并阻止产卵',
    'Stun': '能力 · 眩晕',
    'TauntEnemyRestore': '能力 · 嘲讽敌人并回复',
}

# 少数挂在「生物介绍」下、但其实不是生物行的键（没有中文显示名）
NON_CREATURE_CN = {
    'AreaOfEffectAttack': '范围攻击 · 介绍',
    'ExecutionAttack': '处决攻击 · 介绍',
    'GeneratesThreat': '产生威胁 · 介绍',
    'HiddenFromMinimap': '小地图隐藏 · 介绍',
    'HideFromMinimap': '小地图隐藏 · 介绍',
    'WorkerJobs': '工蚁工作 · 介绍',
    'WorkerJobsAndGathering': '工蚁工作与采集 · 介绍',
}

EN_EXACT = {
    'MainMenu': 'Main Menu Button', 'MainMenuPlayOption': '"Play" Button',
    'MainMenuCredits': '"Credits" Button', 'MainMenuSettings': '"Settings" Button',
    'CreditsTitle': 'Credits Title / Credits Button',
    'Arcade': 'Arcade Mode', 'Tutorial': 'Tutorial Button', 'Back': 'Back Button',
    'InGameMenuTitle': 'In-Game Menu Title',
    'InGameMenuQuitToMainMenu': 'Quit to Main Menu',
    'PlayMenuSkirmishDesc': 'Skirmish Description',
    'PlayMenuFreeplayDesc': 'Freeplay Description',
    'CreditsOurArmy': 'Credits · Sound Team',
    'CreditsSubstanceSharers': 'Credits · Asset Contributors',
    'CreditsFollowingResources': 'Credits · Environment Art',
    'CreditsLocalisation': 'Credits · Localisation',
    'CreditsVarious': 'Credits · Tech Support',
    'CreditsVoiceActors': 'Credits · Voice Actors',
    'CreditsMissionNarrator': 'Credits · Narrator',
    'CreditsLeadDevelopers': 'Credits · Lead Developers',
    'CreditsCharacterArtists': 'Credits · Character Artists',
    'CreditsCommManager': 'Credits · Community Manager',
    'CommTestingFocusCredits': 'Credits · Playtesters',
}

# 词根兜底：万一以后游戏更新多出几个键，也尽量翻成中文而不是甩一串英文
WORDS = {
    'Options': '设置', 'Option': '选项', 'Credits': '致谢', 'Credit': '致谢',
    'Main': '主', 'Menu': '菜单', 'Play': '开始', 'Game': '游戏',
    'Quit': '退出', 'Exit': '退出', 'Back': '返回', 'Continue': '继续',
    'New': '新', 'Plus': '强化', 'Level': '等级', 'Colon': '标签',
    'Show': '显示', 'Hide': '隐藏', 'Enable': '启用', 'Disable': '关闭',
    'Tile': '地块', 'Creature': '生物', 'Info': '信息', 'Tooltip': '提示',
    'Quality': '质量', 'Qual': '质量', 'Volume': '音量', 'Vol': '音量',
    'Audio': '音频', 'Sound': '声音', 'Sounds': '声音', 'Music': '音乐',
    'Voice': '语音', 'FX': '音效', 'VFX': '特效', 'Master': '主',
    'Max': '最大', 'Min': '最小', 'Resolution': '分辨率', 'Res': '渲染',
    'Scaling': '缩放', 'Shadow': '阴影', 'Foliage': '植被', 'View': '视野',
    'Dist': '距离', 'Frame': '帧', 'Rate': '率', 'Monitor': '显示器',
    'Gamma': '亮度', 'Screen': '屏幕', 'Mode': '模式', 'Preset': '预设',
    'Tex': '纹理', 'AA': '抗锯齿', 'PP': '后期处理', 'VSync': '垂直同步',
    'Rotate': '旋转', 'Left': '左', 'Right': '右', 'Inspect': '查看',
    'Group': '分组', 'Enemy': '敌人', 'Mounting': '骑乘', 'Apply': '应用',
    'Default': '默认', 'Keys': '按键', 'Pheromone': '信息素', 'Marker': '标记',
    'Smoke': '烟雾', 'Notifications': '通知', 'Tips': '提示', 'Pause': '暂停',
    'Instance': '关卡', 'Confirm': '确认', 'Desc': '说明', 'Description': '说明',
    'Title': '标题', 'Save': '保存', 'Formicarium': '蚁巢', 'Resume': '继续',
    'Restart': '重新开始', 'Desktop': '桌面', 'Arcade': '街机',
    'Skirmish': '遭遇战', 'Freeplay': '自由模式', 'Language': '语言',
    'Chinese': '中文', 'Czech': '捷克语', 'Dutch': '荷兰语', 'French': '法语',
    'German': '德语', 'Japanese': '日语', 'Korean': '韩语', 'Polish': '波兰语',
    'Russian': '俄语', 'Spanish': '西班牙语', 'Special': '特别', 'Thanks': '感谢',
    'For': '', 'Playing': '游玩', 'Assistant': '助理', 'Programmers': '程序员',
    'Supporting': '支持', 'UI': '界面', 'Artist': '美术', 'Publisher': '发行商',
    'Subtitle': '副标题', 'Leader': '主', 'Developers': '程序',
    'Character': '角色', 'Artists': '美术', 'Comm': '社区', 'Manager': '经理',
    'Testing': '测试', 'Focus': '小组', 'Demo': '演示', 'Levels': '关卡',
    'Extra': '额外', 'Button': '按钮', 'Remix': '重制', 'Label': '标签',
    'Our': '', 'Army': '团队', 'Substance': '素材', 'Sharers': '分享',
    'Following': '环境', 'Resources': '原画', 'Various': '技术支持',
    'Localisation': '本地化', 'Mission': '关卡', 'Narrator': '旁白',
    'No': '否', 'Yes': '是', 'X': '倍数', 'Other': '其他', 'Modes': '模式',
    'To': '', 'With': '', 'And': '与', 'Increase': '提升', 'Damage': '伤害',
    'Over': '持续', 'Time': '时间', 'Area': '范围', 'Ground': '地面',
    'Leave': '离开', 'Effect': '效果', 'Attack': '攻击', 'Speed': '速度',
    'Health': '生命', 'Restore': '恢复', 'Stun': '眩晕', 'Slow': '减速',
    'Confuse': '混乱', 'Movement': '移动', 'Taunt': '嘲讽', 'Return': '反弹',
    'Steal': '偷取', 'Larvae': '幼虫', 'Prevent': '阻止', 'Eggs': '虫卵',
    'Relocate': '迁移', 'Pick': '叼起', 'Up': '', 'Execute': '处决',
    'Paralyse': '麻痹', 'Physical': '物理', 'Resistance': '抗性',
    'Leap': '跃击', 'Towards': '向', 'Hidden': '隐蔽', 'Threat': '威胁',
    'Generates': '产生', 'Detach': '断', 'Leg': '腿', 'Tail': '尾',
    'Eat': '捕食', 'Aphid': '蚜虫', 'Worker': '工蚁', 'Jobs': '工作',
    'Gathering': '采集', 'Minimap': '小地图', 'From': '', 'Hidden2': '',
    'DoT': '持续伤害', 'Player': '玩家', 'Controlled': '控制',
    'Spider': '蜘蛛', 'Ability': '能力', 'Enemy2': '', 'Nearby': '附近',
    'Execution': '处决', 'Of': '', 'ControlledSpider': '控制蜘蛛',
    'Major': '大', 'Termite': '白蚁', 'Queen': '蚁后', 'Larry': '拉里',
}

_HEX = re.compile(r'^[0-9A-F]{24,}$')


def humanize(s):
    """CamelCase / 下划线 → 空格分隔的可读英文。"""
    s = re.sub(r'[_\-]+', ' ', s)
    s = re.sub(r'(?<=[a-z0-9])(?=[A-Z])', ' ', s)
    s = re.sub(r'(?<=[A-Z])(?=[A-Z][a-z])', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _base_of(key, group):
    if group == 'creature_name':
        return key[len('CreatureInfo_'):-len('_DisplayName')]
    if group == 'creature_desc':
        return key[len('CreatureInfo_'):-len('_ShortDescription')]
    if group == 'level3':
        return key[len('CreatureInfo_'):-len('_Level3Description')]
    if group == 'ability':
        return key[len('CreatureInfo_Ability_'):]
    return key


def _word_cn(s):
    parts = [p for p in humanize(s).split(' ') if p]
    out = []
    for p in parts:
        w = WORDS.get(p)
        if w is None:
            w = WORDS.get(p.rstrip('s')) or p
        if w:
            out.append(w)
    return ''.join(out) if out else s


def label_pair(key, group, value, cn_resolver=None):
    """返回 (中文标签, 英文标签)。"""
    base = _base_of(key, group)
    suf_zh, suf_en = SUFFIX.get(group, ('', ''))
    en = EN_EXACT.get(key) or (humanize(base) + suf_en)

    if _HEX.match(key):
        # 游戏里少数哈希命名的键没有语义，用原文开头做提示
        preview = (value or '').replace('\n', ' ')[:12]
        return ('菜单文本 · ' + preview + ('…' if len(value or '') > 12 else ''),
                'Menu text · ' + (humanize(preview) or key[:8]))
    exact = CN_EXACT.get(key)
    if not exact and group in ('ability', 'menu', 'credits'):
        exact = CN_EXACT.get(base)
    if exact:
        return exact, en
    if group in ('creature_name', 'creature_desc', 'level3'):
        special = NON_CREATURE_CN.get(base)
        if special:
            return special, en
        cn = cn_resolver(base) if cn_resolver else base
        if not cn or not re.search(r'[\u4e00-\u9fff]', cn):
            cn = _word_cn(base)
        return cn + suf_zh, en
    # 其余菜单/致谢/能力键：按词根翻译，至少给出中文
    cn = _word_cn(base)
    if not re.search(r'[\u4e00-\u9fff]', cn):
        cn = {'menu': '菜单文字', 'credits': '致谢文字', 'ability': '能力标签'}.get(group, '游戏文本') + ' · ' + cn
    return cn, en
