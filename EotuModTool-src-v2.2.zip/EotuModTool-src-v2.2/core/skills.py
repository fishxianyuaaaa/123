# -*- coding: utf-8 -*-
"""技能编辑：技能目录 + 两类改动写入（改技能数值 / 给生物配技能）。

两套表都改：剧情 Abilities/Creatures_Abilities + 自由 *_Freeplay。
  * 改技能数值 = 等长改 Abilities 表的数值字段（Damage/Cooldown/Rate/...）。
  * 给生物配技能 = 在 Creatures_Abilities 真正新增行，插到 BasicAttack 之前。

安全约束（给生物配技能时强校验，防止卡死/独占平A）：
  * Animation ∈ {Attack, None}（玩家单位 AnimBP 只有 Attack 槽，Ability1/2/3 会卡死）
  * 非 AT_Pickup / PickupStrength=0（Pickup 是两段式，玩家单位叼起后卡死）
  * 有正 Cooldown 或 ChanceToUse<1（否则永久独占平A，后面技能轮不到）
  * 排除 AlwaysOn / ActivatedMounted / Flee / SelfKill 等触发
"""
import os
import re
import struct
import sys

from . import ca_rows, paths
from . import labels as label_mod

_ensure = False


def _boot():
    global _ensure
    if _ensure:
        return
    here = os.path.dirname(os.path.abspath(__file__))
    hd = os.path.abspath(os.path.join(here, '..', 'mods', 'hardmode'))
    if os.path.isdir(hd) and hd not in sys.path:
        sys.path.insert(0, hd)
    _ensure = True


_boot()
from eotu_stats import Table            # noqa: E402

SETS = [
    dict(label='剧情模式', ab='Abilities', ab_f='Abilities_Freeplay',
         ca='Creatures_Abilities', ca_f='Creatures_Abilities_Freeplay'),
]

# 可改的数值字段（前端滑块/输入框 + 后端校验）
NUM_FIELDS = [
    dict(name='Damage', label='伤害', label_en='Damage', kind='float',
         hint='单次伤害，0=不造成伤害', hint_en='Damage per hit; 0 = no damage'),
    dict(name='Cooldown', label='冷却(秒)', label_en='Cooldown (s)', kind='float',
         hint='正数=按秒限频，-1=无冷却', hint_en='Positive = seconds; -1 = no cooldown'),
    dict(name='Rate', label='攻击速率修正', label_en='Attack Speed Modifier', kind='float',
         hint='-1=跟随单位攻速', hint_en='-1 = follow unit attack speed'),
    dict(name='ChanceToUse', label='触发概率', label_en='Use Chance', kind='float',
         hint='0~1，按行顺序判定', hint_en='0~1, checked in row order'),
    dict(name='MinRange', label='最小射程', label_en='Min Range', kind='float',
         hint='-1=不限', hint_en='-1 = unlimited'),
    dict(name='MaxRange', label='最大射程', label_en='Max Range', kind='float',
         hint='-1=不限', hint_en='-1 = unlimited'),
    dict(name='AOERad', label='范围半径', label_en='AoE Radius', kind='float',
         hint='0=单体', hint_en='0 = single target'),
    dict(name='ThreatGeneration', label='仇恨值', label_en='Threat', kind='float',
         hint='影响敌人优先攻击', hint_en='Affects enemy targeting priority'),
    dict(name='TriggerThreshold', label='触发阈值', label_en='Trigger Threshold', kind='float',
         hint='按触发类型而定', hint_en='Depends on trigger type'),
    dict(name='PickupStrength', label='拾取强度', label_en='Pickup Strength', kind='int',
         hint='0=不拾取（强烈建议保持0）', hint_en='0 = no pickup (strongly recommended)'),
    dict(name='Charges', label='充能次数', label_en='Charges', kind='int',
         hint='1=单次', hint_en='1 = single use'),
]
NUM_MAP = {f['name']: f for f in NUM_FIELDS}
ENUM_FIELDS = ['AbilityType', 'Animation', 'Trigger', 'HitType', 'DamageType',
               'UsageLocation', 'AnimPlayType']
SAFE_ANIM = ('EAnimationType::Attack', 'EAnimationType::None')
BAD_TRIG = ('EAbilityTrigger::AlwaysOn', 'EAbilityTrigger::ActivatedMounted',
            'EAbilityTrigger::ActivatedRiding')


def _nm(t, v):
    i, _ = struct.unpack('<ii', v.raw[:8])
    return t._n(i)


def _en_owner(owner):
    """生物行名 -> 英文显示名（与生物数值页一致）。"""
    if not owner:
        return ''
    m = re.match(r'^(.*?)(\d+)$', owner)
    base, level = (m.group(1), m.group(2)) if m else (owner, '')
    en = label_mod.humanize(base)
    return en + (f' Lv.{level}' if level else '')


def _skill_rows(t):
    """只取真正的技能行（23 字段布局），跳过 heuristic 噪音行。"""
    out = []
    for rn, ps in t.rows:
        d = {v.name: v for v in ps}
        if len(ps) == 23 and 'AbilityType' in d:
            out.append((rn, d))
    return out


def _ab_table(name):
    return Table(paths.table_src(name, 'uasset'), paths.table_src(name, 'uexp'))


def _effects_of(ae_name):
    """技能 -> 效果名列表。"""
    t = _ab_table(ae_name)
    m = {}
    for rn, ps in t.rows:
        d = {v.name: v for v in ps}
        if 'AbilityName' in d and 'EffectName' in d:
            m.setdefault(_nm(t, d['AbilityName']), []).append(_nm(t, d['EffectName']))
    return m


def _creature_skills(ca_name):
    """生物 -> {等级: [技能名...]} 及技能->使用者集合。"""
    t = _ab_table(ca_name)
    by_creature = {}
    users = {}
    for rn, ps in t.rows:
        d = {v.name: v for v in ps}
        if 'CreatureName' not in d or 'AbilityName' not in d or 'Level' not in d:
            continue
        c = _nm(t, d['CreatureName'])
        ab = _nm(t, d['AbilityName'])
        lv = d['Level'].get_int()
        by_creature.setdefault(c, {}).setdefault(lv, []).append(ab)
        users.setdefault(ab, set()).add(c)
    return by_creature, users


def catalog():
    """给前端：技能目录 + 生物现有技能 + 可改字段/枚举。"""
    t = _ab_table('Abilities')
    eff = _effects_of('Abilities_Effects')
    by_creature, users = _creature_skills('Creatures_Abilities')
    from . import skill_names
    from .catalog import cn_for_base
    skills = []
    for rn, d in _skill_rows(t):
        vals = {}
        for f in NUM_FIELDS:
            v = d.get(f['name'])
            if v is None:
                continue
            vals[f['name']] = v.get_int() if f['kind'] == 'int' else round(v.get_float(), 6)
        enums = {f: _nm(t, d[f]) for f in ENUM_FIELDS if f in d}
        anim = enums.get('Animation', '')
        ty = enums.get('AbilityType', '')
        trig = enums.get('Trigger', '')
        cd = vals.get('Cooldown', -1)
        chance = vals.get('ChanceToUse', 1.0)
        ps = vals.get('PickupStrength', 0)
        safe = (anim in SAFE_ANIM and 'Pickup' not in ty and ps == 0
                and (cd > 0 or chance < 1.0)
                and trig not in BAD_TRIG)
        owners = sorted(users.get(rn, []))
        owner_cn = cn_for_base(owners[0]) if owners else (skill_names.owner_hint(rn) or '通用')
        owner_en = _en_owner(owners[0]) if owners else (skill_names.owner_hint_en(rn) or 'General')
        skill_cn = skill_names.translate(rn)
        label_cn = f'{owner_cn} - {skill_cn}'
        skills.append(dict(
            name=rn, cn=label_cn, en=rn,
            skill_cn=skill_cn, owner_cn=owner_cn, owner_en=owner_en,
            values=vals, enums=enums, effects=eff.get(rn, []),
            users=owners, safe=safe,
            search=(rn + ' ' + label_cn + ' ' + skill_cn + ' ' + owner_cn + ' '
                    + ' '.join(eff.get(rn, []))).lower(),
        ))
    # 生物列表（带中文名），供「给生物配技能」选择
    creature_list = []
    for c, levels in sorted(by_creature.items()):
        creature_list.append(dict(name=c, cn=cn_for_base(c), levels=sorted(levels)))
    # 枚举取值域（从真实行统计，给前端下拉框）
    enum_vals = {}
    for f in ENUM_FIELDS:
        vals = set()
        for _, d in _skill_rows(t):
            if f in d:
                vals.add(_nm(t, d[f]))
        enum_vals[f] = sorted(vals)
    return dict(
        ok=True, skills=skills, creatures=creature_list,
        fields=NUM_FIELDS, enum_fields=ENUM_FIELDS, enum_values=enum_vals,
        stats=dict(total=len(skills), safe=sum(1 for s in skills if s['safe']),
                   creatures=len(creature_list)),
    )


def validate_values(skill_values, cat):
    """校验改技能数值：字段合法、数值范围、技能存在。"""
    if not isinstance(skill_values, dict):
        return {}
    valid_skills = {s['name']: s for s in cat['skills']}
    out, warns = {}, []
    for name, fields in skill_values.items():
        if name not in valid_skills:
            raise ValueError('未知技能：' + name)
        if not isinstance(fields, dict) or not fields:
            continue
        clean = {}
        for field, value in fields.items():
            meta = NUM_MAP.get(field)
            if not meta:
                raise ValueError(f'技能 {name} 的未知字段：{field}')
            try:
                v = int(value) if meta['kind'] == 'int' else float(value)
            except (TypeError, ValueError):
                raise ValueError(f'{name}.{meta["label"]} 需要数字')
            if not (-1e9 < v < 1e9):
                raise ValueError(f'{name}.{meta["label"]} 数值超出范围')
            if field == 'ChanceToUse' and not (0 <= v <= 1):
                raise ValueError(f'{name}.触发概率必须在 0~1 之间')
            if field == 'PickupStrength' and v != 0:
                warns.append(f'{name}.拾取强度={v}（非0 可能导致玩家单位卡死）')
            clean[field] = v
        if clean:
            out[name] = clean
    return out, warns


def validate_assigns(assigns, cat):
    """校验给生物配技能：安全约束 + 行名唯一。"""
    if not isinstance(assigns, list):
        return []
    skills = {s['name']: s for s in cat['skills']}
    creatures = {c['name']: c for c in cat['creatures']}
    out, row_names = [], set()
    for a in assigns:
        if not isinstance(a, dict):
            raise ValueError('配技能项格式错误')
        c, skill, lv = a.get('creature'), a.get('ability'), a.get('level')
        if c not in creatures:
            raise ValueError('未知生物：' + str(c))
        if skill not in skills:
            raise ValueError('未知技能：' + str(skill))
        try:
            lv = int(lv)
        except (TypeError, ValueError):
            raise ValueError('等级必须是数字')
        if lv not in (1, 2, 3):
            raise ValueError('等级只能是 1/2/3')
        s = skills[skill]
        if not s['safe'] and not a.get('force'):
            reasons = []
            if 'Ability1' in s['enums'].get('Animation', '') or 'Ability2' in s['enums'].get('Animation', '') or 'Ability3' in s['enums'].get('Animation', ''):
                reasons.append('动画槽玩家单位没有，会卡死')
            if 'Pickup' in s['enums'].get('AbilityType', '') or s['values'].get('PickupStrength', 0):
                reasons.append('拾取型技能会卡死')
            if s['values'].get('Cooldown', -1) <= 0 and s['values'].get('ChanceToUse', 1) >= 1:
                reasons.append('无冷却且必触发，会独占平A')
            raise ValueError(f'技能「{skill}」不宜配给玩家单位：' + '；'.join(reasons or ['不安全']))
        rn = a.get('row_name') or f'EotuSkill_{c}_{skill}_L{lv}'
        rn = ''.join(ch for ch in rn if ch.isalnum() or ch == '_')[:60]
        if rn in row_names:
            raise ValueError('技能行名重复：' + rn)
        row_names.add(rn)
        out.append(dict(row_name=rn, creature=c, ability=skill, level=lv))
    return out


def apply(skill_values, assigns, stage, log, scope='both'):
    """把两类改动写入 stage。scope: both/story/freeplay。返回写入文件列表。"""
    written = []
    tables = [('Abilities', 'Creatures_Abilities', 'EotU/Content/Assets/Data')]
    tables_f = [('Abilities_Freeplay', 'Creatures_Abilities_Freeplay',
                 'EotU/Content/Assets/Data/FreeplayStats')]
    jobs = []
    if scope in ('both', 'story'):
        jobs += tables
    if scope in ('both', 'freeplay'):
        jobs += tables_f

    for ab_name, ca_name, rel in jobs:
        # ---------- 1) 改技能数值（等长）----------
        if skill_values:
            t = _ab_table(ab_name)
            orig = len(t.uexp)
            idx = {rn: i for i, (rn, _) in enumerate(_skill_rows(t))}
            # _skill_rows 过滤后的顺序与原 t.rows 的索引需要映射
            real_idx = {}
            for i, (rn, ps) in enumerate(t.rows):
                d = {v.name: v for v in ps}
                if len(ps) == 23 and 'AbilityType' in d:
                    real_idx[rn] = i
            for name, fields in skill_values.items():
                if name not in real_idx:
                    raise RuntimeError(f'{ab_name} 找不到技能行 {name}')
                i = real_idx[name]
                for field, value in fields.items():
                    v = t._find(i, field)
                    meta = NUM_MAP[field]
                    if meta['kind'] == 'int' and v.is_int:
                        t.set_int(i, field, int(value))
                    elif meta['kind'] == 'float' and v.is_float:
                        t.set_float(i, field, float(value))
                    else:
                        raise RuntimeError(f'{name}.{field} 字段类型不匹配：{v.type}')
            if len(t.uexp) != orig:
                raise RuntimeError(f'{ab_name} 改数值后长度变化，已中止')
            out_base = os.path.join(stage, *rel.split('/'))
            os.makedirs(out_base, exist_ok=True)
            t.save(os.path.join(out_base, ab_name + '.uexp'),
                   os.path.join(out_base, ab_name + '.uasset'))
            written += [rel + '/' + ab_name + '.uasset', rel + '/' + ab_name + '.uexp']
            log.append(f'  {ab_name}：改 {len(skill_values)} 个技能数值，长度不变')

        # ---------- 2) 给生物配技能（变长新增行，插到 BasicAttack 之前）----------
        if assigns:
            src_ua = paths.table_src(ca_name, 'uasset')
            src_ux = paths.table_src(ca_name, 'uexp')
            out_base = os.path.join(stage, *rel.split('/'))
            os.makedirs(out_base, exist_ok=True)
            out_ua = os.path.join(out_base, ca_name + '.uasset')
            out_ux = os.path.join(out_base, ca_name + '.uexp')
            # 按 (生物,等级) 分组，每组插到该组 BasicAttack 之前
            groups = {}
            for a in assigns:
                groups.setdefault((a['creature'], a['level']), []).append(a)
            if len(groups) == 1:
                (c0, lv0), specs = next(iter(groups.items()))
                ca_rows.add_rows(src_ua, src_ux, out_ua, out_ux, specs,
                                 insert_before={'creature': c0, 'level': lv0,
                                                'ability': 'BasicAttack'})
            else:
                # 多组：逐组累积输入（上一组输出作为下一组输入）
                cur_ua, cur_ux = src_ua, src_ux
                for (c0, lv0), specs in groups.items():
                    ca_rows.add_rows(cur_ua, cur_ux, out_ua, out_ux, specs,
                                     insert_before={'creature': c0, 'level': lv0,
                                                    'ability': 'BasicAttack'})
                    cur_ua, cur_ux = out_ua, out_ux
            written += [rel + '/' + ca_name + '.uasset', rel + '/' + ca_name + '.uexp']
            log.append(f'  {ca_name}：新增 {len(assigns)} 行技能（插在 BasicAttack 前）')
    return written


def verify(skill_values, assigns, stage, log):
    """生成后回读校验。"""
    checked = 0
    for rn, fields in skill_values.items():
        p = os.path.join(stage, 'EotU', 'Content', 'Assets', 'Data', 'Abilities.uasset')
        ux = p[:-7] + '.uexp'
        if not os.path.isfile(p):
            continue
        t = Table(p, ux)
        idx = {r: i for i, (r, _) in enumerate(t.rows)}
        if rn not in idx:
            raise RuntimeError(f'回读：找不到技能 {rn}')
        d = {v.name: v for v in t.rows[idx[rn]][1]}
        for field, want in fields.items():
            v = d[field]
            got = v.get_int() if NUM_MAP[field]['kind'] == 'int' else v.get_float()
            if abs(got - want) > 1e-4:
                raise RuntimeError(f'回读不一致 {rn}.{field}: {got} != {want}')
            checked += 1
    if assigns:
        p = os.path.join(stage, 'EotU', 'Content', 'Assets', 'Data', 'Creatures_Abilities.uasset')
        t = Table(p, p[:-7] + '.uexp')
        rows = set()
        for r, ps in t.rows:
            rows.add(r)
        for a in assigns:
            if a['row_name'] not in rows:
                raise RuntimeError(f'回读：找不到新增技能行 {a["row_name"]}')
            checked += 1
    log.append(f'  技能改动回读校验 {checked} 项全部一致')
    return checked
