# -*- coding: utf-8 -*-
"""给 Creatures_Abilities  DataTable 真正新增技能行，可指定插入锚点。

基于 add_ca_rows.py 的实测结论（v1.200003）：
  * uexp 里 RowMap 的 NumRows 是 int32 @41，行流 @45 起，每行 111B，
    字段偏移 +0(RowName)/+33(Creature)/+66(Ability)/+99(Level)，末尾 4B 包尾 tag。
  * uasset export[0].serial_size @base+28 必须 = len(uexp)-4；
    export[0].serial_offset @base+36 = total_header（add_name 自动同步）。

本模块新增：insert_before —— 把新行插到「指定生物+等级」的 BasicAttack 行之前。
因为行顺序 = 技能优先级，BasicAttack(ChanceToUse=1.0) 是兜底，排在它之后的技能永远轮不到。
"""
import os
import struct

sys_path_added = False


def _ensure_syspath():
    global sys_path_added
    if sys_path_added:
        return
    import sys
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, '..', 'mods', 'hardmode'),
                 os.path.join(here, '..', '..', 'mods', 'hardmode')):
        p = os.path.abspath(cand)
        if os.path.isdir(p) and p not in sys.path:
            sys.path.insert(0, p)


_ensure_syspath()
from eotu_stats import Table            # noqa: E402
from uasset_rename import UAsset        # noqa: E402

TAG = b'\xc1\x83\x2a\x9e'
ROW_LEN = 111
OFF_ROWNAME = 0
OFF_CREATURE = 33
OFF_ABILITY = 66
OFF_LEVEL = 99


def _name_of(t, v):
    i, _ = struct.unpack('<ii', v.raw[:8])
    return t._n(i)


def _find_stream(ux, table):
    """稳健定位 (NumRows偏移, 行流起点, 行流终点, 末行模板字节)。"""
    n = len(ux)
    if ux[-4:] != TAG:
        raise RuntimeError('uexp 包尾 tag 不对')
    nrows = len(table.rows)
    for off in range(0, 120):
        if off + 4 > n or struct.unpack_from('<i', ux, off)[0] != nrows:
            continue
        start = off + 4
        try:
            rows, end, _ = table._walk(start)
        except Exception:
            continue
        if len(rows) == nrows and end == n - 4:
            p, last = start, None
            while p < end:
                q = p + 8
                while True:
                    ni, _ = struct.unpack_from('<ii', ux, q)
                    q += 8
                    if table._n(ni) == 'None':
                        break
                    ti, _ = struct.unpack_from('<ii', ux, q)
                    q += 8
                    pt = table._n(ti)
                    size = struct.unpack_from('<i', ux, q)[0]
                    q += 8
                    if pt == 'StructProperty':
                        q += 24
                    elif pt in ('EnumProperty', 'ByteProperty'):
                        q += 8
                    elif pt == 'BoolProperty':
                        q += 1
                    g = ux[q]
                    q += 1
                    if g:
                        q += 16
                    q += size
                last = (p, q)
                p = q
            if p == end and last and last[1] - last[0] == ROW_LEN:
                return off, start, end, bytearray(ux[last[0]:last[1]])
    raise RuntimeError('找不到 RowMap 的 NumRows / 行流')


def _row_field(ux, t, pos, field):
    """读某行起始偏移 pos 的 FName 字段（creature/ability）或 int（level）。"""
    if field == 'creature':
        i, _ = struct.unpack_from('<ii', ux, pos + OFF_CREATURE)
        return t._n(i)
    if field == 'ability':
        i, _ = struct.unpack_from('<ii', ux, pos + OFF_ABILITY)
        return t._n(i)
    if field == 'level':
        return struct.unpack_from('<i', ux, pos + OFF_LEVEL)[0]
    raise ValueError(field)


def add_rows(uasset_path, uexp_path, out_uasset, out_uexp, specs,
             insert_before=None):
    """specs: [{'row_name','creature','ability','level'}, ...]

    insert_before: 可选 dict {'creature': str, 'level': int, 'ability': str}，
      所有新行插到该 (生物,等级,技能) 行之前；找不到则回退到该 (生物,等级) 的
      BasicAttack 行之前；再找不到就追加到行流末尾。

    返回统计 dict。输入文件不改。
    """
    t = Table(uasset_path, uexp_path)
    ux = bytes(t.uexp)
    ua = bytes(t.uasset)
    num_off, start, end, tmpl = _find_stream(ux, t)
    n_add = len(specs)
    if n_add == 0:
        open(out_uasset, 'wb').write(ua)
        open(out_uexp, 'wb').write(ux)
        return {'added': 0}

    u = UAsset(ua, len(ux) - 4)
    needed = []
    for s in specs:
        needed += [s['row_name'], s['creature'], s['ability']]
    for name in needed:
        if name not in u.names:
            if not u.add_name(name):
                raise RuntimeError(f'add_name 失败: {name}')
    new_ua = bytearray(u.d)
    names = list(u.names)

    base = u.exports[0]['base']
    old_ss = u.exports[0]['serial_size']
    if old_ss != len(ux) - 4:
        raise RuntimeError(f'serial_size {old_ss} != uexp-4 {len(ux)-4}')
    struct.pack_into('<q', new_ua, base + 28, old_ss + ROW_LEN * n_add)
    if struct.unpack_from('<q', new_ua, base + 36)[0] != u.total_header:
        raise RuntimeError('serial_offset 与 total_header 不一致')

    chunks = []
    for s in specs:
        row = bytearray(tmpl)
        struct.pack_into('<ii', row, OFF_ROWNAME, names.index(s['row_name']), 0)
        struct.pack_into('<ii', row, OFF_CREATURE, names.index(s['creature']), 0)
        struct.pack_into('<ii', row, OFF_ABILITY, names.index(s['ability']), 0)
        struct.pack_into('<i', row, OFF_LEVEL, int(s['level']))
        chunks.append(bytes(row))
    block = b''.join(chunks)

    # 决定插入位置
    at = end  # 默认追加末尾
    if insert_before:
        want_c, want_lv, want_ab = (insert_before.get('creature'),
                                    insert_before.get('level'),
                                    insert_before.get('ability', 'BasicAttack'))
        # 先找精确锚点（在目标生物/等级段内，从后往前找 BasicAttack/指定技能）
        hits = []
        p = start
        while p < end:
            c = _row_field(ux, t, p, 'creature')
            lv = _row_field(ux, t, p, 'level')
            ab = _row_field(ux, t, p, 'ability')
            if c == want_c and lv == int(want_lv) and ab == want_ab:
                hits.append(p)
            p += ROW_LEN
        if hits:
            at = hits[0]
        else:
            # 回退：该生物该等级的 BasicAttack 行
            p = start
            while p < end:
                if (_row_field(ux, t, p, 'creature') == want_c
                        and _row_field(ux, t, p, 'level') == int(want_lv)
                        and _row_field(ux, t, p, 'ability') == 'BasicAttack'):
                    at = p
                    break
                p += ROW_LEN

    new_ux = bytearray(ux[:at] + block + ux[at:])
    struct.pack_into('<i', new_ux, num_off, len(t.rows) + n_add)
    if new_ux[-4:] != TAG:
        raise RuntimeError('包尾 tag 丢失')

    open(out_uasset, 'wb').write(bytes(new_ua))
    open(out_uexp, 'wb').write(bytes(new_ux))

    # 回读校验
    t2 = Table(out_uasset, out_uexp)
    if len(t2.rows) != len(t.rows) + n_add:
        raise RuntimeError(f'回读行数 {len(t2.rows)} != {len(t.rows)}+{n_add}')
    u2 = UAsset(bytes(new_ua), len(new_ux) - 4)
    if u2.exports[0]['serial_size'] != len(new_ux) - 4:
        raise RuntimeError('serial_size 校验失败')
    if u2.exports[0]['serial_offset'] != u2.total_header:
        raise RuntimeError('serial_offset 校验失败')

    # 逐行核对：新增行的 (生物,技能,等级) 正确
    # 新增行插在 at 之前，其在 table.rows 里的顺序 = start 偏移 + at 之前的行数
    before_rows = (at - start) // ROW_LEN
    for i, s in enumerate(specs):
        rn, props = t2.rows[before_rows + i]
        d = {v.name: v for v in props}
        if rn != s['row_name']:
            raise RuntimeError(f'第{i}行行名 {rn} != {s["row_name"]}')
        if _name_of(t2, d['CreatureName']) != s['creature']:
            raise RuntimeError(f'第{i}行生物不符')
        if _name_of(t2, d['AbilityName']) != s['ability']:
            raise RuntimeError(f'第{i}行技能不符')
        if d['Level'].get_int() != int(s['level']):
            raise RuntimeError(f'第{i}行等级不符')

    return {'added': n_add, 'insert_at_row': before_rows,
            'names_added': len(u.names) - len(t.names),
            'uexp': len(new_ux), 'serial_size': u2.exports[0]['serial_size']}
