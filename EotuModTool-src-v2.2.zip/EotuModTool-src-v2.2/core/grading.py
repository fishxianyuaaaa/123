# -*- coding: utf-8 -*-
"""预设调色滤镜：等长改写 ColourGrading LUT 贴图的颜色通道。

20 张场景 LUT 结构完全一致（PF_B8G8R8A8，uexp 16697B）：
  * 像素区 @288 起 16384B = 4096 像素(256×16)，每像素 4B。
  * byte0 恒为 255（alpha/填充），byte1/2/3 是三个颜色通道，对其进行调色变换。
  * .uasset 不动，uexp 长度不变 → 安全可回退（删 pak 即还原）。

预设对三个颜色通道做逐像素变换，保持 LUT 的查找表语义（输入索引不变）。
"""
import hashlib
import json
import os

from . import paths

PX_OFF = 288
PX_LEN = 16384
LUT_LIST = [
    'Africa_LUT', 'BeachTable26Sept', 'BeachTable27Sept', 'Beach__Remastered_LUT',
    'Chowder_LUT', 'ColorGrade15', 'ColorGradeBeach4', 'EcuadorLUT', 'EcuadorLUT1',
    'EcuadorLUT2', 'FormicariumUG_LUT', 'Formicarium_Overground_LUT',
    'MossLab_Dead_Overground_LUT', 'MossLab_Dead_UG_LUT', 'MossLab_Overground_LUT',
    'NoAntsLand_LUT', 'Rotting_Log_LUT', 'Scorched_Earth_LUT', 'Scotland_LUT', 'SwampLUT',
]
LUT_ZH = {
    'Africa_LUT': '非洲草原', 'BeachTable26Sept': '海滩 26', 'BeachTable27Sept': '海滩 27',
    'Beach__Remastered_LUT': '海滩重制', 'Chowder_LUT': '杂烩', 'ColorGrade15': '调色 15',
    'ColorGradeBeach4': '海滩调色 4', 'EcuadorLUT': '厄瓜多尔', 'EcuadorLUT1': '厄瓜多尔 1',
    'EcuadorLUT2': '厄瓜多尔 2', 'FormicariumUG_LUT': '蚁巢地下',
    'Formicarium_Overground_LUT': '蚁巢地面', 'MossLab_Dead_Overground_LUT': '苔藓实验室·枯',
    'MossLab_Dead_UG_LUT': '苔藓实验室·枯地下', 'MossLab_Overground_LUT': '苔藓实验室',
    'NoAntsLand_LUT': '无蚁之地', 'Rotting_Log_LUT': '腐木', 'Scorched_Earth_LUT': '焦土',
    'Scotland_LUT': '苏格兰', 'SwampLUT': '沼泽',
}

# 预设：名称 -> 参数 dict。变换对每个颜色通道 c(0~255)：
#   c' = clamp((c-128)*contrast + 128 + brightness) * (1 + tint)
# 黑白：rgb 三通道取加权灰度后按 mix 混合。
PRESETS = {
    'warm': dict(label='暖阳', label_en='Warm Sunlight',
                 desc='偏暖金黄，提亮中间调', desc_en='Golden warm tone, brighter midtones',
                 brightness=10, contrast=1.08, gamma=0.95,
                 tint_r=1.10, tint_g=1.02, tint_b=0.88, gray=0.0),
    'cool': dict(label='冷冽', label_en='Cool Breeze',
                 desc='偏冷青蓝，清爽', desc_en='Cool cyan-blue, crisp',
                 brightness=4, contrast=1.05, gamma=1.02,
                 tint_r=0.88, tint_g=1.02, tint_b=1.12, gray=0.0),
    'vintage': dict(label='复古', label_en='Vintage Film',
                    desc='低对比偏黄褐，胶片感', desc_en='Low-contrast sepia, film look',
                    brightness=6, contrast=0.88, gamma=1.08,
                    tint_r=1.06, tint_g=0.98, tint_b=0.82, gray=0.0),
    'contrast': dict(label='高对比', label_en='High Contrast',
                     desc='加深暗部提亮亮部', desc_en='Deeper shadows, brighter highlights',
                     brightness=0, contrast=1.30, gamma=1.0,
                     tint_r=1.0, tint_g=1.0, tint_b=1.0, gray=0.0),
    'mono': dict(label='黑白', label_en='Black & White',
                 desc='去色黑白', desc_en='Desaturated monochrome',
                 brightness=0, contrast=1.10, gamma=1.0,
                 tint_r=1.0, tint_g=1.0, tint_b=1.0, gray=1.0),
}


def _clamp255(v):
    return 0 if v < 0 else (255 if v > 255 else int(v + 0.5))


def _transform(channels, p):
    """对 3 个颜色通道做调色。channels = [c1,c2,c3]。"""
    gray = p.get('gray', 0.0)
    if gray:
        lum = 0.299 * channels[0] + 0.587 * channels[1] + 0.114 * channels[2]
        channels = [c * (1 - gray) + lum * gray for c in channels]
    tints = (p.get('tint_r', 1.0), p.get('tint_g', 1.0), p.get('tint_b', 1.0))
    out = []
    for c, tint in zip(channels, tints):
        v = (c - 128) * p.get('contrast', 1.0) + 128 + p.get('brightness', 0)
        v = v * tint
        # gamma：1.0 不变；<1 提亮中间调，>1 压暗中间调
        g = p.get('gamma', 1.0)
        if g and g != 1.0:
            v = 255.0 * ((max(0.0, min(255.0, v)) / 255.0) ** g)
        out.append(_clamp255(v))
    return out


PARAM_KEYS = ('brightness', 'contrast', 'gamma', 'tint_r', 'tint_g', 'tint_b', 'gray')
PARAM_LIMITS = {
    'brightness': (-80.0, 80.0), 'contrast': (0.4, 2.5), 'gamma': (0.4, 2.5),
    'tint_r': (0.4, 1.8), 'tint_g': (0.4, 1.8), 'tint_b': (0.4, 1.8),
    'gray': (0.0, 1.0),
}


def normalize_params(raw):
    """校验并限制自定义参数，返回完整参数 dict。"""
    if not isinstance(raw, dict):
        raise ValueError('滤镜参数格式错误')
    out = {}
    for k in PARAM_KEYS:
        try:
            v = float(raw.get(k, PRESETS['warm'].get(k, 1.0 if k not in ('brightness', 'gray') else 0.0)))
        except (TypeError, ValueError):
            raise ValueError(f'滤镜参数 {k} 需要数字')
        lo, hi = PARAM_LIMITS[k]
        if not (lo <= v <= hi):
            raise ValueError(f'滤镜参数 {k} 超出范围（{lo} ~ {hi}）')
        out[k] = round(v, 4)
    return out


def _custom():
    c = paths.get_cfg().get('grading_custom') or []
    return c if isinstance(c, list) else []


def resolve(spec):
    """spec 可以是预设 key、自定义 key，或 {key,label,params} 字典。"""
    if isinstance(spec, dict):
        key = str(spec.get('key') or 'custom')
        p = dict(spec)
        p['params'] = normalize_params(spec.get('params') or {})
        p.setdefault('label', p.get('params') and '自定义调色' or '自定义调色')
        p.setdefault('label_en', 'Custom')
        p.setdefault('desc', '自定义参数调色')
        p.setdefault('desc_en', 'Custom color grading')
        return key, p
    key = str(spec)
    if key in PRESETS:
        base = PRESETS[key]
        return key, dict(base, params=normalize_params(base))
    for c in _custom():
        if c.get('key') == key:
            return key, dict(c, params=normalize_params(c.get('params') or {}))
    raise ValueError('未知滤镜预设：' + key)


def save_custom(name, params):
    """保存一个自定义预设，返回它（含唯一 key）。"""
    name = str(name or '').strip()[:24] or '自定义调色'
    p = normalize_params(params)
    key = 'custom_' + hashlib.sha1(json.dumps(p, sort_keys=True).encode()).hexdigest()[:8]
    items = _custom()
    for c in items:
        if c.get('key') == key:
            c['label'] = name
            break
    else:
        items.append(dict(key=key, label=name, label_en=name,
                          desc='自定义参数调色', desc_en='Custom color grading',
                          params=p, custom=True))
    paths.set_cfg(grading_custom=items)
    return dict(next(c for c in items if c.get('key') == key))


def delete_custom(key):
    items = [c for c in _custom() if c.get('key') != key]
    paths.set_cfg(grading_custom=items)
    return items


def catalog():
    custom = _custom()
    return dict(ok=True, presets=[
        dict(key=k, label=v['label'], label_en=v.get('label_en', v['label']),
             desc=v.get('desc', ''), desc_en=v.get('desc_en', ''),
             params=normalize_params({q: v.get(q, PRESETS['warm'].get(q, 0))
                                      for q in PARAM_KEYS}),
             custom=bool(v.get('custom')))
        for k, v in list(PRESETS.items()) + [(c['key'], c) for c in custom]
    ], luts=[dict(key=n, label=LUT_ZH.get(n, n), en=n) for n in LUT_LIST],
        count=len(LUT_LIST), params=PARAM_LIMITS)


def apply(spec, stage, log):
    """把预设/自定义参数应用到全部 LUT，写入 stage。返回写入的相对路径列表。"""
    key, p = resolve(spec)
    params = p['params']
    written = []
    rel_dir = 'EotU/Content/Assets/Textures/ColourGrading'
    out_dir = os.path.join(stage, *rel_dir.split('/'))
    os.makedirs(out_dir, exist_ok=True)
    for name in LUT_LIST:
        uexp = os.path.join(paths.asset('grading', 'uexp'), name + '.uexp')
        uasset = os.path.join(paths.asset('grading', 'uasset'), name + '.uasset')
        if not os.path.isfile(uexp) or not os.path.isfile(uasset):
            raise RuntimeError('缺少 LUT 资产：' + name)
        data = bytearray(open(uexp, 'rb').read())
        if len(data) != PX_OFF + PX_LEN + 25:
            raise RuntimeError(f'{name} 结构异常（长度 {len(data)}）')
        # 逐像素改 byte1/2/3，byte0(alpha) 不动
        for i in range(PX_LEN // 4):
            off = PX_OFF + i * 4
            chans = [data[off + 1], data[off + 2], data[off + 3]]
            new = _transform(chans, params)
            data[off + 1], data[off + 2], data[off + 3] = new
        open(os.path.join(out_dir, name + '.uexp'), 'wb').write(bytes(data))
        # uasset 原样复制（不修改）
        open(os.path.join(out_dir, name + '.uasset'), 'wb').write(
            open(uasset, 'rb').read())
        written += [rel_dir + '/' + name + '.uasset', rel_dir + '/' + name + '.uexp']
    log.append(f'  调色滤镜「{p["label"]}」已应用到 {len(LUT_LIST)} 张场景 LUT（{key}）')
    return written


def verify(spec, stage, log):
    """回读：确认至少一张 LUT 的像素确实变化，且长度不变。"""
    _, p = resolve(spec)
    rel = os.path.join(stage, 'EotU', 'Content', 'Assets', 'Textures',
                       'ColourGrading', 'Africa_LUT.uexp')
    src = os.path.join(paths.asset('grading', 'uexp'), 'Africa_LUT.uexp')
    if not os.path.isfile(rel):
        return 0
    a = open(src, 'rb').read()
    b = open(rel, 'rb').read()
    if len(a) != len(b):
        raise RuntimeError('LUT 长度变化')
    changed = sum(1 for i in range(PX_LEN // 4)
                  if a[PX_OFF + i * 4 + 1:PX_OFF + i * 4 + 4]
                  != b[PX_OFF + i * 4 + 1:PX_OFF + i * 4 + 4])
    if changed == 0:
        raise RuntimeError('滤镜未生效：像素无变化')
    log.append(f'  滤镜回读校验：Africa_LUT {changed} 个像素已改变，长度不变')
    return changed
