# -*- coding: utf-8 -*-
"""技能显示名：把 Abilities 的行名（BWSVenomStrike 之类）翻成可读中文。

游戏表里没有技能显示名字段，只有行名；本模块用「生物前缀 + 动作词」拆词翻译。
翻译只用于工具界面显示，不改游戏资产；查不到时保留英文行名。
"""
import re

# 生物/系列前缀（按长度倒序匹配）
PREFIX = {
    'BlackAntSelf': '黑蚁自保', 'BlackAnt': '黑蚁',
    'AfricanGiantCentipede': '非洲巨型蜈蚣', 'AlligatorbackScorpion': '鳄背蝎',
    'Alligatorback': '鳄背蝎', 'ArmyAntMajor': '行军蚁大兵', 'ArmyAnt': '行军蚁',
    'AssassinBug': '猎蝽', 'AfricanTigerBeetle': '非洲虎甲', 'AfricanGiantCentipede': '非洲巨型蜈蚣',
    'BeachTigerBeetle': '海滩虎甲', 'BHSuperSoldier': '大头蚁超级兵',
    'Bullfrog': '牛蛙', 'BulletAnt': '子弹蚁', 'DCHAdult': '魔鬼隐翅虫',
    'DriverAntSuperSoldier': '黑行军蚁超级兵', 'DriverAnt': '黑行军蚁',
    'DwarfSalamander': '侏儒蝾螈', 'Earwig': '蠼螋', 'EasternNewt': '东方蝾螈',
    'EmperorScorpionJuvenile': '帝王蝎幼体', 'EmperorScorpion': '帝王蝎',
    'EuropeanShoreCrab': '欧洲滨蟹', 'EuropeanShore': '欧洲滨蟹',
    'ExplodingTermiteWorker': '爆炸白蚁工蚁',
    'ExplodingTermiteSoldier': '爆炸白蚁兵蚁', 'ExplodingTermite': '爆炸白蚁',
    'ExplodingAntMajorSoldier': '爆炸蚁大兵', 'ExplodingAnt': '爆炸蚁',
    'FireAntWorker': '火蚁工蚁', 'FireAnt': '火蚁',
    'FishingSpider': '渔蛛', 'Frog': '蛙', 'GAMJuvenile': '大齿猛蚁幼体',
    'GAMLarge': '大齿猛蚁大型', 'GAM': '大齿猛蚁', 'AGCJuvenile': '巨扁锹甲幼体',
    'AGC': '巨扁锹甲', 'GreenJumper': '绿跳蛛', 'HCRegenerate': '寄居蟹再生',
    'HermitCrab': '寄居蟹', 'HermitScorpion': '隐居蝎',
    'HuntsmanSpider': '猎人蛛', 'Huntsman': '猎人蛛', 'JumpingSpider': '跳蛛',
    'LeafcutterSupermajor': '切叶蚁超大型兵', 'LeafcutterMedia': '切叶蚁中型兵',
    'LeafcutterMajor': '切叶蚁大兵', 'Leafcutter': '切叶蚁',
    'LargeHermitCrab': '大型寄居蟹', 'LargeSandBear': '大型沙熊',
    'LittleBlackAnt': '小黑蚁', 'LynxSpider': '猫蛛', 'MatabeleAnesthetist': '马塔贝勒麻醉蚁',
    'MatabeleMedic': '马塔贝勒医蚁', 'MatabeleSoldier': '马塔贝勒兵蚁', 'Matabele': '马塔贝勒蚁',
    'NarrowMouthedToad': '窄口蟾蜍', 'NianBeast': '年兽', 'NorthernDunes': '北部沙丘',
    'PrayingSpider': '螳螂蛛', 'Queen': '蚁后', 'RainbowLizardJuvenile': '彩虹蜥幼体',
    'RainbowLizard': '彩虹蜥', 'RoughGreenSnake': '糙鳞绿树蛇',
    'RVA': '红箭毒蛙', 'SandBear': '沙熊', 'SandLizard': '沙蜥',
    'Scorpion': '蝎', 'SpinyDevil': '棘魔蝎', 'StinkAnt': '臭蚁',
    'SunSpiderJuvenile': '太阳蛛幼体', 'SunSpider': '太阳蛛',
    'TarantulaDragonFly': '捕鸟蛛蜻蜓', 'TermiteMajorSoldier': '白蚁大兵',
    'TermiteSoldier': '白蚁兵蚁', 'TrapjawAnt': '大齿猛蚁',
    'TreeFrog': '树蛙', 'VelvetWorm': '天鹅绒虫', 'WhipMantis': '鞭螳螂',
    'WhipSpiderling': '鞭蛛幼体', 'WhipSpider': '鞭蛛', 'WoodAnt': '木蚁',
    'Woodlouse': '鼠妇', 'YungVelvetWorm': '幼天鹅绒虫',
    # 三字母缩写
    'BWS': '海滩狼蛛', 'BTB': '海滩虎甲', 'DCHA': '魔鬼隐翅虫', 'GBS': '绿头蝇',
    'HCR': '寄居蟹', 'HC': '寄居蟹', 'LB': '瓢虫', 'MC': '行军蚁', 'PM': '大齿猛蚁',
    'Harvestman': '盲蛛', 'Trapjaw': '大齿猛蚁', 'Frog': '蛙', 'LynxSpider': '猫蛛',
    'RBA': '红隐翅虫', 'RBB': '蓝隐翅虫', 'SD': '棘魔蝎', 'SSTB': '沙蝎甲虫',
    'WS': '鞭蛛', 'JS': '跳蛛', 'FBB': '火甲虫', 'BB': '甲虫', 'FB': '火甲虫',
}

# 动作词（小写匹配）
ACTION = {
    'basicattack': '普通攻击', 'aoebasicattack': '范围普攻', 'attack': '攻击',
    'spray': '喷射', 'squirt': '射液', 'venomstrike': '毒液突刺', 'venomjab': '毒针',
    'venom': '毒液', 'strike': '突刺', 'devour': '吞噬', 'regenerate': '再生',
    'selfslow': '自我减速', 'slow': '减速', 'fast': '加速', 'stun': '眩晕',
    'paralysis': '麻痹', 'taunt': '嘲讽', 'invulnerable': '无敌', 'sharp': '利刃',
    'resilient': '坚韧', 'secondwind': '回光返照', 'fiercemother': '凶母',
    'fmevent': '凶母事件', 'royaldecree': '王室诏令', 'royalguard': '皇家卫兵',
    'damageselfstun': '反震眩晕', 'selfpresevation': '自保',
    'spikes': '尖刺', 'aoe': '范围', 'smallaoe': '小范围', 'bunker': '筑堡',
    'stunaoe': '范围眩晕', 'snatch': '抓取', 'sneek': '潜行', 'lunge': '猛扑',
    'backup': '后撤', 'backoff': '退避', 'backaway': '退避', 'sideskip': '侧移',
    'sidestep': '侧移', 'puncture': '穿刺', 'push': '推击', 'escape': '逃脱',
    'flee': '逃跑', 'retreat': '撤退', 'flinch': '畏缩', 'bunker': '筑堡',
    'greatescape': '大逃脱', 'relocate': '转移', 'returnhome': '归巢',
    'sting': '蛰刺', 'laststand': '背水一战', 'lastlaugh': '狂笑',
    'riding': '骑乘', 'bite': '啃咬', 'wingbuffet': '振翅', 'wingdash': '振翅冲撞',
    'buff': '增益', 'wipe': '横扫', 'hop': '跳跃', 'jump': '跳跃', 'eat': '吞食',
    'consum': '吞食', 'consume': '吞食', 'groundslap': '拍地', 'scoop': '铲取',
    'poison': '毒', 'lowhealth': '低血', 'tongueshot': '舌击', 'largetongueshot': '巨舌击',
    'grabbytongue': '黏舌抓取', 'ram': '冲撞', 'crush': '碾压', 'faceprant': '扑倒',
    'faceplant': '扑倒', 'gasterflag': '腹部旗语', 'thump': '重击',
    'medic': '医蚁治疗', 'anesthetist': '麻醉蛰刺', 'preserveaura': '守护光环',
    'soldier': '兵蚁', 'cripple': '致残', 'enrage': '狂暴', 'rampage': '暴走',
    'attract': '引诱', 'cleave': '劈砍', 'clawsnap': '钳击', 'clawcrush': '钳碎',
    'snapsnapsnap': '连环钳击', 'personalspace': '领域震慑', 'frenzy': '狂乱',
    'grabandsting': '抓刺', 'exercute': '处决', 'execute': '处决', 'wallbash': '撞墙',
    'transition': '形态切换', 'drain': '吸食', 'legloss': '掷腿', 'legtoss': '掷腿',
    'thousandtarus': '千足践踏', 'hundredtarus': '百足践踏', 'bodyslam': '冲撞',
    'inject': '注毒', 'legflinch': '腿伤退缩', 'flinch': '畏缩', 'choochoo': '疾驰',
    'tailpincor': '尾钳', 'firetongue': '火舌', 'legit': '立正', 'shellcrack': '碎壳',
    'clawnudge': '轻钳', 'swoop': '俯冲', 'charge': '冲锋',
    'explode': '自爆', 'hunkerdown': '坚守', 'snapsurface': '地表爆破',
    'snapunderground': '地下爆破', 'tantrum': '暴怒', 'strafe': '横移扫射',
    'clawbash': '钳击', 'chopsticks': '筷击', 'bury': '潜埋', 'unbury': '出土',
    'concussion': '震荡', 'burstofspeed': '疾速爆发', 'chomp': '大口撕咬',
    'flinch_small': '小型畏缩', 'strike_small': '小型攻击', 'weak': '弱化',
    'toxicskin': '毒性皮肤', 'toxic': '毒性', 'skin': '皮肤', 'swipe': '横扫',
    'mesmerise': '催眠', 'mesmerize': '催眠',
}

# 修饰词（拆词后逐词匹配）
WORD = {
    'uber': '强化', 'small': '小型', 'med': '中型', 'medium': '中型',
    'very': '超', 'large': '大型', 'huge': '巨型', 'major': '大兵',
    'supermajor': '超大兵', 'juvenile': '幼体', 'weak': '弱化', 'worker': '工蚁',
    'self': '自我', 'low': '低', 'health': '血', 'second': '第二', 'wind': '风',
    'fire': '火', 'leg': '腿', 'wing': '翼', 'body': '身体', 'tail': '尾',
    'claw': '钳', 'legit': '立正', 'great': '大', 'back': '后', 'up': '进',
    'side': '侧', 'step': '步', 'shell': '甲壳', 'ground': '地面', 'tongue': '舌',
    'shot': '射', 'speed': '速度', 'burst': '爆发', 'of': '', 'and': '',
    'battle': '战斗', 'basic': '普通', 'aoe': '范围', 'damage': '伤害',
    # 缩写前缀出现在 Uber 后面时也要能翻（UberBWSVenomStrike 等）
    'bws': '海滩狼蛛', 'btb': '海滩虎甲', 'dcha': '魔鬼隐翅虫', 'gbs': '绿头蝇',
    'hc': '寄居蟹', 'sd': '棘魔蝎', 'pm': '大齿猛蚁', 'ws': '鞭蛛', 'js': '跳蛛',
    'rva': '红箭毒蛙', 'bb': '甲虫', 'fbb': '火甲虫', 'agc': '巨扁锹甲',
    'gam': '大齿猛蚁', 'mc': '行军蚁', 'lb': '瓢虫', 'sstb': '沙蝎甲虫',
}

_SUFFIX_NUM = {'1': 'Ⅰ', '2': 'Ⅱ', '3': 'Ⅲ', '4': 'Ⅳ', '5': 'Ⅴ'}

# 全名精确覆盖（优先于拆词）
EXACT = {
    'Default': '默认（未使用）', 'BasicAttack': '普通攻击',
    'UberAOEBasicAttack': '强化范围普攻', 'UberAOESmallBasicAttack': '强化小范围普攻',
    'WoodlouseBunker': '鼠妇筑堡', 'GreenJumperBuff': '绿跳蛛增益',
    'FrogWipe': '青蛙横扫', 'FrogHop': '青蛙跳跃',
    'QueenSecondWind': '蚁后回光返照', 'QueenFierceMother': '蚁后凶母',
    'QueenFMEvent': '蚁后凶母事件', 'QueenRoyalDecree': '蚁后诏令',
    'QueenRoyalGuard': '蚁后禁卫', 'BlackAntSelfPresevation': '黑蚁自保',
    'FireAntLastStand': '火蚁背水一战', 'FireAntLastLaugh': '火蚁狂笑',
    'FireAntRiding': '火蚁骑乘', 'LeafcutterInvulnerable': '切叶蚁无敌',
    'LeafcutterSharp': '切叶蚁利刃', 'LeafcutterResilient': '切叶蚁坚韧',
    'SandLizardBurstOfSpeed': '沙蜥疾速爆发', 'SandLizardChomp': '沙蜥撕咬',
    'HermitScorpionShellCrack': '隐居蝎碎壳', 'HermitScorpionClawNudge': '隐居蝎轻钳',
    'StinkAntAttract': '臭蚁引诱', 'StinkAntCleave': '臭蚁劈砍',
    # Steam 新版（Beach Brawl + SWAMPED!）新增生物技能（只写动作，生物前缀由显示层加）
    'EasternNewtToxicSkin_Adult': '毒性皮肤',
    'EasternNewtSwipe_Adult': '横扫',
    'EasternNewtChomp_Adult': '大口撕咬',
    'EasternNewtExercute_Adult': '处决',
    'RoughGreenSnakeConsume': '吞食',
    'RoughGreenSnakeMesmerise': '催眠',
}


def _prefix_cn(name):
    for p in sorted(PREFIX, key=len, reverse=True):
        if name.startswith(p):
            return p, PREFIX[p]
    return '', ''


def owner_hint(name):
    """无使用者时，从行名前缀猜一个所属生物中文名。"""
    _, cn = _prefix_cn(name)
    return cn or ''


def _humanize_prefix(p):
    """把 EasternNewt / BWS 这类行名前缀转成可读英文。"""
    if not p:
        return ''
    if p.isupper():
        return p
    return re.sub(r'(?<=[a-z0-9])(?=[A-Z])', ' ', p)


def owner_hint_en(name):
    """无使用者时，从行名前缀猜一个所属生物英文名。"""
    p, _ = _prefix_cn(name)
    return _humanize_prefix(p)


def translate(name):
    """技能行名 -> 中文技能名（只用于界面显示）。"""
    if name in EXACT:
        return EXACT[name]
    rest = name
    uber = False
    if rest.startswith('Uber'):
        uber = True
        rest = rest[4:]
    prefix_cn = ''
    # 先去掉生物前缀（Uber 强化保留在动作里）
    p, pc = _prefix_cn(rest)
    if p and len(p) < len(rest):
        rest = rest[len(p):]
        prefix_cn = pc
    # 处理尾缀 _Weak/_Small 等和结尾数字
    tail_cn = ''
    for suf in ('_VerySmall', '_Small', '_Med', '_Medium', '_Huge', '_Weak'):
        if rest.endswith(suf):
            tail_cn = WORD.get(suf[1:].lower(), '')
            rest = rest[:-len(suf)]
            break
    m = re.search(r'(\d+)$', rest)
    num_cn = ''
    if m:
        raw = m.group(1)
        num_cn = _SUFFIX_NUM.get(raw, raw + '%' if int(raw) >= 10 else raw)
        rest = rest[:m.start()]
    # 整体动作词优先（VenomStrike 等合成词）
    key = rest.lower()
    if key in ACTION:
        core = ACTION[key]
    else:
        # 拆 CamelCase：UberBWSVenomStrike -> Uber / Venom / Strike
        words = re.sub(r'(?<=[a-z0-9])(?=[A-Z])', ' ', rest)
        words = re.sub(r'(?<=[A-Z])(?=[A-Z][a-z])', ' ', words)
        parts = [w for w in re.split(r'[\s_]+', words) if w]
        zh = []
        for i, w in enumerate(parts):
            lw = w.lower()
            if lw in ('and', 'of'):
                continue
            if lw in ('uber', 'small', 'med', 'medium', 'very', 'large', 'huge',
                      'major', 'supermajor', 'juvenile', 'weak', 'worker'):
                zh.append(WORD[lw])
                continue
            # 后续单词逐个翻（可能的复合词按整段尝试）
            joined = ''.join(x.lower() for x in parts[i:])
            hit = None
            for length in range(min(4, len(parts) - i), 0, -1):
                cand = ''.join(x.lower() for x in parts[i:i + length])
                if cand in ACTION:
                    hit = (length, ACTION[cand])
                    break
            if hit:
                zh.append(hit[1])
                # 跳过已消费的词
                for _ in range(hit[0] - 1):
                    try:
                        parts.pop(i + 1)
                    except IndexError:
                        pass
            elif lw in WORD and WORD[lw]:
                zh.append(WORD[lw])
            else:
                zh.append(w)
        core = ''.join(zh)
    if uber:
        core = '强化' + core
    if prefix_cn and not core:
        core = prefix_cn
    return core + tail_cn + num_cn
