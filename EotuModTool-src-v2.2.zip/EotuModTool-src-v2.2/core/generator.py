# -*- coding: utf-8 -*-
"""按页面填写的内容生成 mod pak。

v2：数值（等长改值）+ 中文文案（locres 重建）+ 生物图标（贴图像素替换）。
所有改动都在生成前经 summary 汇总并由用户确认，生成时逐项回读校验。
"""
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import time

from . import icons, locres, paths, skills, grading
from .catalog import FIELD_MAP
from eotu_stats import Table

SCOPES = {
    'both': ['CreatureStats', 'CreatureStats_Freeplay'],
    'story': ['CreatureStats'],
    'freeplay': ['CreatureStats_Freeplay'],
}
SCOPE_LABEL = {'both': '剧情模式 + 自由模式', 'story': '仅剧情模式', 'freeplay': '仅自由模式'}
SCOPE_LABEL_EN = {'both': 'Story + Freeplay', 'story': 'Story only', 'freeplay': 'Freeplay only'}
PAK_VERSION = 'V11'
VERSION = '2.2'


def safe_name(text):
    s = re.sub(r'[\\/:*?"<>|\r\n\t]', '', (text or '').strip())
    return (s or '自定义模组')[:40]


def pak_filename(mod_name):
    return f'zzz_EotU_EothTool_{safe_name(mod_name)}_P.pak'


def token_of(payload):
    """改动内容的指纹：确认弹窗与真正生成必须是同一份数据。"""
    keys = ('mod_name', 'scope', 'note', 'changes', 'texts', 'icons',
            'skillValues', 'skillAssigns', 'grading')
    canon = {k: payload.get(k) for k in keys}
    raw = json.dumps(canon, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:16]


def _clean_stage():
    stage = paths.STAGE_DIR
    here = os.path.abspath(paths.APP_DIR)
    if os.path.commonpath([os.path.abspath(stage), here]) != here:
        raise RuntimeError('打包暂存目录越界，已中止')
    # 把旧 stage 整体改名归档（零文件删除），再建空目录。
    # 用 rename 代替 rmtree：不触发批量删除告警，旧内容可在 out/_stage_archive 追溯。
    if os.path.isdir(stage):
        import time as _time
        archive = os.path.join(paths.OUT_DIR, '_stage_archive')
        os.makedirs(archive, exist_ok=True)
        backup = os.path.join(archive, 'stage_' + _time.strftime('%Y%m%d_%H%M%S'))
        try:
            os.rename(stage, backup)
        except OSError:
            backup += '_' + str(int(_time.time() * 1000) % 100000)
            os.rename(stage, backup)
    os.makedirs(stage, exist_ok=True)
    return stage


def _validate(changes, log):
    """规范化数值改动；v2 允许为空（只改文案/图标）。"""
    if not isinstance(changes, dict):
        changes = {}
    out, warnings = {}, []
    for row, fields in changes.items():
        if not isinstance(fields, dict) or not fields:
            continue
        clean = {}
        for field, value in fields.items():
            meta = FIELD_MAP.get(field)
            if not meta:
                raise ValueError(f'未知字段：{field}')
            kind = meta['kind']
            if kind == 'enum':
                raise ValueError(f'「{meta["label"]}」是枚举字段，本版本不支持修改')
            if kind == 'bool':
                if not isinstance(value, bool):
                    raise ValueError(f'{row}.{meta["label"]} 需要真/假值')
                clean[field] = value
            elif kind == 'int':
                try:
                    v = int(value)
                except (TypeError, ValueError):
                    raise ValueError(f'{row}.{meta["label"]} 需要整数')
                if not (-2 ** 30 < v < 2 ** 30):
                    raise ValueError(f'{row}.{meta["label"]} 数值超出范围')
                clean[field] = v
            else:
                try:
                    v = float(value)
                except (TypeError, ValueError):
                    raise ValueError(f'{row}.{meta["label"]} 需要数字')
                if not math.isfinite(v) or abs(v) > 1e9:
                    raise ValueError(f'{row}.{meta["label"]} 数值超出范围')
                if meta['group'] == '防御' and field != 'Armour' and not (0 <= v <= 1):
                    warnings.append(f'{row}.{meta["label"]} = {v:g}（抗性类数值通常填 0 ~ 1）')
                clean[field] = v
        if clean:
            out[row] = clean
    if out:
        log.append(f'数值校验通过：{len(out)} 个生物、{sum(len(v) for v in out.values())} 项')
    return out, warnings


def _patch_table(tname, changes, stage, log):
    src = paths.table_src(tname, 'uexp')
    uas = paths.table_src(tname, 'uasset')
    t = Table(uas, src)
    index = {row: i for i, (row, _) in enumerate(t.rows)}
    applied, skipped = [], []
    for row, fields in changes.items():
        if row not in index:
            raise ValueError(f'{tname} 表里找不到生物「{row}」')
        i = index[row]
        for field, value in fields.items():
            meta = FIELD_MAP[field]
            try:
                v = t._find(i, field)
            except KeyError:
                skipped.append(f'{row}.{field}（该行没有此字段）')
                continue
            if meta['kind'] == 'float' and v.is_float:
                t.set_float(i, field, value)
            elif meta['kind'] == 'int' and v.is_int:
                t.set_int(i, field, value)
            elif meta['kind'] == 'bool' and v.type == 'BoolProperty':
                t.set_bool(i, field, value)
            else:
                skipped.append(f'{row}.{field}（类型不匹配：{v.type}）')
                continue
            applied.append((row, field, value))
    if len(t.uexp) != os.path.getsize(src):
        raise RuntimeError(f'{tname} 改写后文件长度变化，已中止（会破坏资产结构）')
    rel = paths.TABLE_PATHS[tname]
    uexp_out = os.path.join(stage, *rel.split('/')) + '.uexp'
    uasset_out = os.path.join(stage, *rel.split('/')) + '.uasset'
    os.makedirs(os.path.dirname(uexp_out), exist_ok=True)
    t.save(uexp_out, uasset_out)
    log.append(f'  {tname}：写入 {len(applied)} 项，文件长度不变')
    for s in skipped:
        log.append('  ! 跳过 ' + s)
    return uexp_out


def _verify_values(tname, uexp_out, changes, log):
    t = Table(uexp_out[:-5] + '.uasset', uexp_out)
    index = {row: i for i, (row, _) in enumerate(t.rows)}
    checked = 0
    for row, fields in changes.items():
        if row not in index:
            continue
        for field, want in fields.items():
            meta = FIELD_MAP[field]
            try:
                v = t._find(index[row], field)
            except KeyError:
                continue
            if meta['kind'] == 'float' and v.is_float:
                if abs(v.get_float() - want) > max(1e-4, abs(want) * 1e-6):
                    raise RuntimeError(f'{tname}.{row}.{field} 回读不一致')
            elif meta['kind'] == 'int' and v.is_int:
                if v.get_int() != int(want):
                    raise RuntimeError(f'{tname}.{row}.{field} 回读不一致')
            elif meta['kind'] == 'bool' and v.type == 'BoolProperty':
                if bool(v.bool_val) != bool(want):
                    raise RuntimeError(f'{tname}.{row}.{field} 回读不一致')
            checked += 1
    log.append(f'  {tname}：回读校验 {checked} 项全部一致')


def _md5(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def generate(payload):
    """payload: {mod_name, scope, changes, texts, icons, skillValues, skillAssigns,
    grading, note, confirmed, token}。"""
    if not payload.get('confirmed'):
        raise ValueError('未经确认：请先在改动汇总窗口点击「确认生成」')
    want_token = payload.get('token')
    if not want_token or want_token != token_of(payload):
        raise ValueError('改动汇总已过期或内容被修改，请重新点「生成 Mod」查看汇总')

    log = []
    mod_name = safe_name(payload.get('mod_name'))
    scope = payload.get('scope', 'both')
    if scope not in SCOPES:
        raise ValueError('生效模式无效')
    changes, warnings = _validate(payload.get('changes'), log)
    texts = payload.get('texts') or {}
    icon_changes = payload.get('icons') or {}
    cat = skills.catalog()
    skill_values, swarn = skills.validate_values(payload.get('skillValues') or {}, cat)
    warnings += swarn
    skill_assigns = skills.validate_assigns(payload.get('skillAssigns') or [], cat)
    grading_spec = payload.get('grading') or None
    if grading_spec:
        grading.resolve(grading_spec)  # 提前校验，防止确认后才发现参数非法
    if not (changes or texts or icon_changes or skill_values or skill_assigns or grading_spec):
        raise ValueError('没有任何改动')
    issues, _ = paths.check_environment()
    if issues:
        raise RuntimeError('环境不完整：' + '；'.join(issues))
    paths.ensure_dirs()
    log.append(f'模组名称：{mod_name}')
    log.append(f'生效范围：{SCOPE_LABEL[scope]}（{len(SCOPES[scope])} 张数据表）')

    stage = _clean_stage()
    for tname in SCOPES[scope]:
        uexp_out = _patch_table(tname, changes, stage, log)
        _verify_values(tname, uexp_out, changes, log)
    skill_written = skills.apply(skill_values, skill_assigns, stage, log, scope)
    if skill_values or skill_assigns:
        skills.verify(skill_values, skill_assigns, stage, log)
    grading_written = []
    if grading_spec:
        grading_written = grading.apply(grading_spec, stage, log)
        grading.verify(grading_spec, stage, log)
    text_written = locres.apply_changes(texts, stage, log)
    icon_written = icons.apply_changes(icon_changes, stage, log)

    # repak 用 ASCII 中间名打包，避免中文路径在部分环境下出问题
    tmp_pak = os.path.join(paths.OUT_DIR, '_eoth_build.pak')
    final_pak = os.path.join(paths.OUT_DIR, pak_filename(mod_name))
    if os.path.exists(tmp_pak):
        os.remove(tmp_pak)
    cmd = [paths.repak(), 'pack', '--version', PAK_VERSION, '--compression', 'Zlib', stage, tmp_pak]
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode != 0:
        err = (r.stderr or r.stdout or b'').decode('utf-8', 'replace')
        raise RuntimeError('打包失败：' + err[-600:])
    if not os.path.isfile(tmp_pak) or os.path.getsize(tmp_pak) == 0:
        raise RuntimeError('打包失败：没有生成 pak 文件')
    if os.path.exists(final_pak):
        os.remove(final_pak)
    shutil.move(tmp_pak, final_pak)

    lr = subprocess.run([paths.repak(), 'list', final_pak], capture_output=True)
    files = [l.strip() for l in (lr.stdout or b'').decode('utf-8', 'replace').splitlines() if l.strip()]
    expect = (2 * len(SCOPES[scope]) + len(text_written) + len(icon_written)
              + len(skill_written) + len(grading_written))
    if len(files) < expect or expect == 0:
        raise RuntimeError(f'pak 内文件数异常（实际 {len(files)}，预期至少 {expect}）')
    log.append(f'打包完成：{os.path.basename(final_pak)}，内含 {len(files)} 个资产文件')

    manifest = dict(
        tool='Eoth-Mod Tool', version=VERSION,
        mod_name=mod_name, scope=scope, scope_label=SCOPE_LABEL[scope],
        created=time.strftime('%Y-%m-%d %H:%M:%S'),
        note=payload.get('note', ''),
        changes=changes, texts=texts,
        icons={k: {kk: vv for kk, vv in v.items() if kk != 'image'}
               if isinstance(v, dict) else v for k, v in icon_changes.items()},
        skill_values=skill_values, skill_assigns=skill_assigns, grading=grading_spec,
        pak=os.path.basename(final_pak),
        size=os.path.getsize(final_pak), md5=_md5(final_pak), files=files,
    )
    with open(final_pak[:-4] + '.json', 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    # 记录「上次生成的模组名」，供前端做同名覆盖提醒（即使 pak 被手工删掉也认得）
    paths.set_cfg(last_mod_name=mod_name,
                  last_mod_pak=os.path.basename(final_pak),
                  last_mod_time=manifest['created'])
    return dict(
        ok=True, pak=final_pak, pak_name=os.path.basename(final_pak),
        size=manifest['size'], md5=manifest['md5'], files=files,
        scope=scope, scope_label=SCOPE_LABEL[scope], scope_label_en=SCOPE_LABEL_EN[scope],
        changed_creatures=len(changes),
        changed_values=sum(len(v) for v in changes.values()),
        changed_texts=len(texts), changed_icons=len(icon_changes),
        changed_skills=len(skill_values), assigned_skills=len(skill_assigns),
        grading=grading_spec,
        log=log, warnings=warnings,
    )
