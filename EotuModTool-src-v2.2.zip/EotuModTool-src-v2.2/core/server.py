# -*- coding: utf-8 -*-
"""本地 HTTP 服务（只监听 127.0.0.1），给软件界面提供数据与构建能力。"""
import json
import mimetypes
import os
import re
import subprocess
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import catalog, generator, icons, installer, locres, paths, summary, skills, grading

VERSION = '2.2'
_CATALOG_CACHE = None
_TEXT_CACHE = None
_ICON_CACHE = None
_SKILL_CACHE = None
_GRADING_CACHE = None
_CONFLICT_CACHE = {'t': 0.0, 'v': []}


def _conflicts():
    import time
    now = time.time()
    if now - _CONFLICT_CACHE['t'] < 30:
        return _CONFLICT_CACHE['v']
    try:
        _CONFLICT_CACHE['v'] = installer.conflicts()
    except Exception:
        _CONFLICT_CACHE['v'] = []
    _CONFLICT_CACHE['t'] = now
    return _CONFLICT_CACHE['v']


def _catalog():
    global _CATALOG_CACHE
    if _CATALOG_CACHE is None:
        _CATALOG_CACHE = catalog.build()
    return _CATALOG_CACHE


def _texts():
    global _TEXT_CACHE
    if _TEXT_CACHE is None:
        items, _ = locres.catalog()
        # 常用的菜单/致谢条目排在最前，打开页面就能改，不用翻好几页
        pinned = ['CreditsTitle', 'MainMenuCredits', 'CreditsOurArmy',
                  'CreditsSubstanceSharers', 'CreditsFollowingResources',
                  'MainMenu', 'MainMenuPlayOption', 'Arcade', 'Tutorial', 'InGameMenuTitle']
        gorder = {g['id']: i for i, g in enumerate(locres.GROUPS)}
        items.sort(key=lambda i: (0, pinned.index(i['key']), 0, '')
                   if i['key'] in pinned else (1, 0, gorder.get(i['group'], 9), i['label']))
        _TEXT_CACHE = dict(ok=True, groups=locres.GROUPS, items=items,
                           stats=dict(total=len(items),
                                      by_group={g['id']: sum(1 for i in items if i['group'] == g['id'])
                                                for g in locres.GROUPS}))
    return _TEXT_CACHE


def _icons():
    global _ICON_CACHE
    if _ICON_CACHE is None:
        items = icons.load_index()
        from . import taxonomy
        _ICON_CACHE = dict(ok=True, items=items, families=taxonomy.FAMILIES,
                           stats=dict(total=len(items),
                                      by_family={f['id']: sum(1 for i in items if i['family'] == f['id'])
                                                 for f in taxonomy.FAMILIES}))
    return _ICON_CACHE


def _skills():
    global _SKILL_CACHE
    if _SKILL_CACHE is None:
        _SKILL_CACHE = skills.catalog()
    return _SKILL_CACHE


def _grading():
    global _GRADING_CACHE
    if _GRADING_CACHE is None:
        _GRADING_CACHE = grading.catalog()
    return _GRADING_CACHE


def _json(handler, obj, code=200):
    body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    handler.send_response(code)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(body)))
    handler.send_header('Cache-Control', 'no-store')
    handler.end_headers()
    handler.wfile.write(body)


def _bytes(handler, data, ctype, cache=False):
    handler.send_response(200)
    handler.send_header('Content-Type', ctype)
    handler.send_header('Content-Length', str(len(data)))
    handler.send_header('Cache-Control', 'public, max-age=86400' if cache else 'no-store')
    handler.end_headers()
    handler.wfile.write(data)


def _static(handler, rel):
    base = os.path.abspath(paths.WEB_DIR)
    target = os.path.abspath(os.path.join(base, rel))
    if os.path.commonpath([target, base]) != base or not os.path.isfile(target):
        handler.send_error(404)
        return
    ctype = mimetypes.guess_type(target)[0] or 'application/octet-stream'
    if ctype.startswith('text/') or ctype in ('application/javascript', 'application/json'):
        ctype += '; charset=utf-8'
    _bytes(handler, open(target, 'rb').read(), ctype)


class Handler(BaseHTTPRequestHandler):
    server_version = 'EothModTool/' + VERSION

    def log_message(self, fmt, *args):
        pass

    def do_GET(self):
        path = self.path.split('?')[0]
        try:
            if path in ('/', '/index.html'):
                return _static(self, 'index.html')
            if path in ('/app.js', '/style.css', '/i18n.js'):
                return _static(self, path[1:])
            if path in ('/favicon.ico', '/logo.ico'):
                p = paths.asset('logo.ico')
                if os.path.isfile(p):
                    return _bytes(self, open(p, 'rb').read(), 'image/x-icon', cache=True)
                self.send_response(204); self.end_headers(); return
            if path == '/logo.png':
                p = paths.asset('logo.png')
                if os.path.isfile(p):
                    return _bytes(self, open(p, 'rb').read(), 'image/png', cache=True)
                self.send_response(204); self.end_headers(); return
            m = re.fullmatch(r'/sound/(ciallo|click)\.wav', path)
            if m:
                p = paths.asset('sound', m.group(1) + '.wav')
                if os.path.isfile(p):
                    return _bytes(self, open(p, 'rb').read(), 'audio/wav', cache=True)
                self.send_response(204); self.end_headers(); return
            m = re.fullmatch(r'/icon/png/([A-Za-z0-9_\-.]+)\.png', path)
            if m:
                p = paths.icon_png(m.group(1))
                if os.path.isfile(p):
                    return _bytes(self, open(p, 'rb').read(), 'image/png', cache=True)
                self.send_response(404); self.end_headers(); return
            if path == '/api/status':
                issues, info = paths.check_environment()
                return _json(self, dict(ok=not issues, issues=issues, info=info,
                                        version=VERSION,
                                        lang=paths.get_cfg().get('lang', 'zh'),
                                        sound=paths.get_cfg().get('sound', False),
                                        conflicts=_conflicts(),
                                        installed=installer.installed_own(),
                                        game_running=installer.game_running()))
            if path == '/api/catalog':
                return _json(self, dict(ok=True, **_catalog()))
            if path == '/api/texts':
                return _json(self, _texts())
            if path == '/api/icons':
                return _json(self, _icons())
            if path == '/api/skills':
                return _json(self, _skills())
            if path == '/api/grading':
                return _json(self, _grading())
            if path == '/api/theme':
                cfg = paths.get_cfg()
                return _json(self, dict(ok=True, theme=cfg.get('theme', 'light'),
                                        theme_image=cfg.get('theme_image', '')))
            if path == '/api/presets':
                return _json(self, dict(ok=True, presets=installer.list_presets()))
            self.send_error(404)
        except Exception:
            return _json(self, dict(ok=False, error=traceback.format_exc()), 500)

    def do_POST(self):
        global _GRADING_CACHE
        path = self.path.split('?')[0]
        try:
            length = int(self.headers.get('Content-Length', 0) or 0)
            payload = json.loads(self.rfile.read(length) or b'{}')
            if path == '/api/summary':
                return _json(self, summary.build(payload, _catalog()))
            if path == '/api/generate':
                return _json(self, generator.generate(payload))
            if path == '/api/install':
                _CONFLICT_CACHE['t'] = 0.0
                return _json(self, installer.install(payload.get('pak', '')))
            if path == '/api/uninstall':
                _CONFLICT_CACHE['t'] = 0.0
                return _json(self, installer.uninstall())
            if path == '/api/grading/custom/save':
                _GRADING_CACHE = None
                return _json(self, dict(ok=True,
                                        preset=grading.save_custom(payload.get('name'),
                                                                   payload.get('params') or {})))
            if path == '/api/grading/custom/delete':
                _GRADING_CACHE = None
                return _json(self, dict(ok=True,
                                        presets=grading.delete_custom(payload.get('key', ''))))
            if path == '/api/presets/save':
                return _json(self, installer.save_preset(payload))
            if path == '/api/presets/load':
                return _json(self, dict(ok=True, preset=installer.load_preset(payload.get('name', ''))))
            if path == '/api/settings':
                if 'lang' in payload:
                    if payload['lang'] not in ('zh', 'en'):
                        return _json(self, dict(ok=False, error='语言只能是 zh 或 en'), 200)
                    paths.set_cfg(lang=payload['lang'])
                if 'theme' in payload:
                    if payload['theme'] not in ('light', 'dark', 'image'):
                        return _json(self, dict(ok=False, error='主题只能是 light、dark 或 image'), 200)
                    paths.set_cfg(theme=payload['theme'])
                if 'theme_image' in payload:
                    img = payload['theme_image']
                    if img and (not isinstance(img, str) or not img.startswith('data:image/')
                                or len(img) > 4_000_000):
                        return _json(self, dict(ok=False, error='背景图片格式或大小不符合要求（上限约 3MB）'), 200)
                    paths.set_cfg(theme_image=img or '')
                if 'sound' in payload:
                    if not isinstance(payload['sound'], bool):
                        return _json(self, dict(ok=False, error='音效开关只能是 true 或 false'), 200)
                    paths.set_cfg(sound=payload['sound'])
                root = payload.get('game_root', '')
                if root:
                    root = paths.set_game_root(root)
                    global _CATALOG_CACHE, _TEXT_CACHE, _ICON_CACHE, _SKILL_CACHE
                    _CATALOG_CACHE = _TEXT_CACHE = _ICON_CACHE = _SKILL_CACHE = _GRADING_CACHE = None
                    _CONFLICT_CACHE['t'] = 0.0
                return _json(self, dict(ok=True, game_root=root or paths.get_cfg().get('game_root', ''),
                                        lang=paths.get_cfg().get('lang', 'zh'),
                                        sound=paths.get_cfg().get('sound', False),
                                        issues=paths.check_environment()[0]))
            if path == '/api/open-url':
                url = str(payload.get('url', ''))
                if not url.startswith(('https://', 'http://')):
                    return _json(self, dict(ok=False, error='只允许 http/https 链接'), 200)
                import webbrowser
                webbrowser.open(url)
                return _json(self, dict(ok=True))
            if path == '/api/open-folder':
                target = payload.get('path') or paths.OUT_DIR
                if os.path.isdir(target):
                    subprocess.Popen(['explorer', os.path.abspath(target)])
                return _json(self, dict(ok=True))
            if path == '/api/shutdown':
                _json(self, dict(ok=True))
                import threading
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return _json(self, dict(ok=False, error='未知接口：' + path), 404)
        except Exception as e:
            return _json(self, dict(ok=False, error=str(e), trace=traceback.format_exc()), 200)


def start(port=8765):
    paths.ensure_dirs()
    last = None
    for p in range(port, port + 20):
        try:
            srv = ThreadingHTTPServer(('127.0.0.1', p), Handler)
            return srv, p
        except OSError as e:
            last = e
    raise RuntimeError(f'端口 {port}~{port + 19} 都被占用：{last}')
