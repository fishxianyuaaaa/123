@echo off
chcp 65001 >nul
setlocal
set "HERE=%~dp0"
set "EXE=%HERE%Eotu Mod Tool.exe"
set "ICO=%HERE%logo.ico"
if not exist "%EXE%" (
  echo [ERROR] Cannot find "Eotu Mod Tool.exe" next to this script.
  pause
  exit /b 1
)
if not exist "%ICO%" set "ICO=%EXE%"
powershell -NoProfile -Command ^
  "$w = New-Object -ComObject WScript.Shell; " ^
  "$lnk = $w.CreateShortcut([IO.Path]::Combine($w.SpecialFolders('Desktop'), 'Eotu Mod Tool.lnk')); " ^
  "$lnk.TargetPath = '%EXE%'; " ^
  "$lnk.WorkingDirectory = '%HERE%'; " ^
  "$lnk.IconLocation = '%ICO%,0'; " ^
  "$lnk.Description = '地下蚁国 Mod 工坊'; " ^
  "$lnk.Save(); " ^
  "Write-Host 'Desktop shortcut created.'"
echo.
echo Done. You can now launch Eotu Mod Tool from your desktop.
timeout /t 3 >nul
