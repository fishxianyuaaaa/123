'use strict';
/* Eotu Mod Tool v2.2 前端 —— 双语界面 / 中文标签 / 批量范围 / 生成前确认 /
   技能编辑（改数值 + 配技能）/ 预设调色滤镜 */

const $ = id => document.getElementById(id);
const S = {
  catalog: null, texts: null, icons: null, skills: null, gradingCat: null, status: null, presets: [],
  changes: {}, textChanges: {}, iconChanges: {},
  skillValues: {}, skillAssigns: [], grading: null, customParams: {},
  gradeLimits: {},
  filter: { q: '', family: 'all', side: 'all' },
  textFilter: { q: '', group: 'all', page: 0, onlyChanged: false },
  iconFilter: { q: '', family: 'all', onlyChanged: false },
  skillFilter: { q: '', onlySafe: true, onlyChanged: false },
  selected: null, summary: null, lastResult: null,
  picker: { id: null, sel: null, image: null, tab: 'official' },
  tab: 'editor',
  sound: false,
};

// ---------------- 提示音效 ----------------
// 进入软件播放 ciallo 问候音；按钮点击播放清脆音。可在设置里关闭。
function soundEnabled() { return S.sound === true; }
// 浏览器自动播放策略：首次用户手势前 Audio.play() 会被拒绝。
// 用一次性监听在第一次点击时解锁音频上下文，之后进场音/点击音才能正常播放。
const _audioCache = {};
function _getAudio(name) {
  if (!_audioCache[name]) {
    const a = new Audio('/sound/' + name + '.wav');
    a.preload = 'auto';
    _audioCache[name] = a;
  }
  return _audioCache[name];
}
function _unlockAudio() {
  // 播放一段极短的静音数据来解锁浏览器的自动播放限制
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (Ctx) {
      if (!window._eotuAudioCtx) window._eotuAudioCtx = new Ctx();
      const ctx = window._eotuAudioCtx;
      if (ctx.state === 'suspended') ctx.resume();
    }
  } catch (e) { /* 忽略 */ }
  document.removeEventListener('pointerdown', _unlockAudio, true);
  document.removeEventListener('keydown', _unlockAudio, true);
  // 若进场音之前被自动播放策略拦下，这里借首次手势补播一次
  if (window._needCialloOnUnlock && soundEnabled()) {
    window._needCialloOnUnlock = false;
    setTimeout(playCiallo, 20);
  }
}
document.addEventListener('pointerdown', _unlockAudio, true);
document.addEventListener('keydown', _unlockAudio, true);
function playSound(name) {
  if (!soundEnabled()) return Promise.resolve(false);
  try {
    const a = _getAudio(name);
    a.volume = name === 'ciallo' ? 0.7 : 0.5;
    a.currentTime = 0;
    const p = a.play();
    if (p && p.then) return p.then(() => true).catch(() => false);
  } catch (e) { /* 音效失败绝不影响功能 */ }
  return Promise.resolve(false);
}
function playCiallo() {
  playSound('ciallo').then(ok => { if (ok) window._needCialloOnUnlock = false; });
}
function playClick() { playSound('click'); }
function applySound(on) {
  S.sound = !!on;
  document.querySelectorAll('[data-sound-opt]').forEach(b => {
    b.classList.toggle('active', (b.dataset.soundOpt === 'on') === !!on);
  });
}
async function saveSound(on) {
  applySound(on);
  if ($('soundResult')) $('soundResult').textContent = '';
  try {
    const d = await api('/api/settings', { sound: !!on });
    if (!d.ok) { toast(d.error || t('toast.soundSaved'), true); return; }
    toast(t('toast.soundSaved'));
  } catch (e) { toast(e.message, true); }
}
const PAGE_SIZE = 24;

// 批量倍率作用范围：常用 / 阵营 / 物种类别 / 其它
const BATCH_GROUPS = [
  { group: 'common', items: ['filtered', 'all', 'player', 'hostile'] },
  { group: 'side', items: ['hostile_ants', 'hostile_insects', 'hostile_beetles', 'hostile_arachnids'] },
  { group: 'family', items: ['ants', 'beetles', 'insects', 'arachnids', 'others', 'special'] },
  { group: 'other', items: ['prefix'] },
];

// ---------------- 工具 ----------------
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
}
function fmt(v) {
  if (v === true) return t('bool.true');
  if (v === false) return t('bool.false');
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : String(+v.toFixed(4));
  return String(v == null ? '—' : v);
}
function clip(s, n) { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n) + '…' : s; }
function eq(a, b) {
  if (typeof a === 'number' && typeof b === 'number') return Math.abs(a - b) < 1e-9;
  return a === b;
}
let toastTimer = null;
function toast(msg, bad) {
  const el = $('toast'); el.textContent = msg; el.className = 'toast' + (bad ? ' bad' : ''); el.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, 3200);
}
async function api(path, body) {
  const opt = body === undefined ? {} : {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  };
  const r = await fetch(path, opt);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}
function byRow(row) { return S.catalog.byRow[row]; }
function textById(id) { return S.texts ? S.texts.byId[id] : null; }
function iconById(id) { return S.icons ? S.icons.byId[id] : null; }
function countOf(o) { return Object.keys(o).length; }
function countFields() { return Object.values(S.changes).reduce((n, v) => n + Object.keys(v).length, 0); }
function skillValueCount() { return Object.values(S.skillValues).reduce((n, v) => n + Object.keys(v).length, 0); }
function totalChanges() {
  return countFields() + countOf(S.textChanges) + countOf(S.iconChanges)
    + skillValueCount() + S.skillAssigns.length + (S.grading ? 1 : 0);
}
function hasChanges() { return totalChanges() > 0; }

function buildPayload() {
  return {
    mod_name: $('modName').value.trim() || t('build.modName.def'),
    scope: $('scope').value,
    note: $('note').value.trim(),
    changes: S.changes, texts: S.textChanges, icons: S.iconChanges,
    skillValues: S.skillValues, skillAssigns: S.skillAssigns, grading: S.grading,
  };
}

// ---------------- 初始化 ----------------
async function init() {
  applyStaticI18n();
  bindEvents();
  try {
    const [st, cat, tx, ic, pr, sk, gd, th] = await Promise.all([
      api('/api/status'), api('/api/catalog'), api('/api/texts'), api('/api/icons'),
      api('/api/presets'), api('/api/skills'), api('/api/grading'), api('/api/theme'),
    ]);
    // 本机没存过语言偏好时，用工具配置里的值（分享给别人时沿用对方上次设置）
    let saved = null;
    try { saved = localStorage.getItem('eoth_lang'); } catch (e) { /* ignore */ }
    if (!saved && st.lang && st.lang !== LANG) { LANG = st.lang; _applyI18n(); }
    S.status = st;
    S.catalog = cat;
    S.catalog.byRow = {};
    S.catalog.fieldMap = {};
    cat.creatures.forEach(c => { S.catalog.byRow[c.row] = c; });
    cat.fields.forEach(f => { S.catalog.fieldMap[f.name] = f; });
    S.texts = tx;
    S.texts.byId = {};
    tx.items.forEach(i => { S.texts.byId[i.id] = i; });
    S.icons = ic;
    S.icons.byId = {};
    ic.items.forEach(i => { S.icons.byId[i.id] = i; });
    S.skills = sk;
    S.skills.byName = {};
    sk.skills.forEach(s => { S.skills.byName[s.name] = s; });
    S.skills.byCreature = {};
    sk.creatures.forEach(c => { S.skills.byCreature[c.name] = c; });
    S.gradingCat = gd;
    S.grading = null;
    S.presets = pr.presets || [];
    $('verText').textContent = 'v' + (st.version || '2.2');
    applyTheme(th.theme || 'light', th.theme_image || '');
    applySound(st.sound === true);
    // 首次进入播放一声 ciallo。App 模式已加 autoplay-policy 允许自动播放；
    // 若仍被浏览器拦截，则由首次用户手势的 _unlockAudio 兜底补播。
    if (soundEnabled()) {
      window._needCialloOnUnlock = true;
      setTimeout(playCiallo, 350);
    } else {
      window._needCialloOnUnlock = false;
    }
    S.customParams = Object.assign({}, (S.gradingCat.presets[0] || {}).params || {});
    S.gradeLimits = S.gradingCat.params || {};
    initGradeSliders();
    const defs = ['我的蚂蚁模组', 'My Ant Mod'];
    if (defs.includes($('modName').value)) $('modName').value = t('build.modName.def');
    rerenderAll();
    $('gameRoot').value = (st.info && st.info.game_root) || '';
    applyHash();
  } catch (e) {
    $('statusChip').className = 'status-chip bad';
    $('statusChip').querySelector('span').textContent = t('init.fail', { m: e.message });
    toast(t('init.fail', { m: e.message }), true);
  }
}

/** 语言切换后重画所有动态内容 */
function rerenderAll() {
  if (!S.catalog || !S.texts || !S.icons) return;
  renderStatus();
  renderFamilyFilters();
  renderIconFamilySel();
  renderTextGroupSel();
  renderBatchScope();
  renderCreatureList();
  if (S.selected) renderEditor();
  renderTexts();
  renderIcons();
  renderSkills();
  renderGrading();
  renderPresets();
  renderPakStatus();
  renderNavBadges();
  renderFooter();
  renderDiff();
  updatePakPreview();
  $('aboutEnv').textContent = t('settings.env', {
    r: (S.status.info && S.status.info.game_root) || '—',
    s: (S.status.info && S.status.info.source) || '—',
    n: S.icons.stats ? S.icons.stats.total : 0,
  });
  $('btnTextOnlyChanged').textContent = S.textFilter.onlyChanged ? t('texts.showAll') : t('texts.onlyChanged');
  $('btnIconOnlyChanged').textContent = S.iconFilter.onlyChanged ? t('icons.showAll') : t('icons.onlyChanged');
  const defs = ['我的蚂蚁模组', 'My Ant Mod'];
  if (defs.includes($('modName').value)) $('modName').value = t('build.modName.def');
  if (!$('confirmModal').hidden && S.summary) renderConfirm(S.summary);
  if (!$('dupModal').hidden && S.summary) renderDup(S.summary);
  if (!$('batchModal').hidden) {
    const fs = S.catalog.fields.filter(f => f.kind === 'float' || f.kind === 'int');
    $('batchFields').innerHTML = fs.map(f =>
      `<label><input type="checkbox" value="${f.name}" ${batchChecked(f.name)}>${esc(L(f, 'label'))}</label>`).join('');
    batchPreview();
  }
  if (!$('iconModal').hidden && S.picker.id) {
    const item = iconById(S.picker.id);
    $('iconModalTitle').textContent = t('iconModal.title', {
      n: item ? L(item, 'cn') : S.picker.id,
      s: item ? item.w + '×' + item.h : '',
    });
    renderPicker();
  }
  if (S.lastResult) showResult(S.lastResult);
}

function applyHash() {
  const h = location.hash || '';
  const lm = h.match(/lang=(zh|en)/);
  if (lm) setLang(lm[1], false);
  const m = h.match(/tab=(\w+)/);
  if (m) switchTab(m[1]);
  const r = h.match(/row=([\w]+)/);
  if (r && S.catalog.byRow[r[1]]) { switchTab('editor'); selectCreature(r[1]); }
  // 可视化自检用的临时开关（不影响正常功能）
  if (h.indexOf('debug=batch') >= 0) setTimeout(() => { if (S.catalog) openBatch(); }, 500);
  if (h.indexOf('debug=grade') >= 0) setTimeout(() => {
    if (S.gradingCat) { S.grading = S.gradingCat.presets[0].key; afterChange(); }
  }, 500);
  if (h.indexOf('debug=dup') >= 0) setTimeout(() => {
    S.summary = {
      mod_name: $('modName').value.trim() || t('build.modName.def'),
      pak_name: 'zzz_EotU_EothTool_测试_P.pak', reused: true,
      reused_info: { pak: 'zzz_EotU_EothTool_测试_P.pak', exists: true,
                     size: 42311, mtime: '2026-11-13 19:20:00', last_time: '2026-11-13 19:20:00' },
    };
    renderDup(S.summary); $('dupModal').hidden = false;
  }, 500);
}

function renderStatus() {
  const st = S.status, chip = $('statusChip');
  if (!st) return;
  const issues = st.issues || [], conflicts = st.conflicts || [];
  if (issues.length) {
    chip.className = 'status-chip bad';
    chip.querySelector('span').textContent = t('status.bad', { m: clip(issues[0], 42) });
  } else if (conflicts.length) {
    chip.className = 'status-chip warn';
    chip.querySelector('span').textContent = t('status.conflict', { n: conflicts.length });
  } else if (st.game_running) {
    chip.className = 'status-chip warn';
    chip.querySelector('span').textContent = t('status.running');
  } else {
    chip.className = 'status-chip';
    chip.querySelector('span').textContent = t('status.ok', { n: S.catalog ? S.catalog.stats.rows : 283 });
  }
  const wb = $('warnBox');
  const lines = [];
  conflicts.forEach(c => lines.push(t('warn.conflict', { p: esc(c) })));
  if (st.game_running) lines.push(t('warn.running'));
  issues.forEach(i => lines.push(t('warn.issue', { m: esc(i) })));
  wb.innerHTML = lines.join('<br>'); wb.hidden = !lines.length;
}

// ---------------- 导航 ----------------
function switchTab(tab) {
  S.tab = tab;
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === 'panel-' + tab));
  history.replaceState(null, '', '#tab=' + tab);
  if (tab === 'diff') renderDiff();
  if (tab === 'build') renderPakStatus();
  if (tab === 'texts') renderTexts();
  if (tab === 'icons') renderIcons();
  if (tab === 'skills') renderSkills();
  if (tab === 'grading') renderGrading();
}

// ---------------- 生物列表 ----------------
function renderFamilyFilters() {
  const el = $('familyFilters'), fams = S.catalog.families, stats = S.catalog.stats.by_family;
  const all = `<button class="fam-chip ${S.filter.family === 'all' ? 'active' : ''}" data-fam="all">${LANG === 'en' ? 'All' : '全部'} <b>${S.catalog.stats.rows}</b></button>`;
  el.innerHTML = all + fams.map(f =>
    `<button class="fam-chip ${S.filter.family === f.id ? 'active' : ''}" data-fam="${f.id}" title="${esc(L(f, 'hint'))}">${f.icon} ${esc(L(f, 'label'))} <b>${stats[f.id] || 0}</b></button>`
  ).join('');
}
function filteredCreatures() {
  const q = S.filter.q.trim().toLowerCase();
  return S.catalog.creatures.filter(c => {
    if (S.filter.family !== 'all' && c.family !== S.filter.family) return false;
    if (S.filter.side !== 'all' && c.category !== S.filter.side) return false;
    if (q && !(c.search || (L(c, 'cn') + ' ' + c.base + ' ' + c.row).toLowerCase()).includes(q)) return false;
    return true;
  });
}
function renderCreatureList() {
  if (!S.catalog) return;
  const list = filteredCreatures();
  $('listCount').textContent = t('list.count', { n: list.length });
  $('listHint').textContent = S.filter.q ? t('list.search') : t('list.hint');
  const el = $('creatureList');
  if (!list.length) { el.innerHTML = `<div class="empty-inline" style="margin-top:14px">${esc(t('list.empty'))}</div>`; return; }
  el.innerHTML = list.map(c => {
    const n = countOf(S.changes[c.row] || {});
    return `<div class="c-item ${S.selected === c.row ? 'active' : ''}" data-row="${esc(c.row)}">
      <div class="c-main"><div class="c-name">${esc(L(c, 'cn'))}</div><div class="c-row">${esc(c.row)}</div></div>
      ${n ? `<span class="c-badge">${n}</span>` : ''}
      <span class="c-fam">${esc(L(c, 'family_label'))}</span></div>`;
  }).join('');
}
function selectCreature(row) {
  S.selected = row;
  renderCreatureList();
  renderEditor();
}
function renderEditor() {
  const row = S.selected;
  if (!row || !S.catalog) return;
  const c = byRow(row), ch = S.changes[row] || {};
  $('editorEmpty').hidden = true; $('editorContent').hidden = false;
  $('edTitle').textContent = L(c, 'cn');
  $('edRow').textContent = c.row;
  $('edCat').textContent = L(c, 'category_label');
  $('edFam').textContent = L(c, 'family_label');
  $('edFp').hidden = !(c.fp_diff && c.fp_diff.length);
  const groups = S.catalog.groups;
  $('fieldGroups').innerHTML = groups.map((g, gi) => {
    const fs = S.catalog.fields.filter(f => f.group === g && c.values[f.name] !== undefined);
    const gname = LANG === 'en' ? (S.catalog.groups_en[gi] || g) : g;
    return `<div class="fgroup"><h4>${esc(gname)} <small>${esc(t('ed.group', { n: fs.length }))}</small></h4>` +
      fs.map(f => renderField(c, f, ch)).join('') + '</div>';
  }).join('');
}
function renderField(c, f, ch) {
  const orig = c.values[f.name];
  const cur = ch[f.name] !== undefined ? ch[f.name] : orig;
  const changed = ch[f.name] !== undefined;
  const origTitle = esc(t('f.origTitle', { l: L(f, 'label'), v: fmt(orig) }));
  let control, oldText;
  if (f.kind === 'enum') {
    // 「性情」是只读枚举：控件显示本地化可读名，副标签不再暴露内部英文枚举值
    const disp = (LANG === 'en' ? c.temperament_en : c.temperament_cn) || fmt(orig);
    control = `<div class="enum-val" title="${esc(disp)}">${esc(disp)}</div><span></span>`;
    oldText = esc(t('f.readonly'));
  } else if (f.kind === 'bool') {
    control = `<button class="bool-btn ${cur ? 'on' : ''}" data-bool="${esc(f.name)}">${esc(fmt(cur))}</button><span></span>`;
    oldText = esc(t('f.old', { v: fmt(orig) }));
  } else {
    control = `<input type="text" inputmode="decimal" value="${esc(fmt(cur))}" data-field="${esc(f.name)}" title="${esc(L(f, 'hint'))}">` +
      `<button class="f-reset" data-reset="${esc(f.name)}" title="${esc(t('f.reset'))}">↺</button>`;
    oldText = esc(t('f.old', { v: fmt(orig) }));
  }
  return `<div class="f-row ${changed ? 'changed' : ''}" data-wrap="${esc(f.name)}">
    <div class="f-label" title="${origTitle}">${esc(L(f, 'label'))}<span class="f-old">${oldText}</span></div>
    ${control}</div>`;
}
function setChange(row, field, value) {
  const orig = byRow(row).values[field];
  if (!S.changes[row]) S.changes[row] = {};
  if (eq(orig, value)) delete S.changes[row][field];
  else S.changes[row][field] = value;
  if (!countOf(S.changes[row])) delete S.changes[row];
  afterChange();
}
function afterChange() {
  renderNavBadges(); renderFooter(); renderDiff(); updatePakPreview();
  if (S.tab === 'editor') { renderCreatureList(); if (S.selected) renderEditor(); }
  if (S.tab === 'texts') renderTexts();
  if (S.tab === 'icons') renderIcons();
  if (S.tab === 'skills') renderSkills();
  if (S.tab === 'grading') renderGrading();
}

// ---------------- 文案 ----------------
function renderTextGroupSel() {
  const sel = $('textGroupSel'), cur = sel.value || 'all';
  const all = `<option value="all">${esc(t('texts.group.all'))}</option>`;
  sel.innerHTML = all + S.texts.groups.map(g =>
    `<option value="${g.id}">${esc(L(g, 'label'))}（${S.texts.stats.by_group[g.id] || 0}）</option>`).join('');
  sel.value = cur;
  S.textFilter.group = sel.value;
}
function filteredTexts() {
  const q = S.textFilter.q.trim().toLowerCase();
  return S.texts.items.filter(i => {
    if (S.textFilter.group !== 'all' && i.group !== S.textFilter.group) return false;
    if (S.textFilter.onlyChanged && S.textChanges[i.id] === undefined) return false;
    if (q && !(L(i, 'label') + ' ' + i.key + ' ' + i.value + ' ' + i.id).toLowerCase().includes(q)) return false;
    return true;
  });
}
function renderTexts() {
  if (!S.texts) return;
  const list = filteredTexts(), pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  S.textFilter.page = Math.min(S.textFilter.page, pages - 1);
  const page = list.slice(S.textFilter.page * PAGE_SIZE, (S.textFilter.page + 1) * PAGE_SIZE);
  $('textChanged').textContent = t('texts.changed', { n: countOf(S.textChanges) });
  const gmap = {}; S.texts.groups.forEach(g => { gmap[g.id] = L(g, 'label'); });
  $('textList').innerHTML = page.length ? page.map(i => {
    const val = S.textChanges[i.id] !== undefined ? S.textChanges[i.id] : i.value;
    const changed = S.textChanges[i.id] !== undefined;
    const shared = i.shared && i.shared.length > 1;
    return `<div class="tcard ${changed ? 'changed' : ''}" data-id="${esc(i.id)}">
      <div class="tcard-head"><div style="min-width:0;flex:1"><div class="tcard-label">${esc(L(i, 'label'))}</div>
        <div class="tcard-key">${esc(i.key)}</div></div><span class="tgroup">${esc(gmap[i.group] || i.group)}</span></div>
      <div class="tcard-orig" title="${esc(i.value)}">${esc(t('texts.orig', { v: clip(i.value, 150) }))}</div>
      <textarea data-tid="${esc(i.id)}" rows="2" placeholder="${esc(t('texts.textarea.ph'))}">${esc(val)}</textarea>
      <div class="tcard-foot"><span>${esc(t('texts.chars', { n: val.length, o: i.value.length }))}${shared ? ' · <span class="share">' + esc(t('texts.shared')) + '</span>' : ''}${i.value.includes('{') ? ' · <span class="share">' + esc(t('texts.placeholder')) + '</span>' : ''}</span>
        ${changed ? `<button data-treset="${esc(i.id)}">${esc(t('texts.reset'))}</button>` : ''}</div></div>`;
  }).join('') : `<div class="empty-inline" style="grid-column:1/-1">${esc(t('texts.empty'))}</div>`;
  $('textPager').innerHTML = `<button id="tPrev" ${S.textFilter.page <= 0 ? 'disabled' : ''}>${esc(t('texts.prev'))}</button>
    <span>${esc(t('texts.pager', { p: S.textFilter.page + 1, n: pages, t: list.length }))}</span>
    <button id="tNext" ${S.textFilter.page >= pages - 1 ? 'disabled' : ''}>${esc(t('texts.next'))}</button>`;
  const p = $('tPrev'), n = $('tNext');
  if (p) p.onclick = () => { S.textFilter.page--; renderTexts(); };
  if (n) n.onclick = () => { S.textFilter.page++; renderTexts(); };
}
function setText(id, value) {
  const item = textById(id);
  if (!item) return;
  if (value === item.value) delete S.textChanges[id];
  else S.textChanges[id] = value;
  afterChange();
}

// ---------------- 图标 ----------------
function renderIconFamilySel() {
  const sel = $('iconFamilySel'), cur = sel.value || 'all';
  sel.innerHTML = `<option value="all">${esc(t('icons.family.all'))}</option>` + S.icons.families.map(f =>
    `<option value="${f.id}">${f.icon} ${esc(L(f, 'label'))}（${(S.icons.stats.by_family || {})[f.id] || 0}）</option>`).join('');
  sel.value = cur;
  S.iconFilter.family = sel.value;
}
function filteredIcons() {
  const q = S.iconFilter.q.trim().toLowerCase();
  return S.icons.items.filter(i => {
    if (S.iconFilter.family !== 'all' && i.family !== S.iconFilter.family) return false;
    if (S.iconFilter.onlyChanged && S.iconChanges[i.id] === undefined) return false;
    if (q && !(L(i, 'cn') + ' ' + i.name + ' ' + i.id).toLowerCase().includes(q)) return false;
    return true;
  });
}
function iconThumb(id) {
  const ch = S.iconChanges[id];
  if (ch && ch.from && iconById(ch.from)) return '/icon/png/' + encodeURIComponent(ch.from) + '.png';
  if (ch && ch.image) return ch.image;
  return '/icon/png/' + encodeURIComponent(id) + '.png';
}
function renderIcons() {
  if (!S.icons) return;
  const list = filteredIcons();
  $('iconChanged').textContent = t('icons.changed', { n: countOf(S.iconChanges) });
  $('iconGrid').innerHTML = list.length ? list.map(i => {
    const ch = S.iconChanges[i.id];
    const src = ch ? (ch.from ? t('icons.from', { n: L(iconById(ch.from) || {}, 'cn') }) : t('icons.custom')) : i.w + '×' + i.h;
    return `<div class="icard ${ch ? 'changed' : ''}" data-icon="${esc(i.id)}">
      ${ch ? `<span class="ibadge">${esc(t('icons.badge'))}</span>` : ''}
      <img class="thumb" src="${iconThumb(i.id)}" alt="" loading="lazy">
      <div class="icn" title="${esc(L(i, 'cn'))}">${esc(L(i, 'cn'))}</div>
      <div class="isub">${esc(clip(src, 22))}</div></div>`;
  }).join('') : `<div class="empty-inline" style="grid-column:1/-1">${esc(t('icons.empty'))}</div>`;
}
function openIconModal(id) {
  S.picker = { id, sel: null, image: null, tab: 'official' };
  const item = iconById(id);
  $('iconModalTitle').textContent = t('iconModal.title', {
    n: item ? L(item, 'cn') : id, s: item ? item.w + '×' + item.h : '',
  });
  $('pickerSearch').value = '';
  $('uploadPreview').hidden = true;
  $('btnApplyIcon').disabled = true;
  switchIconTab('official');
  renderPicker();
  $('iconModal').hidden = false;
}
function switchIconTab(tab) {
  S.picker.tab = tab;
  document.querySelectorAll('.it').forEach(b => b.classList.toggle('active', b.dataset.itab === tab));
  $('itabOfficial').hidden = tab !== 'official';
  $('itabUpload').hidden = tab !== 'upload';
}
function renderPicker() {
  const q = ($('pickerSearch').value || '').trim().toLowerCase();
  const list = S.icons.items.filter(i => i.id !== S.picker.id &&
    (!q || (L(i, 'cn') + ' ' + i.name).toLowerCase().includes(q))).slice(0, 120);
  $('pickerGrid').innerHTML = list.map(i =>
    `<div class="pitem ${S.picker.sel === i.id ? 'sel' : ''}" data-pick="${esc(i.id)}" title="${esc(i.name)}">
      <img src="/icon/png/${encodeURIComponent(i.id)}.png" alt="" loading="lazy"><div>${esc(L(i, 'cn'))}</div></div>`).join('') ||
    `<div class="empty-inline" style="grid-column:1/-1">${esc(t('picker.empty'))}</div>`;
}
function applyIcon() {
  const p = S.picker;
  if (!p.id) return;
  if (p.tab === 'upload' && p.image) S.iconChanges[p.id] = { image: p.image };
  else if (p.tab === 'official' && p.sel) S.iconChanges[p.id] = { from: p.sel };
  else { toast(t('toast.selectIcon'), true); return; }
  $('iconModal').hidden = true;
  afterChange();
  toast(t('toast.iconAdded'));
}

// ---------------- 技能编辑 ----------------
function skillById(name) { return S.skills && S.skills.byName[name]; }
/** 技能显示：生物名称 - 技能名称（中文用后端翻译，英文用英文行名） */
function skillLabel(s) {
  if (!s) return '—';
  if (LANG === 'en') {
    const owner = s.owner_en || s.owner_cn || 'General';
    const skill = (s.name || '').replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/_/g, ' ');
    return owner + ' - ' + skill;
  }
  return s.cn || ((s.owner_cn || '通用') + ' - ' + (s.skill_cn || s.name));
}
function creatureLabel(name) {
  const c = S.skills && S.skills.byCreature && S.skills.byCreature[name];
  if (!c) return name;
  return LANG === 'en' ? (c.cn_en || c.name) : c.cn;
}
function filteredSkills() {
  if (!S.skills) return [];
  const q = S.skillFilter.q.trim().toLowerCase();
  return S.skills.skills.filter(s => {
    if (S.skillFilter.onlySafe && !s.safe && !S.skillValues[s.name]) return false;
    if (S.skillFilter.onlyChanged && !S.skillValues[s.name]) return false;
    if (q && s.search.indexOf(q) < 0) return false;
    return true;
  });
}
function setSkillValue(name, field, value) {
  const s = skillById(name);
  const orig = s ? s.values[field] : null;
  if (!S.skillValues[name]) S.skillValues[name] = {};
  const num = (value === '' || value == null) ? NaN : Number(value);
  if (orig != null && !isNaN(num) && eq(orig, num)) delete S.skillValues[name][field];
  else if (!isNaN(num)) S.skillValues[name][field] = num;
  else delete S.skillValues[name][field];
  if (!countOf(S.skillValues[name])) delete S.skillValues[name];
  afterChange();
}
function renderSkills() {
  if (!S.skills) return;
  const list = $('skillList');
  $('skillChanged').textContent = t('skills.changed', { n: skillValueCount() + S.skillAssigns.length });
  $('btnSkillOnlyChanged').textContent = S.skillFilter.onlyChanged ? t('skills.showAll') : t('skills.onlyChanged');
  $('btnSkillOnlySafe').textContent = S.skillFilter.onlySafe ? t('skills.showSafe') : t('skills.showAllSkills');
  $('btnSkillOnlySafe').classList.toggle('active', S.skillFilter.onlySafe);
  const items = filteredSkills().slice(0, 200);
  if (!items.length) { list.innerHTML = `<div class="empty-inline">${esc(t('skills.empty'))}</div>`; }
  else {
    const fields = S.skills.fields.filter(f => f.name !== 'PickupStrength');
    list.innerHTML = items.map(s => {
      const changed = S.skillValues[s.name] || {};
      const badge = s.safe ? `<span class="tag ok">${esc(t('skills.safe'))}</span>`
                           : `<span class="tag warn">${esc(t('skills.unsafe'))}</span>`;
      const rows = fields.map(f => {
        const v = (f.name in changed) ? changed[f.name] : s.values[f.name];
        const isCh = f.name in changed;
        return `<label class="sf-row${isCh ? ' changed' : ''}">
          <span>${esc(L(f, 'label'))}</span>
          <input type="number" step="any" value="${esc(v == null ? '' : v)}"
                 data-skill="${esc(s.name)}" data-field="${f.name}" title="${esc(L(f, 'hint'))}">
        </label>`;
      }).join('');
      return `<div class="scard${countOf(changed) ? ' changed' : ''}" data-name="${esc(s.name)}">
        <div class="sc-head"><b>${esc(skillLabel(s))}</b> <small>${esc(s.name)}</small> ${badge}
          <span class="sc-users">${esc(t('skills.users'))}: ${esc(s.users.slice(0, 4).map(creatureLabel).join(', ') || '—')}</span></div>
        <div class="sf-grid">${rows}</div>
        <div class="sc-foot">
          <button class="btn small secondary" data-addskill="${esc(s.name)}">${esc(t('skills.addTo'))}</button>
          <button class="btn small ghost" data-resetskill="${esc(s.name)}" ${countOf(changed) ? '' : 'hidden'}>${esc(t('skills.reset'))}</button>
        </div></div>`;
    }).join('');
  }
  renderSkillAssigns();
}
function renderSkillAssigns() {
  const box = $('skillAssignList');
  if (!S.skillAssigns.length) { box.innerHTML = `<div class="empty-inline">${esc(t('skills.noAssigns'))}</div>`; return; }
  box.innerHTML = S.skillAssigns.map((a, i) => {
    const s = skillById(a.ability);
    return `<div class="assign-chip"><b>${esc(creatureLabel(a.creature))}</b> Lv${a.level} ← ${esc(skillLabel(s))}
      <button class="del" data-delassign="${i}">×</button></div>`;
  }).join('');
}
// 弹出「给生物配技能」小窗
function openAssignModal(skillName) {
  const s = skillById(skillName);
  if (!s) return;
  S.picker.assignSkill = skillName;
  $('assignSkillName').textContent = skillLabel(s) + ' (' + s.name + ')';
  const creatures = (S.skills.creatures || []).map(c =>
    `<option value="${esc(c.name)}">${esc(L(c, 'cn'))} (${esc(c.name)})</option>`).join('');
  $('assignCreature').innerHTML = creatures;
  $('assignLevel').innerHTML = '<option value="1">Lv1</option><option value="2">Lv2</option><option value="3" selected>Lv3</option>';
  $('assignForceRow').hidden = s.safe;
  $('assignForce').checked = false;
  $('assignModal').hidden = false;
}
function confirmAssign() {
  const skill = S.picker.assignSkill;
  const creature = $('assignCreature').value;
  const level = Number($('assignLevel').value);
  const force = $('assignForce').checked;
  if (!skill || !creature) { toast(t('toast.selectIcon'), true); return; }
  const rn = 'EotuSkill_' + creature + '_' + skill + '_L' + level;
  S.skillAssigns.push({ row_name: rn, creature, ability: skill, level, force });
  $('assignModal').hidden = true;
  afterChange();
  toast(t('toast.skillAssigned'));
}

// ---------------- 滤镜预设 / 自定义调色 ----------------
function gradingKey() {
  if (!S.grading) return null;
  return typeof S.grading === 'string' ? S.grading : (S.grading.key || null);
}
function gradingPreset() {
  const key = gradingKey();
  if (!key || !S.gradingCat) return null;
  const p = S.gradingCat.presets.find(x => x.key === key);
  if (p) return p;
  return typeof S.grading === 'object' ? S.grading : null;
}
function gradingName() {
  const p = gradingPreset();
  return p ? (L(p, 'label') || p.label || p.key) : String(S.grading || '');
}
function swatchStyle(params) {
  if (!params) return '';
  const rgb = p => [p.tint_r || 1, p.tint_g || 1, p.tint_b || 1]
    .map(x => Math.max(0, Math.min(255, Math.round(235 * x)))).join(',');
  return `background:linear-gradient(135deg,rgb(${rgb(params)}),rgb(${rgb({ tint_r: (params.tint_r || 1) * .62, tint_g: (params.tint_g || 1) * .62, tint_b: (params.tint_b || 1) * .62 })}))`;
}
function renderGrading() {
  if (!S.gradingCat) return;
  const box = $('gradeGrid');
  const key = gradingKey();
  box.innerHTML = S.gradingCat.presets.map(p => {
    const on = key === p.key;
    return `<div class="gcard${on ? ' active' : ''}" data-grade="${esc(p.key)}">
      <div class="g-swatch ${esc(p.key)}" style="${p.custom ? swatchStyle(p.params) : ''}"></div>
      <b>${esc(L(p, 'label'))}</b>
      <p>${esc(L(p, 'desc'))}</p>
      ${on ? `<span class="g-check">✓ ${esc(t('grading.selected'))}</span>` : ''}
    </div>`;
  }).join('');
  $('gradeChanged').textContent = S.grading ? t('grading.changed', { n: S.gradingCat.count }) : t('grading.none');
  $('btnGradeClear').hidden = !S.grading;
  const banner = $('gradeSelected');
  banner.hidden = !S.grading;
  if (S.grading) banner.textContent = t('grading.current', { n: gradingName(), c: S.gradingCat.count });
  const cur = gradingPreset();
  $('btnGradeDeleteCustom').hidden = !(cur && cur.custom && String(cur.key || '').startsWith('custom_'));
}
function setGrading(key) {
  S.grading = (gradingKey() === key) ? null : key;
  afterChange();
}

/** 按与后端 _transform 相同的公式，把一条渐变样图实时调色 */
function drawGradePreview() {
  const cv = $('gradePreview');
  if (!cv || !S.customParams) return;
  const ctx = cv.getContext('2d');
  const p = S.customParams;
  const clamp = v => v < 0 ? 0 : (v > 255 ? 255 : Math.round(v));
  const img = ctx.createImageData(cv.width, cv.height);
  for (let y = 0; y < cv.height; y++) {
    for (let x = 0; x < cv.width; x++) {
      const base = [Math.round(255 * x / cv.width), Math.round(255 * y / cv.height),
                    Math.round(255 * (1 - x / cv.width))];
      let chans = base.slice();
      const gray = +p.gray || 0;
      if (gray) {
        const lum = .299 * chans[0] + .587 * chans[1] + .114 * chans[2];
        chans = chans.map(c => c * (1 - gray) + lum * gray);
      }
      const tints = [p.tint_r, p.tint_g, p.tint_b];
      const out = chans.map((c, i) => {
        let v = (c - 128) * (+p.contrast || 1) + 128 + (+p.brightness || 0);
        v *= (tints[i] === undefined ? 1 : +tints[i]);
        const g = +p.gamma || 1;
        if (g && g !== 1) v = 255 * Math.pow(Math.max(0, Math.min(255, v)) / 255, g);
        return clamp(v);
      });
      const o = (y * cv.width + x) * 4;
      img.data[o] = out[2]; img.data[o + 1] = out[1]; img.data[o + 2] = out[0]; img.data[o + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
}
function initGradeSliders() {
  const names = ['brightness', 'contrast', 'gamma', 'tint_r', 'tint_g', 'tint_b', 'gray'];
  const limits = S.gradeLimits || {};
  $('gradeSliders').innerHTML = names.map(n => {
    const lim = limits[n] || [0, 2];
    const step = (n === 'brightness') ? 1 : 0.01;
    return `<label class="gs-row"><span>${esc(t('grading.param.' + n))}</span>
      <input type="range" data-grade-param="${n}" min="${lim[0]}" max="${lim[1]}" step="${step}"
             value="${esc(S.customParams[n] == null ? 1 : S.customParams[n])}">
      <b data-grade-val="${n}">${esc(S.customParams[n] == null ? 1 : S.customParams[n])}</b></label>`;
  }).join('');
  drawGradePreview();
}
function applyCustomGrading() {
  const label = $('gradePresetName').value.trim() || t('grading.customTitle');
  S.grading = { key: 'custom_live', label, label_en: label, desc: '', desc_en: '',
                params: Object.assign({}, S.customParams), custom: true };
  afterChange();
  toast(t('toast.gradeApplied'));
}
async function saveCustomGrading() {
  const name = $('gradePresetName').value.trim() || t('grading.customTitle');
  try {
    const d = await api('/api/grading/custom/save', { name, params: S.customParams });
    if (!d.ok) { toast(d.error || '保存失败', true); return; }
    S.gradingCat = await api('/api/grading');
    S.grading = d.preset;
    afterChange();
    toast(t('toast.gradeSaved', { n: name }));
  } catch (e) { toast(e.message, true); }
}
async function deleteCustomGrading() {
  const cur = gradingPreset();
  if (!cur || !String(cur.key || '').startsWith('custom_')) return;
  try {
    await api('/api/grading/custom/delete', { key: cur.key });
    S.gradingCat = await api('/api/grading');
    if (gradingKey() === cur.key) S.grading = null;
    afterChange();
    toast(t('toast.gradeDeleted'));
  } catch (e) { toast(e.message, true); }
}

// ---------------- 界面主题 ----------------
function applyTheme(theme, image) {
  const t = theme || 'light';
  document.body.dataset.theme = t;
  document.body.classList.toggle('theme-image', t === 'image' && !!image);
  document.body.style.backgroundImage = (t === 'image' && image) ? `url("${image}")` : '';
  document.body.style.backgroundSize = 'cover';
  document.body.style.backgroundPosition = 'center';
  document.body.style.backgroundAttachment = 'fixed';
  document.querySelectorAll('[data-theme-opt]').forEach(b => {
    b.classList.toggle('active', b.dataset.themeOpt === t);
  });
}
async function saveTheme(theme, image) {
  const payload = { theme };
  if (image !== undefined) payload.theme_image = image;
  try {
    const d = await api('/api/settings', payload);
    if (!d.ok) { toast(d.error || t('toast.themeSaved'), true); return; }
    applyTheme(theme, image === undefined ? '' : image);
    if ($('themeResult')) $('themeResult').textContent = '';
    toast(t('toast.themeSaved'));
  } catch (e) { toast(e.message, true); }
}
function readThemeImage(file) {
  if (!file || !file.type.startsWith('image/')) { toast(t('toast.themePicked'), true); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const maxW = 1600, maxH = 1000;
      const scale = Math.min(1, maxW / img.width, maxH / img.height);
      const cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.round(img.width * scale));
      cv.height = Math.max(1, Math.round(img.height * scale));
      cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
      saveTheme('image', cv.toDataURL('image/jpeg', 0.82));
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

// ---------------- 清单 / 底栏 ----------------
function renderNavBadges() {
  const vals = [countFields(), countOf(S.textChanges), countOf(S.iconChanges),
                skillValueCount() + S.skillAssigns.length, totalChanges()];
  ['navStat', 'navText', 'navIcon', 'navSkill', 'navDiff'].forEach((id, k) => {
    const el = $(id); if (!el) return;
    el.textContent = vals[k]; el.classList.toggle('on', vals[k] > 0);
  });
}
function renderFooter() {
  $('footSummary').innerHTML = t('foot.summary', {
    n: '<b id="footCount">' + totalChanges() + '</b>',
    s: '<b id="footStat">' + countFields() + '</b>',
    t: '<b id="footText">' + countOf(S.textChanges) + '</b>',
    i: '<b id="footIcon">' + countOf(S.iconChanges) + '</b>',
    k: '<b id="footSkill">' + (skillValueCount() + S.skillAssigns.length) + '</b>',
    g: '<b id="footGrade">' + (S.grading ? 1 : 0) + '</b>',
  });
  $('footScope').textContent = t('foot.scope.' + $('scope').value);
  $('btnFootRisk').hidden = !(S.summary && (S.summary.danger || S.summary.warn));
}
function diffRows() {
  const out = [];
  for (const [row, fs] of Object.entries(S.changes)) {
    const c = byRow(row) || { cn: row, cn_en: row };
    for (const [f, v] of Object.entries(fs)) {
      const meta = (S.catalog.fieldMap || {})[f] || { label: f, label_en: f };
      out.push([t('diff.catStat'), L(c, 'cn') + ' · ' + L(meta, 'label'), fmt(c.values[f]), fmt(v),
        () => setChange(row, f, c.values[f])]);
    }
  }
  for (const [id, v] of Object.entries(S.textChanges)) {
    const i = textById(id) || { label: id, label_en: id, value: '—' };
    out.push([t('diff.catText'), L(i, 'label'), clip(i.value, 50), clip(v, 50),
      () => setText(id, i.value)]);
  }
  for (const [id, v] of Object.entries(S.iconChanges)) {
    const i = iconById(id) || { cn: id, cn_en: id };
    const src = iconById(v.from) || { cn: v.from, cn_en: v.from };
    const nv = v.from ? t('diff.officialIcon', { n: L(src, 'cn') }) : t('diff.customImage');
    out.push([t('diff.catIcon'), L(i, 'cn'), t('diff.vanillaIcon'), nv,
      () => { delete S.iconChanges[id]; afterChange(); }]);
  }
  for (const [name, fs] of Object.entries(S.skillValues)) {
    for (const [f, v] of Object.entries(fs)) {
      const s = S.skills && S.skills.byName[name];
      const meta = (S.skills && S.skills.fields.find(x => x.name === f)) || { label: f };
      out.push([t('diff.catSkill'), skillLabel(s) + ' · ' + meta.label,
                fmt(s && s.values ? s.values[f] : '—'), fmt(v),
                () => setSkillValue(name, f, s ? s.values[f] : null)]);
    }
  }
  S.skillAssigns.forEach((a, k) => {
    const s = S.skills && S.skills.byName[a.ability];
    out.push([t('diff.catSkill'), creatureLabel(a.creature) + ' Lv' + a.level + ' ← ' + skillLabel(s),
              '—', t('diff.newSkill'), () => { S.skillAssigns.splice(k, 1); afterChange(); }]);
  });
  if (S.grading) {
    out.push([t('diff.catGrade'), t('diff.grading'), t('diff.vanillaIcon'),
              gradingName(), () => { S.grading = null; afterChange(); }]);
  }
  return out;
}
function renderDiff() {
  const rows = diffRows();
  $('diffStats').innerHTML = `<div class="stat-pill"><b>${countFields()}</b>${esc(t('diff.pill.values'))}</div>
    <div class="stat-pill"><b>${countOf(S.textChanges)}</b>${esc(t('diff.pill.texts'))}</div>
    <div class="stat-pill"><b>${countOf(S.iconChanges)}</b>${esc(t('diff.pill.icons'))}</div>
    <div class="stat-pill"><b>${skillValueCount() + S.skillAssigns.length}</b>${esc(t('diff.pill.skills'))}</div>
    <div class="stat-pill"><b>${totalChanges()}</b>${esc(t('diff.pill.total'))}</div>`;
  $('diffEmpty').hidden = rows.length > 0;
  $('diffBody').innerHTML = rows.slice(0, 400).map((r, k) =>
    `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td><td class="num">${esc(r[3])}</td>
     <td><button class="del" data-del="${k}">${esc(t('diff.del'))}</button></td></tr>`).join('');
  $('diffBody').querySelectorAll('[data-del]').forEach(b => {
    b.onclick = () => { rows[Number(b.dataset.del)][4](); };
  });
}

// ---------------- 生成 / 确认 / 同名提醒 ----------------
function updatePakPreview() {
  $('pakPreview').textContent = 'zzz_EotU_EothTool_' + ($('modName').value.trim() || t('build.modName.def')) + '_P.pak';
}
async function doSummary() {
  if (!hasChanges()) { toast(t('toast.noChanges'), true); return; }
  const btn = $('btnGenerate'); btn.disabled = true; btn.textContent = t('build.generating');
  try {
    const d = await api('/api/summary', buildPayload());
    if (!d.ok) { toast(d.error || t('toast.summaryFail', { e: '' }), true); return; }
    S.summary = d;
    renderFooter();
    if (d.reused) { renderDup(d); $('dupModal').hidden = false; return; }
    renderConfirm(d);
    $('confirmModal').hidden = false;
  } catch (e) { toast(t('toast.summaryFail', { e: e.message }), true); }
  finally { btn.disabled = false; btn.textContent = t('build.generate'); }
}
function renderDup(d) {
  const r = d.reused_info || {};
  const info = r.exists
    ? t('dup.fileInfo', { k: Math.max(1, Math.round((r.size || 0) / 1024)), t: r.mtime || '—' })
    : t('dup.historyInfo', { t: r.last_time || '—' });
  $('dupBody').textContent = t('dup.body', {
    n: d.mod_name, pak: r.pak || d.pak_name, info,
  });
  $('dupPak').textContent = (r.pak || d.pak_name) +
    (LANG === 'en' ? '  ·  in the tool out/ folder' : '  ·  位于工具目录 out/ 下');
}
function renderConfirm(d) {
  const c = d.counts;
  let html = `<div class="summary-counts">
    <div class="sc"><b>${c.stats}</b><span>${esc(t('confirm.statValues'))}</span></div>
    <div class="sc"><b>${c.texts}</b><span>${esc(t('confirm.statTexts'))}</span></div>
    <div class="sc"><b>${c.icons}</b><span>${esc(t('confirm.statIcons'))}</span></div>
    <div class="sc"><b>${c.skills || 0}</b><span>${esc(t('confirm.statSkills'))}</span></div>
    <div class="sc"><b>${c.grading || 0}</b><span>${esc(t('diff.catGrade'))}</span></div>
    <div class="sc"><b>${d.files.length}</b><span>${esc(t('confirm.statFiles'))}</span></div></div>
    <div style="font-size:12px;color:#5d6a82;line-height:1.8">
      ${esc(t('confirm.modName'))}<b>${esc(d.mod_name)}</b> · ${esc(t('confirm.scope'))}<b>${esc(L(d, 'scope_label'))}</b><br>
      ${esc(t('confirm.output'))}<code>${esc(d.pak_name)}</code>${esc(t('confirm.outHint'))}
    </div>`;
  html += `<div class="summary-title">${esc(t('confirm.detail'))}</div>`;
  d.sections.forEach(sec => {
    html += `<div class="sum-sec"><div class="sum-sec-head"><span>${esc(L(sec, 'title'))} · ${sec.count} ${LANG === 'en' ? 'items' : '项'}</span>
      <small>${esc(L(sec, 'note'))}</small></div><div class="sum-rows">` +
      sec.rows.slice(0, 300).map(r => `<div class="sum-row">
        <span class="lbl" title="${esc(L(r, 'label'))}">${esc(L(r, 'label'))}</span>
        <span class="old" title="${esc(L(r, 'old'))}">${esc(clip(L(r, 'old'), 40))}</span>
        <span class="new" title="${esc(L(r, 'new'))}">→ ${esc(clip(L(r, 'new'), 40))}</span></div>`).join('') +
      (sec.rows.length > 300 ? `<div class="sum-row"><span class="lbl">${esc(t('confirm.more', { n: sec.rows.length - 300 }))}</span><span></span><span></span></div>` : '') +
      `</div></div>`;
  });
  html += `<div class="summary-title">${esc(t('confirm.riskTitle'))} <span class="cnt">${esc(t('confirm.riskCount', { d: d.danger, w: d.warn }))}</span></div>
    <div class="risk-list">` + (d.risks.length ? d.risks.map(r =>
    `<div class="risk-item ${r.level}"><span class="ri">${r.level === 'danger' ? '⛔' : r.level === 'warn' ? '⚠️' : 'ℹ️'}</span>
       <div><b>${esc(L(r, 'title'))}</b>${esc(L(r, 'detail'))}</div></div>`).join('')
    : `<div class="risk-item info"><span class="ri">✅</span><div><b>${esc(t('confirm.noRisk'))}</b>${esc(t('confirm.noRiskDetail'))}</div></div>`) + '</div>';
  html += `<div class="summary-files">${esc(t('confirm.files'))}${d.files.map(f => esc(f)).join('<br>')}</div>`;
  $('confirmBody').innerHTML = html;
  const needAck = d.danger > 0;
  $('ackWrap').hidden = !needAck;
  $('ackRisk').checked = false;
  $('btnConfirmGenerate').disabled = needAck;
  $('confirmBody').scrollTop = 0;
}
async function doGenerate() {
  if (!S.summary) return;
  const p = buildPayload(); p.confirmed = true; p.token = S.summary.token;
  $('confirmBody').innerHTML = `<div class="gen-progress">${t('confirm.progress')}</div>`;
  $('btnConfirmGenerate').disabled = true;
  try {
    const r = await api('/api/generate', p);
    if (!r.ok) { toast(r.error || t('toast.genFail', { e: '' }), true); $('confirmModal').hidden = true; return; }
    S.lastResult = r;
    $('confirmModal').hidden = true;
    showResult(r);
    toast(t('toast.genSuccess', { n: r.pak_name }));
    switchTab('build');
  } catch (e) {
    toast(t('toast.genFail', { e: e.message }), true);
    $('confirmModal').hidden = true;
  } finally { $('btnConfirmGenerate').disabled = false; }
}
function showResult(r) {
  $('buildIdle').hidden = true; $('buildResult').hidden = false;
  $('rName').textContent = r.pak_name;
  $('rSize').textContent = t('size.kb', { n: (r.size / 1024).toFixed(1) });
  $('rMd5').textContent = r.md5;
  $('rScope').textContent = L(r, 'scope_label');
  $('rCount').textContent = t('result.count', {
    v: r.changed_values, t: r.changed_texts, i: r.changed_icons,
    k: (r.changed_skills || 0) + (r.assigned_skills || 0), g: r.grading ? 1 : 0,
  });
  $('buildLog').textContent = (r.log || []).join('\n') + ((r.warnings || []).length ? '\n\n' + t('foot.risk') + '\n' + r.warnings.join('\n') : '');
  $('installNote').textContent = '';
}
function renderPakStatus() {
  if (!S.status) return;
  const installed = S.status.installed || [], conflicts = S.status.conflicts || [];
  $('pakStatus').innerHTML =
    `<div>${esc(t('build.paksDir'))}<code>${esc(S.status.info ? S.status.info.paks_dir : '—')}</code></div>` +
    (installed.length ? `<div>${esc(t('build.installed', { p: installed.join('、') }))}</div>` : `<div>${esc(t('build.notInstalled'))}</div>`) +
    conflicts.map(c => `<span class="conf">${esc(t('build.conflict', { p: c }))}</span>`).join('') +
    (S.status.game_running ? `<div style="color:#b07a22">${esc(t('warn.running'))}</div>` : '');
}

// ---------------- 预设 / 设置 / 安装 ----------------
function renderPresets() {
  $('presetList').innerHTML = S.presets.length ? S.presets.map(p =>
    `<div class="preset-row"><b>${esc(p.name)}</b><span class="muted">${p.count} 项 · ${esc(p.saved || '')}</span>
     <button data-load="${esc(p.name)}">${esc(t('build.presetLoad'))}</button></div>`).join('')
    : `<p class="muted">${esc(t('build.presetEmpty'))}</p>`;
  $('presetList').querySelectorAll('[data-load]').forEach(b => { b.onclick = () => loadPreset(b.dataset.load); });
}
async function savePreset() {
  const name = $('presetName').value.trim();
  if (!name) { toast(t('toast.presetName'), true); return; }
  try {
    const d = await api('/api/presets/save', Object.assign(buildPayload(), { name }));
    if (!d.ok) { toast(d.error || t('toast.presetName'), true); return; }
    S.presets = (await api('/api/presets')).presets || [];
    renderPresets(); toast(t('toast.presetSaved'));
  } catch (e) { toast(t('toast.presetSaved') + '：' + e.message, true); }
}
async function loadPreset(name) {
  try {
    const d = await api('/api/presets/load', { name });
    const p = d.preset || {};
    S.changes = p.changes || {}; S.textChanges = p.texts || {}; S.iconChanges = p.icons || {};
    S.skillValues = p.skillValues || {}; S.skillAssigns = p.skillAssigns || []; S.grading = p.grading || null;
    $('modName').value = p.mod_name || t('build.modName.def');
    $('scope').value = p.scope || 'both';
    $('note').value = p.note || '';
    S.textFilter.page = 0; S.summary = null;
    afterChange(); updatePakPreview(); renderPresets();
    toast(t('toast.presetLoaded', { n: name }));
  } catch (e) { toast(t('toast.presetLoaded', { n: name }) + '：' + e.message, true); }
}
async function installPak() {
  if (!S.lastResult) { toast(t('toast.needResult'), true); return; }
  try {
    const d = await api('/api/install', { pak: S.lastResult.pak });
    if (!d.ok) { toast(d.error || t('toast.installFail', { e: '' }), true); return; }
    $('installNote').textContent = t('build.installNote', { p: d.dst });
    S.status = await api('/api/status'); renderStatus(); renderPakStatus();
    toast(t('toast.installOk'));
  } catch (e) { toast(t('toast.installFail', { e: e.message }), true); }
}
async function uninstallPak() {
  try {
    const d = await api('/api/uninstall', {});
    toast(d.ok ? t('toast.uninstall', { n: (d.removed || []).length }) : (d.error || '—'), !d.ok);
    S.status = await api('/api/status'); renderStatus(); renderPakStatus();
  } catch (e) { toast(t('toast.uninstallFail', { e: e.message }), true); }
}
async function saveRoot() {
  const root = $('gameRoot').value.trim();
  if (!root) { toast(t('toast.rootEmpty'), true); return; }
  try {
    const d = await api('/api/settings', { game_root: root });
    if (!d.ok) { $('rootResult').textContent = d.error || t('toast.rootEmpty'); return; }
    const tail = d.issues && d.issues.length ? t('settings.rootIssues', { i: d.issues.join('；') }) : '';
    $('rootResult').textContent = t('settings.rootOk', { p: d.game_root, tail });
    S.status = await api('/api/status'); renderStatus(); renderPakStatus();
  } catch (e) { $('rootResult').textContent = t('settings.rootFail', { e: e.message }); }
}
function exportJson() {
  const data = Object.assign(buildPayload(), { exported: new Date().toISOString() });
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'EotuModTool_改动清单.json'; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
function clearAll() {
  if (!hasChanges() || !confirm(t('clearAll.confirm'))) return;
  S.changes = {}; S.textChanges = {}; S.iconChanges = {};
  S.skillValues = {}; S.skillAssigns = []; S.grading = null; S.summary = null;
  afterChange(); toast(t('toast.cleared'));
}

// ---------------- 批量倍率 ----------------
function renderBatchScope() {
  const sel = $('batchScope'), cur = sel.value || 'filtered';
  sel.innerHTML = BATCH_GROUPS.map(g =>
    `<optgroup label="${esc(t('batch.group.' + g.group))}">` +
    g.items.map(k => `<option value="${k}">${esc(t('scope.' + k))}</option>`).join('') +
    '</optgroup>').join('');
  sel.value = Array.from(sel.options).some(o => o.value === cur) ? cur : 'filtered';
  $('prefixRow').hidden = sel.value !== 'prefix';
}
function batchTargets() {
  if (!S.catalog) return [];
  const all = S.catalog.creatures, scope = $('batchScope').value;
  const hostile = c => c.category === 'wild';
  switch (scope) {
    case 'all': return all;
    case 'player': return all.filter(c => c.category === 'player');
    case 'hostile': return all.filter(hostile);
    case 'hostile_ants': return all.filter(c => hostile(c) && c.family === 'ants');
    case 'hostile_insects': return all.filter(c => hostile(c) && (c.family === 'insects' || c.family === 'beetles'));
    case 'hostile_beetles': return all.filter(c => hostile(c) && c.family === 'beetles');
    case 'hostile_arachnids': return all.filter(c => hostile(c) && c.family === 'arachnids');
    case 'ants': return all.filter(c => c.family === 'ants');
    case 'beetles': return all.filter(c => c.family === 'beetles');
    case 'insects': return all.filter(c => c.family === 'insects');
    case 'arachnids': return all.filter(c => c.family === 'arachnids');
    case 'others': return all.filter(c => c.family === 'others');
    case 'special': return all.filter(c => c.family === 'special' || c.category === 'special');
    case 'prefix': {
      const p = $('batchPrefix').value.trim().toLowerCase();
      return p ? all.filter(c => c.row.toLowerCase().startsWith(p)) : [];
    }
    default: return filteredCreatures();
  }
}
function batchFields() {
  return Array.from(document.querySelectorAll('#batchFields input:checked')).map(i => i.value);
}
function batchChecked(name) {
  return document.querySelector(`#batchFields input[value="${name}"]`)?.checked ||
    ['Health', 'AttackDamage'].includes(name);
}
function batchPreview() {
  const mul = Number($('batchMul').value);
  $('batchPreview').textContent = !Number.isFinite(mul) || mul < 0 ? t('batch.invalid') :
    t('batch.preview', { n: batchTargets().length, f: batchFields().length, m: mul });
}
function openBatch() {
  const fs = S.catalog.fields.filter(f => f.kind === 'float' || f.kind === 'int');
  $('batchFields').innerHTML = fs.map(f =>
    `<label><input type="checkbox" value="${f.name}" ${['Health', 'AttackDamage'].includes(f.name) ? 'checked' : ''}>${esc(L(f, 'label'))}</label>`).join('');
  $('batchModal').hidden = false; batchPreview();
}
function applyBatch() {
  const targets = batchTargets(), fs = batchFields();
  const mul = Number($('batchMul').value), digits = Number($('batchRound').value);
  if (!targets.length || !fs.length || !Number.isFinite(mul) || mul < 0) { toast(t('toast.batchIncomplete'), true); return; }
  let n = 0;
  for (const c of targets) for (const f of fs) {
    const orig = c.values[f];
    if (typeof orig !== 'number') continue;
    const cur = (S.changes[c.row] || {})[f] !== undefined ? S.changes[c.row][f] : orig;
    let v = cur * mul;
    v = digits === 0 ? Math.round(v) : Number(v.toFixed(digits));
    if ((S.catalog.fieldMap || {})[f] && S.catalog.fieldMap[f].kind === 'int') v = Math.round(v);
    setChange(c.row, f, v); n++;
  }
  $('batchModal').hidden = true;
  toast(t('toast.batchApplied', { n }));
}

// ---------------- 事件 ----------------
function bindEvents() {
  // 全局点击音：按钮与可点击项，轻节流避免连点爆音；输入框/文本选择不触发
  let _lastClick = 0;
  document.addEventListener('click', e => {
    const el = e.target.closest('button, [data-sound-opt], [data-theme-opt], [data-lang-opt], .node, .scard, .gcard, .tab-btn');
    if (!el || el.closest('[data-sound-opt]')) return;
    const now = Date.now();
    if (now - _lastClick < 45) return;
    _lastClick = now;
    playClick();
  }, true);
  document.querySelectorAll('.nav-item').forEach(b => { b.onclick = () => switchTab(b.dataset.tab); });
  $('btnShutdown').onclick = async () => {
    if (!confirm(t('shutdown.confirm'))) return;
    try { await api('/api/shutdown', {}); } catch (e) { /* 服务已关闭 */ }
    document.body.innerHTML = `<div style="display:flex;height:100vh;align-items:center;justify-content:center;font-size:16px;color:#5d6a82">${esc(t('shutdown.done'))}</div>`;
  };
  // 标题栏作者链接：普通浏览器直接开新标签；内置预览被拦截时让后端用系统浏览器打开
  $('authorLink').addEventListener('click', e => {
    const url = $('authorLink').href;
    let w = null;
    try { w = window.open(url, '_blank', 'noopener'); } catch (err) { /* ignore */ }
    if (w) { e.preventDefault(); return; }
    e.preventDefault();
    api('/api/open-url', { url }).catch(() => {});
  });
  // 语言切换（标题栏快捷按钮 + 设置页单选）
  $('btnLang').onclick = () => setLang(LANG === 'zh' ? 'en' : 'zh');
  document.querySelectorAll('[data-lang-opt]').forEach(b => {
    b.onclick = () => setLang(b.dataset.langOpt);
  });
  // 界面主题
  document.querySelectorAll('[data-theme-opt]').forEach(b => {
    b.onclick = () => {
      if (b.dataset.themeOpt === 'image') { $('themeFile').click(); return; }
      saveTheme(b.dataset.themeOpt);
    };
  });
  $('themeFile').onchange = e => { if (e.target.files[0]) readThemeImage(e.target.files[0]); };

  // 提示音效开关
  document.querySelectorAll('[data-sound-opt]').forEach(b => {
    b.onclick = () => saveSound(b.dataset.soundOpt === 'on');
  });

  // 生物列表
  $('search').addEventListener('input', e => {
    S.filter.q = e.target.value; $('btnClearSearch').hidden = !S.filter.q; renderCreatureList();
  });
  $('btnClearSearch').onclick = () => { $('search').value = ''; S.filter.q = ''; $('btnClearSearch').hidden = true; renderCreatureList(); };
  $('familyFilters').addEventListener('click', e => {
    const b = e.target.closest('[data-fam]'); if (!b) return;
    S.filter.family = b.dataset.fam; renderFamilyFilters(); renderCreatureList(); batchPreview();
  });
  $('sideFilters').addEventListener('click', e => {
    const b = e.target.closest('[data-side]'); if (!b) return;
    S.filter.side = b.dataset.side;
    $('sideFilters').querySelectorAll('button').forEach(x => x.classList.toggle('active', x === b));
    renderCreatureList();
  });
  $('creatureList').addEventListener('click', e => {
    const it = e.target.closest('[data-row]'); if (it) selectCreature(it.dataset.row);
  });
  $('btnResetRow').onclick = () => { if (S.selected) { delete S.changes[S.selected]; afterChange(); toast(t('toast.resetRow')); } };
  $('fieldGroups').addEventListener('change', e => {
    const el = e.target;
    if (el.dataset.field && S.selected) {
      const meta = (S.catalog.fieldMap || {})[el.dataset.field] || {};
      let v = el.value.trim();
      if (meta.kind === 'int') v = Math.round(Number(v)); else v = Number(v);
      if (!Number.isFinite(v)) { toast(t('toast.number'), true); renderEditor(); return; }
      setChange(S.selected, el.dataset.field, v);
    }
  });
  $('fieldGroups').addEventListener('click', e => {
    const el = e.target;
    if (el.dataset.bool && S.selected) {
      const c = byRow(S.selected), cur = (S.changes[S.selected] || {})[el.dataset.bool] !== undefined
        ? S.changes[S.selected][el.dataset.bool] : c.values[el.dataset.bool];
      setChange(S.selected, el.dataset.bool, !cur);
    }
    const r = el.dataset.reset;
    if (r && S.selected) setChange(S.selected, r, byRow(S.selected).values[r]);
  });

  // 文案
  $('textSearch').addEventListener('input', e => {
    S.textFilter.q = e.target.value; S.textFilter.page = 0;
    $('btnClearTextSearch').hidden = !S.textFilter.q; renderTexts();
  });
  $('btnClearTextSearch').onclick = () => { $('textSearch').value = ''; S.textFilter.q = ''; S.textFilter.page = 0; $('btnClearTextSearch').hidden = true; renderTexts(); };
  $('textGroupSel').onchange = e => { S.textFilter.group = e.target.value; S.textFilter.page = 0; renderTexts(); };
  $('btnTextOnlyChanged').onclick = () => {
    S.textFilter.onlyChanged = !S.textFilter.onlyChanged;
    $('btnTextOnlyChanged').textContent = S.textFilter.onlyChanged ? t('texts.showAll') : t('texts.onlyChanged');
    S.textFilter.page = 0; renderTexts();
  };
  $('textList').addEventListener('change', e => {
    const el = e.target;
    if (el.dataset.tid) setText(el.dataset.tid, el.value);
  });
  $('textList').addEventListener('click', e => {
    const b = e.target.closest('[data-treset]');
    if (b) { const i = textById(b.dataset.treset); if (i) setText(i.id, i.value); }
  });

  // 图标
  $('iconSearch').addEventListener('input', e => {
    S.iconFilter.q = e.target.value; $('btnClearIconSearch').hidden = !S.iconFilter.q; renderIcons();
  });
  $('btnClearIconSearch').onclick = () => { $('iconSearch').value = ''; S.iconFilter.q = ''; $('btnClearIconSearch').hidden = true; renderIcons(); };
  $('iconFamilySel').onchange = e => { S.iconFilter.family = e.target.value; renderIcons(); };
  $('btnIconOnlyChanged').onclick = () => {
    S.iconFilter.onlyChanged = !S.iconFilter.onlyChanged;
    $('btnIconOnlyChanged').textContent = S.iconFilter.onlyChanged ? t('icons.showAll') : t('icons.onlyChanged'); renderIcons();
  };
  $('iconGrid').addEventListener('click', e => {
    const it = e.target.closest('[data-icon]'); if (it) openIconModal(it.dataset.icon);
  });
  document.querySelectorAll('.it').forEach(b => { b.onclick = () => switchIconTab(b.dataset.itab); });
  $('pickerSearch').addEventListener('input', renderPicker);
  $('pickerGrid').addEventListener('click', e => {
    const it = e.target.closest('[data-pick]'); if (!it) return;
    S.picker.sel = it.dataset.pick; S.picker.image = null;
    $('btnApplyIcon').disabled = false; renderPicker();
  });
  $('uploadZone').onclick = () => $('iconFile').click();
  $('uploadZone').addEventListener('dragover', e => { e.preventDefault(); });
  $('uploadZone').addEventListener('drop', e => {
    e.preventDefault(); if (e.dataTransfer.files[0]) readIconFile(e.dataTransfer.files[0]);
  });
  $('iconFile').onchange = e => { if (e.target.files[0]) readIconFile(e.target.files[0]); };
  $('btnCloseIconModal').onclick = $('btnCancelIconModal').onclick = () => { $('iconModal').hidden = true; };
  $('btnResetIcon').onclick = () => {
    if (!S.picker.id) return;
    delete S.iconChanges[S.picker.id]; $('iconModal').hidden = true; afterChange(); toast(t('toast.iconReset'));
  };
  $('btnApplyIcon').onclick = applyIcon;

  // 技能编辑
  $('skillSearch').addEventListener('input', e => {
    S.skillFilter.q = e.target.value; $('btnClearSkillSearch').hidden = !S.skillFilter.q; renderSkills();
  });
  $('btnClearSkillSearch').onclick = () => { $('skillSearch').value = ''; S.skillFilter.q = ''; $('btnClearSkillSearch').hidden = true; renderSkills(); };
  $('btnSkillOnlySafe').onclick = () => { S.skillFilter.onlySafe = !S.skillFilter.onlySafe; renderSkills(); };
  $('btnSkillOnlyChanged').onclick = () => { S.skillFilter.onlyChanged = !S.skillFilter.onlyChanged; renderSkills(); };
  $('skillList').addEventListener('change', e => {
    const el = e.target;
    if (el.dataset.skill && el.dataset.field) setSkillValue(el.dataset.skill, el.dataset.field, el.value);
  });
  $('skillList').addEventListener('click', e => {
    const add = e.target.closest('[data-addskill]');
    if (add) { openAssignModal(add.dataset.addskill); return; }
    const rs = e.target.closest('[data-resetskill]');
    if (rs) { delete S.skillValues[rs.dataset.resetskill]; afterChange(); toast(t('toast.skillReset')); }
  });
  $('skillAssignList').addEventListener('click', e => {
    const d = e.target.closest('[data-delassign]');
    if (d) { S.skillAssigns.splice(Number(d.dataset.delassign), 1); afterChange(); }
  });
  $('btnCloseAssignModal').onclick = $('btnCancelAssignModal').onclick = () => { $('assignModal').hidden = true; };
  $('btnConfirmAssign').onclick = confirmAssign;
  $('btnSkillHelp').onclick = () => { $('skillHelpModal').hidden = false; };
  $('btnCloseSkillHelp').onclick = $('btnCloseSkillHelp2').onclick = () => { $('skillHelpModal').hidden = true; };

  // 滤镜预设 + 自定义
  $('gradeGrid').addEventListener('click', e => {
    const c = e.target.closest('[data-grade]'); if (c) setGrading(c.dataset.grade);
  });
  $('gradeSliders').addEventListener('input', e => {
    const n = e.target.dataset.gradeParam;
    if (!n) return;
    S.customParams[n] = Number(e.target.value);
    const out = document.querySelector(`[data-grade-val="${n}"]`);
    if (out) out.textContent = e.target.value;
    drawGradePreview();
  });
  $('btnGradeClear').onclick = () => { S.grading = null; afterChange(); };
  $('btnGradeApplyCustom').onclick = applyCustomGrading;
  $('btnGradeSavePreset').onclick = saveCustomGrading;
  $('btnGradeDeleteCustom').onclick = deleteCustomGrading;

  // 清单 / 生成 / 同名提醒
  $('btnExport').onclick = exportJson;
  $('btnClear').onclick = clearAll;
  $('btnGenerate').onclick = doSummary;
  $('btnQuickGenerate').onclick = () => { switchTab('build'); setTimeout(doSummary, 40); };
  $('btnFootRisk').onclick = doSummary;
  $('btnCloseConfirm').onclick = $('btnCancelConfirm').onclick = () => { $('confirmModal').hidden = true; };
  $('ackRisk').onchange = e => { $('btnConfirmGenerate').disabled = !e.target.checked; };
  $('btnConfirmGenerate').onclick = doGenerate;
  const cancelDup = () => { $('dupModal').hidden = true; };
  $('btnCloseDup').onclick = $('btnCancelDup').onclick = cancelDup;
  $('btnConfirmDup').onclick = () => {
    $('dupModal').hidden = true;
    if (S.summary) { renderConfirm(S.summary); $('confirmModal').hidden = false; }
  };
  $('btnInstall').onclick = installPak;
  $('btnUninstall').onclick = uninstallPak;
  $('btnOpenOut').onclick = () => api('/api/open-folder', {});
  $('modName').addEventListener('input', () => { S.summary = null; updatePakPreview(); renderFooter(); });
  $('scope').addEventListener('change', () => { S.summary = null; renderFooter(); });
  $('note').addEventListener('input', () => { S.summary = null; });
  $('btnSavePreset').onclick = savePreset;
  $('btnSaveRoot').onclick = saveRoot;

  // 批量
  $('btnBatch').onclick = openBatch;
  $('btnCloseBatch').onclick = $('btnCancelBatch').onclick = () => { $('batchModal').hidden = true; };
  $('btnApplyBatch').onclick = applyBatch;
  $('batchScope').onchange = e => { $('prefixRow').hidden = e.target.value !== 'prefix'; batchPreview(); };
  $('batchPrefix').addEventListener('input', batchPreview);
  $('batchMul').addEventListener('input', batchPreview);
  $('batchFields').addEventListener('change', batchPreview);
  $('familyFilters').addEventListener('click', batchPreview);
  $('sideFilters').addEventListener('click', batchPreview);

  // 快捷键
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault(); switchTab('editor'); $('search').focus(); $('search').select();
    }
    if (e.key === 'Escape') {
      ['confirmModal', 'iconModal', 'batchModal', 'dupModal', 'assignModal'].forEach(id => { const el = $(id); if (el) el.hidden = true; });
    }
  });
}

function readIconFile(file) {
  if (!file || !file.name.toLowerCase().endsWith('.png')) { toast(t('toast.pngOnly'), true); return; }
  if (file.size > 8 * 1024 * 1024) { toast(t('toast.imageBig'), true); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      S.picker.image = reader.result; S.picker.sel = null;
      $('uploadImg').src = reader.result;
      $('uploadInfo').textContent = file.name + ' · ' + img.width + '×' + img.height;
      const item = iconById(S.picker.id);
      $('uploadHint').textContent = t('upload.scale', { s: item ? item.w + '×' + item.h : '—' });
      $('uploadPreview').hidden = false;
      $('btnApplyIcon').disabled = false;
      switchIconTab('upload');
    };
    img.onerror = () => toast(t('toast.imageBad'), true);
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

init();
