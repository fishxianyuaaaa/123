# Eotu Mod Tool (v2.2)

A local, **offline** modding tool for **Empires of the Undergrowth** (地下蚁国).
It reads the game's own data tables / localization / textures from a bundled
copy, lets you edit them in a browser UI, and writes out a standard `_P.pak`
mod file that you drop into the game's `Paks` folder.

- **No internet connection is ever made** by this tool.
- **No game files are modified in place** — it only *creates* a new `.pak` in your chosen game folder.
- This is a modding utility for a game you already own; it does not distribute any game assets of its own beyond small reference copies used to build your mod.

Author: **bilbil聪明de咸鱼**
This software is **completely free** — please do NOT use it for commercial gain.

---

## What it can do / 功能

1. **Creature stats** — edit 34 numeric attributes for each of 283 creatures.
2. **Chinese text** — edit 389 UI/localization strings (locres, rebuilt in-place).
3. **Icons** — swap any of 76 creature/chamber icons with bundled official icons or your own PNG.
4. **Skills** — edit 337 abilities, assign abilities to creatures, and set custom Chinese skill names.
5. **Color grading** — apply 5 preset looks (or 7-parameter custom grading) to any of 20 scene LUT textures.
6. **UI themes** — light / dark / custom background image; Chinese and English interface.
7. **Sound effects** — optional entrance/click sounds (off by default; enable in Settings).

Before writing anything, the tool shows a **change summary** (old → new values,
risk level, affected files). You must confirm it before it generates the pak.

---

## Source layout / 源码结构

```
EotuModTool-src-v2.2/
├── EothModTool.py            # entry point: starts a local web server + opens the browser
├── eotu_stats.py             # UE4 DataTable reader/writer (equal-length CreatureStats edits)
├── probe.py                  # game-folder detection
├── uasset_rename.py          # uasset name-table / serial-offset handling
├── Eoth-Mod Tool.spec        # PyInstaller build spec
├── config.json               # clean default config (lang/theme/sound)
├── core/                     # backend: locres, skills, grading, generator, server, ...
├── web/                      # frontend: index.html / app.js / i18n.js / style.css
├── tools/                    # build-time helpers + end-to-end tests
├── assets/
│   ├── bin/repak.exe         # repak packer (bundled, used to create the .pak)
│   ├── tables/               # vanilla data tables (Abilities / CreatureStats / ...)
│   ├── loc/                  # vanilla locres files
│   ├── icons/                # 76 official icons (uasset/uexp + png)
│   ├── grading/              # 20 scene LUT textures (uasset/uexp)
│   ├── sound/                # optional WAV effects
│   └── logo.ico / logo.png   # app icon (already generated)
└── README.md
```

The reference data under `assets/` is bundled, so you do **not** need the game
installed to build the executable or to run the tool from source.

---

## How to build the executable / 如何编译出 exe

### Requirements / 环境
- Python **3.10+**
- `pyinstaller`
- Pillow is only needed if you want to **regenerate** the logo (`tools/make_logo.py`);
  the shipped logo files are already included, so the build does not need it.

### Steps / 步骤
```bash
cd EotuModTool-src-v2.2
pip install pyinstaller
python -m PyInstaller "Eoth-Mod Tool.spec" --noconfirm
```

The spec uses `console=False` (windowed) and embeds `assets/` + `web/` + the icon,
so the result is a **single self-contained file**: `dist/Eotu Mod Tool.exe`.

To run directly from source (no build):
```bash
python EothModTool.py
# then open http://127.0.0.1:8765/
```

### Tests / 测试 (optional)
```bash
python tools/e2e_test.py
python tools/e2e_v3_test.py
```
These run the end-to-end smoke tests against a temporary game folder. They are
not required for normal use or for building.

---

## Notes / 说明

- The tool writes mods only into the game folder you pick in the UI; it appends
  `EotU/Content/Paks/` to that folder automatically (enter the **game root**, not the Paks folder).
- Generated pak names are prefixed `zzz_` so they load last and override vanilla data.
- All edits are reversible: delete the generated `.pak` to restore the vanilla game.

---

## License / 许可

Free for personal use. **Do not sell, paywall, or use this software for
commercial profit.** Attribution to the original author
(**bilbil聪明de咸鱼**) is appreciated.

免费供个人使用。**禁止用于任何商业牟利行为**（出售、付费墙等）。
鼓励注明原作者 bilbil聪明de咸鱼。
