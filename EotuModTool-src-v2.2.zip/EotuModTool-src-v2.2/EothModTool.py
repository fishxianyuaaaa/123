# -*- coding: utf-8 -*-
"""Eotu Mod Tool 入口：启动本地服务并打开独立软件窗口。

用法：
    Eotu Mod Tool.exe                # 双击启动
    python EothModTool.py            # 源码模式
    python EothModTool.py --no-browser --port 8765
"""
import argparse
import os
import subprocess
import sys
import webbrowser

# 打包成无控制台 exe 时 stdout 可能是 None，统一兜底
try:
    if sys.stdout is None:
        sys.stdout = open(os.devnull, 'w', encoding='utf-8')
    if sys.stderr is None:
        sys.stderr = open(os.devnull, 'w', encoding='utf-8')
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from core import paths, server  # noqa: E402

VERSION = '2.2'


def _edge():
    for var in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
        base = os.environ.get(var)
        if not base:
            continue
        p = os.path.join(base, r'Microsoft\Edge\Application\msedge.exe')
        if os.path.isfile(p):
            return p
    return None


def open_window(url, port=8765):
    edge = _edge()
    if edge:
        try:
            # 按端口隔离 profile：避免旧版本窗口复用同一 profile，导致看到旧页面
            profile = os.path.join(paths.APP_DIR, f'edge_profile_{port}')
            cmd = [edge, f'--app={url}', '--window-size=1500,980',
                   '--no-first-run', '--no-default-browser-check',
                   '--disable-features=msEdgeSplitScreen',
                   # 允许进场问候音在无用户手势时自动播放
                   '--autoplay-policy=no-user-gesture-required',
                   f'--user-data-dir={profile}']
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return '独立软件窗口（Edge App 模式）'
        except Exception:
            pass
    try:
        webbrowser.open(url)
        return '默认浏览器'
    except Exception:
        return '未能自动打开，请手动访问 ' + url


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8765)
    ap.add_argument('--no-browser', action='store_true')
    args = ap.parse_args()

    srv, port = server.start(args.port)
    url = f'http://127.0.0.1:{port}/'
    issues, info = paths.check_environment()
    print('=' * 64)
    print(f'  Eotu Mod Tool  v{VERSION}  —  地下蚁国 Mod 工坊')
    print('=' * 64)
    print('  界面地址：' + url)
    print('  游戏目录：' + info['game_root'])
    print('  输出目录：' + paths.OUT_DIR)
    print('  资产来源：' + info['source'] + ' · 图标库 ' + ('就绪' if info['icons'] else '缺失'))
    if issues:
        print('  ⚠ 环境提示：' + '；'.join(issues[:3]))
    print('  关闭方法：点界面右上角「关闭工具」，或在此窗口按 Ctrl+C')
    print('=' * 64)

    if not args.no_browser:
        print('  已打开：' + open_window(url, port))
    print('  服务已就绪。\n', flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
        print('  已退出。')


def _fatal(exc):
    """无控制台 exe 出错时，写日志并弹窗，方便分享给别人后排查。"""
    import traceback
    detail = traceback.format_exc()
    try:
        with open(os.path.join(paths.APP_DIR, 'eoth_error.log'), 'w', encoding='utf-8') as f:
            f.write(detail)
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(
            0, 'Eotu Mod Tool 启动失败：\n' + str(exc) +
            '\n\n详细信息已写到程序目录下的 eoth_error.log',
            'Eotu Mod Tool', 16)
    except Exception:
        pass


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        _fatal(e)
