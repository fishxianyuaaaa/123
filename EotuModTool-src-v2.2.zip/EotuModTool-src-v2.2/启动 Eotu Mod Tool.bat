@echo off
chcp 65001 >nul
title Eotu Mod Tool
setlocal
set "TOOLDIR=%~dp0"

rem Prefer the standalone exe (no Python needed); fall back to source mode.
if exist "%TOOLDIR%Eotu Mod Tool.exe" (
  start "" "%TOOLDIR%Eotu Mod Tool.exe" %*
  exit /b 0
)

for /f "delims=" %%i in ('where python 2^>nul') do set "PYEXE=%%i" & goto run
for /f "delims=" %%i in ('where py 2^>nul') do set "PYEXE=%%i" & goto runpy
echo [ERROR] Python not found. Please install Python 3.9+ and try again.
pause
exit /b 1

:runpy
"%PYEXE%" -3 "%TOOLDIR%EothModTool.py" %*
goto done

:run
"%PYEXE%" "%TOOLDIR%EothModTool.py" %*

:done
echo.
echo Eotu Mod Tool has stopped. Press any key to close this window.
pause >nul
